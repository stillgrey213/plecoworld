<?php
/**
 * Operations of the plugin are included here.
 *
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
global $vwg_pro_activation_id;

/**
 * Save PRO Settings
 *
 * @since 1.0
 */
function vwg_pro_save_settings() {

    $settings = get_option('vwg_pro_settings');

    /**
     * General settings section
     */
    if ( isset( $_POST['vwg_save_general_settings_nonce'] ) && check_admin_referer( 'vwg_save_general_settings', 'vwg_save_general_settings_nonce' ) ) {

        $custom_svg_icon = isset($_POST['vwg_settings_custom_svg_icon']) ? sanitize_text_field($_POST['vwg_settings_custom_svg_icon']) : '';

        $settings['vwg_settings_custom_svg_icon'] = $custom_svg_icon;

        update_option('vwg_pro_settings', $settings);
    }

/**
     * Thumbnails optimization section
     */
    if ( isset( $_POST['vwg_save_thumbnails_optimization_nonce'] ) && check_admin_referer( 'vwg_save_thumbnails_optimization', 'vwg_save_thumbnails_optimization_nonce' ) ) {

        $optimized_thumbnails = isset($_POST['vwg_settings_optimized_thumbnails']) ? sanitize_text_field($_POST['vwg_settings_optimized_thumbnails']) : '';
        $convert_on_upload = isset($_POST['vwg_settings_convert_on_upload']) ? sanitize_text_field($_POST['vwg_settings_convert_on_upload']) : '';

        $settings['vwg_settings_optimized_thumbnails'] = $optimized_thumbnails;
        $settings['vwg_settings_convert_on_upload'] = $convert_on_upload;

        update_option('vwg_pro_settings', $settings);
        vwg_settings_saved_notice(__( 'Optimization settings saved successfully.', 'video-wc-gallery-pro' ));
    }

}

/**
 * Modify strings for PRO version
 *
 * @since 1.0
 */
function vwg_pro_modify_strings_pro_version($title) {
    if ($title == 'Video Gallery for WooCommerce Settings') {
        $modified_title = 'Video Gallery for WooCommerce PRO Settings';
    } else {
        $modified_title = $title . ' PRO';
    }
    return $modified_title;
}


/**
 * Remove feature link
 *
 * @since 1.0
 */
function vwg_pro_remove_feature_link($html) {
    return '';
}

/**
 * Allow SVG upload
 *
 * @since 1.0
 */
function vwg_pro_allow_svg_upload($mimes) {
    // enable svg for super users.
    if(current_user_can('manage_options')){
        $mimes['svg'] = 'image/svg+xml';
    }
    return $mimes;
}

/**
 * Upload SVG to VWG PRO Settings
 *
 * @since 1.0
 */
function vwg_pro_save_svg_attachment() {
    $vwg_pro_data = get_option('vwg_pro_settings');
    // Check if the user is allowed to upload files
    if ( ! current_user_can( 'upload_files' ) ) {
        wp_send_json_error( 'You do not have permission to upload files.' );
    }

    check_ajax_referer( 'vwg_pro_save_svg_attachment_nonce', 'nonce' );

    // Get the attachment details from the AJAX request
    $attachment = isset( $_POST['attachment'] ) ? $_POST['attachment'] : '';

    $vwg_pro_data['svg_data'] = $attachment;

    update_option( 'vwg_pro_settings', $vwg_pro_data );

    wp_send_json_success(
        array(
            'message' => __( 'SVG attachment saved successfully!', 'video-wc-gallery-pro' ),
            'svg_data' => $attachment
        )
    );
}
add_action( 'wp_ajax_vwg_pro_action_save_svg_attachment', 'vwg_pro_save_svg_attachment' );

/**
 * Remove GET PRO metabox if license is active
 *
 * @since 1.0
 */
function vwg_remove_pro_version_metabox() {
    remove_meta_box('vwg_metabox_get_pro_version', 'video-gallery_page_video-gallery-wc-settings', 'side');
}

/**
 * Increases the video limit from 2 to 6 for the PRO version
 *
 * @since 1.0
 * @param int $limit Standard limit
 * @return int Modified limit
 */
function vwg_pro_video_limit( $limit ) {
    return 6; // New limit of 6 videos for the PRO version
}

/**
 * Sets PRO status for the plugin
 *
 * @since 1.0
 * @param bool $is_pro Standard value
 * @return bool Returns true
 */
function vwg_pro_is_active( $is_pro ) {
    return true;
}

/**
 * Removes links to PRO features
 *
 * @since 1.0
 * @param string $link Original link
 * @return string Empty string
 */
function vwg_pro_remove_feature_links( $link ) {
    return '';
}

/**
 * Remove products limit for PRO
 *
 * @since 1.1
 * @param int $limit
 * @return int
 */
function vwg_pro_pml_f( $limit ) {
    return PHP_INT_MAX;
}

/**
 * Replace the free version function with PRO version
 * 
 * @since 1.2
 */
function vwg_pro_replace_frontend_functions() {
    // Remove the free version function if it exists
    if (function_exists('vwg_add_custom_style_and_scripts_product_page')) {
        remove_action('wp_footer', 'vwg_add_custom_style_and_scripts_product_page');
    }
    
    // Add the PRO version function if it exists
    if (function_exists('vwg_pro_add_custom_style_and_scripts_product_page')) {
        add_action('wp_footer', 'vwg_pro_add_custom_style_and_scripts_product_page', 10);
    } else {
        // Load the PRO frontend file if not already loaded
        require_once(VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'functions/vwg-pro-frontend.php');
        add_action('wp_footer', 'vwg_pro_add_custom_style_and_scripts_product_page', 10);
    }
}

if ($vwg_pro_activation_id) {
    $vwg_pro_data = get_option('vwg_pro_settings');
    $vwg_settings_optimized_thumbnails = (is_array($vwg_pro_data) && isset($vwg_pro_data['vwg_settings_optimized_thumbnails'])) ? $vwg_pro_data['vwg_settings_optimized_thumbnails'] : '';
    $vwg_settings_convert_on_upload = (is_array($vwg_pro_data) && isset($vwg_pro_data['vwg_settings_convert_on_upload'])) ? $vwg_pro_data['vwg_settings_convert_on_upload'] : '';

    add_action('admin_init', 'vwg_pro_save_settings');

    add_action('admin_enqueue_scripts', 'vwg_pro_enqueue_css_js', 100 );
    add_filter('vwg_modify_strings', 'vwg_pro_modify_strings_pro_version');
    add_filter('vwg_pro_feature_link', 'vwg_pro_remove_feature_link');
    add_filter('upload_mimes', 'vwg_pro_allow_svg_upload');
    
    // Add PRO features filters
    add_filter('vwg_continue_video_loop', 'vwg_pro_video_limit', 10, 1);
    add_filter('vwg_is_pro_addon', 'vwg_pro_is_active');
    add_filter('vwg_pro_feature_link', 'vwg_pro_remove_feature_links');
    add_filter('vwg_pml_f', 'vwg_pro_pml_f', 10, 1);

    // Include YouTube functionality
    require_once( dirname( __FILE__ ) . '/youtube_video_url.php' );
    
    // Include SEO Settings
    require_once( dirname( __FILE__ ) . '/video_seo_settings.php' );

    // Include Image Optimization
    require_once( dirname( __FILE__ ) . '/image_optimization.php' );

    // Replace frontend functions
    add_action('init', 'vwg_pro_replace_frontend_functions', 20);

    if ($vwg_settings_optimized_thumbnails) {
        add_filter('vwg_product_gallery_html', 'replace_product_thumbnails_with_webp', 20);
        add_filter('woocommerce_single_product_image_thumbnail_html', 'replace_product_thumbnails_with_webp', 9999, 2);
        add_filter('woocommerce_single_product_image_html', 'replace_product_thumbnails_with_webp', 9999, 2);
    }

    if ($vwg_settings_convert_on_upload) {
        add_action('vwg_image_paths_processed', 'vwg_pro_convert_on_upload', 10, 3);
    }
} else {
    delete_option( 'vwg_pro_settings' );
} 