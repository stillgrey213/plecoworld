<?php
/**
 * Operations from the frontend
 *
 * @since 1.3
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

function vwg_pro_add_custom_style_and_scripts_product_page() {
    if ( is_product() ) {
        global $product;

        // Ensure $product is a valid object and initialize if necessary
        if (!is_object($product)) {
            $product = wc_get_product(get_the_ID());
        }

        // Verify that we now have a valid product object
        if (!is_object($product)) {
            return; // Exit the function if $product is still not valid
        }

        $pro_opt = get_option('vwg_pro_settings');
        $use_webp = (is_array($pro_opt) && !empty($pro_opt['vwg_settings_optimized_thumbnails']));

        // Enqueue Video.js YouTube library for frontend YouTube video support
        wp_enqueue_script('videojs-youtube', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/videojs-youtube/Youtube.min.js', array('jquery', 'videojs'), '3.0.0', true);

        $iconColor = get_option('vwg_settings_group')['vwg_settings_icon_color'];
        $icon = get_option('vwg_settings_group')['vwg_settings_icon'];
        $adaptSettings = get_option('vwg_settings_group')['vwg_settings_video_adapt_sizes'];
        $showFirstClassSettings = get_option('vwg_settings_group')['vwg_settings_show_first'];
        $useDefaultAttrVariable = 0;

        // PRO
        $proSettings = get_option('vwg_pro_settings');
        // PRO

        if ($product->is_type('variable')) {
            $default_attributes = $product->get_default_attributes();
            if ($default_attributes && isset($showFirstClassSettings) && $showFirstClassSettings == 1) {
                $useDefaultAttrVariable = 1;
            }
        }

        if ($icon == 'far fa-play-circle') {
            $unuCodeIcon = 'f144';
            $iconWeight = '500';
        } elseif ($icon == 'fas fa-play-circle') {
            $unuCodeIcon = 'f144';
            $iconWeight = '900';
        } elseif ($icon == 'fas fa-play') {
            $unuCodeIcon = 'f04b';
            $iconWeight = '900';
        } elseif ($icon == 'fas fa-video') {
            $unuCodeIcon = 'f03d';
            $iconWeight = '900';
        } elseif ($icon == 'fas fa-file-video') {
            $unuCodeIcon = 'f1c8';
            $iconWeight = '900';
        } elseif ($icon == 'far fa-file-video') {
            $unuCodeIcon = 'f1c8';
            $iconWeight = '500';
        } else {
            $unuCodeIcon = 'f04b';
            $iconWeight = '900';
        }
        ?>
        <style>
            .vwg-video-wrapper { width: 100%; height: 100%; overflow: hidden; position: relative; margin: auto !important; }
            .vwg-video-wrapper img { width: 100%; height: 100%; margin: auto !important; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) }
            /*.vwg-video-wrapper img.vwg-generated-thumb { width: 100% !important; height: 100% !important;}*/
            .vwg-video-wrapper i { font-size: 24px; color: <?=esc_attr($iconColor)?>; position: absolute; left: 50%; top: 50%; transform: translate(-50%,-50%); }
            .woocommerce div.product div.images .flex-control-thumbs li .vwg-video-wrapper {cursor: pointer;opacity: .5;margin: 0;}
            .woocommerce div.product div.images .flex-control-thumbs li .vwg-video-wrapper:hover, .woocommerce div.product div.images .flex-control-thumbs li .vwg-video-wrapper.flex-active {opacity: 1;}

            /* PRO */
            .vwg-video-wrapper div.vwg-custom-svg {
                position: absolute;
                width: 100%;
                height: 100%;
                background-position: center center;
                background-size: 30px;
                background-repeat: no-repeat;
            }
            /* PRO */

            /*.woocommerce-product-gallery__image .woocommerce-product-gallery__vwg_video .video-js {*/
            /*    background-color: #000;*/
            /*    margin: 0 auto;*/
            /*}*/

            /* Center the play button */
            .vwg_video_js .vjs-big-play-button {
                top: 50% !important;
                left: 50% !important;
                transform: translate(-50%, -50%) !important;
                border-color: <?=esc_attr($iconColor)?> !important;
            }
            /* Replace the default play button with a FontAwesome icon */
            .vwg_video_js .vjs-big-play-button .vjs-icon-placeholder:before {
                content: '\<?=esc_attr($unuCodeIcon)?>';
                font-family: 'Font Awesome 5 Free';
                font-weight: <?=esc_attr($iconWeight)?>;
                font-size: 30px;
                color: <?=esc_attr($iconColor)?>;
            }

            <?php if (isset($adaptSettings) && $adaptSettings == 1) : ?>
            .woocommerce-product-gallery__image .woocommerce-product-gallery__vwg_video video {
                object-fit: cover;
            }

            .woocommerce-product-gallery__image .woocommerce-product-gallery__vwg_video .vjs-fullscreen video {
                object-fit: contain;
            }

            @media only screen and (max-width: 1200px) {
                .woocommerce-product-gallery__image .woocommerce-product-gallery__vwg_video .vwg_video_js {
                    position: relative;
                    width: 100%;
                    padding-top: 133.33%;
                    max-width: 100%;
                    height: 0;
                }
            }
            <?php endif; ?>

        </style>

        <?php if (vwg_active_theme_checker() === 'Flatsome') : ?>
            
        <!-- fix for stacket option -->
        <style>
            .product-gallery-stacked .woocommerce-product-gallery__image[data-vwg-video] {
                position: unset !important;
                margin-top: 1.5em !important;
            }
        </style>
        <!-- fix for stacket option -->
         
        <script>
            jQuery( document ).ready(function($) {
                setInterval(function () {
                    var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || /apple/i.test(navigator.vendor);
                    var $activeVideoSlide = jQuery('.woocommerce-product-gallery__image.is-selected .woocommerce-product-gallery__vwg_video')
                                        
                        // Pause all inactive videos
                        jQuery('.woocommerce-product-gallery__image').each(function() {
                            var $slide = jQuery(this);
                            var isActive = $slide.hasClass('flex-active-slide');
                            var $video = $slide.find('.woocommerce-product-gallery__vwg_video video');
                            
                            if ($video.length > 0) {
                                var videoId = $video.attr('id');
                                var hasAutoplay = $video.attr('autoplay') !== undefined;
                                var hasControls = $video.hasClass('.vjs-controls-enabled');

                                // When video player is initialized
                                if (typeof videojs !== 'undefined' && videoId) {
                                    var player = videojs(videoId);

                                    // Set user active/inactive state based on slide
                                    if (isActive) {
                                        player.options_.inactivityTimeout = 10000; // 10 seconds
                                        player.userActive(true);
                                    } else {
                                        player.userActive(false);
                                    }

                                    if (!hasControls) {
                                        jQuery($slide).on('click', function() {
                                            if (player.paused()) {  
                                                player.play();
                                            } else {
                                                player.pause();
                                            }
                                        });
                                    } 
    
                                    if (hasAutoplay) {
                                        // User became inactive (vjs-user-inactive class added)
                                        player.on('userinactive', function() {
                                            player.pause();
                                        });
    
                                        // User became active (vjs-user-inactive class removed)
                                        player.on('useractive', function() {
                                            player.play();
                                        });

                                        // Video was paused
                                        // player.on('pause', function() {
                                        //     console.log('Video paused');
                                        // });

                                        // Video started playing
                                        // player.on('play', function() {
                                        //     console.log('Video playing');
                                        // });
                                    }
                                }
                            }
                        });
                    
                    if ($activeVideoSlide.length > 0 ) {
                        var vwg_video_ID = jQuery('.woocommerce-product-gallery__image.is-selected').attr('data-vwg-video')
                        var vwg_video_isAutoPlay = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('autoplay')
                        var vwg_video_loop = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('loop')
                        var vwg_video_pause = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('pause')
                        var vwg_user_pause = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('user_pause')
                        var vwg_controls_enabled = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).hasClass('.vjs-controls-enabled')
                        if (isSafari && vwg_video_isAutoPlay && !vwg_video_pause ) {
                            var vwgPlayer = videojs(`vwg_video_js_${vwg_video_ID}`);
                            if (vwg_video_loop) {
                                if(vwg_controls_enabled) {
                                    vwgPlayer.play();
                                } else {
                                    if (!vwg_user_pause) {
                                        vwgPlayer.play();
                                        // Listen for the 'pause' event to detect when the video is paused
                                        vwgPlayer.on('pause', function () {
                                            vwgPlayer.pause();
                                            var posterUrl = vwgPlayer.poster();
                                            if (posterUrl) {
                                                var posterStyle = 'url("' + posterUrl + '")';
                                                vwgPlayer.el().style.display = 'block';
                                                vwgPlayer.el().style.backgroundImage = posterStyle;
                                                vwgPlayer.el().style.backgroundSize = 'cover';
                                                vwgPlayer.el().style.backgroundPosition = 'center';
                                            }
                                            $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('user_pause', 'true');
                                        });
                                    }
                                }
                            } else {
                                vwgPlayer.play();
                                vwgPlayer.on('ended', function () {
                                    vwgPlayer.currentTime(0);
                                    $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('pause', 'true');
                                });
                            }
                        }
                        jQuery('a[href="#product-zoom"]').hide()
                    } else {
                        jQuery('a[href="#product-zoom"]').show()
                    }
                }, 500); // Check every 0.5 seconds

                 /**
                 * Add function fix variable product with option video show first
                 *
                 * @since 1.39
                 */
                <?php if (isset($showFirstClassSettings) && $showFirstClassSettings == 1) : ?>
                    var isFirstLoad = true;
                    
                    // Use event model instead of overwriting WooCommerce functions
                    $(document).ready(function() {
                        setTimeout(function() {
                            // Handle found_variation event
                            $(document).on('found_variation', 'form.variations_form', function(event, variation) {
                                // Modify first slide to show variation image
                                if (variation && variation.image && variation.image.src) {
                                    var $product_gallery = $('.images');
                                    var $product_img_wrap = $product_gallery
                                        .find('.woocommerce-product-gallery__image.vwg_show_first, .woocommerce-product-gallery__image--placeholder.vwg_show_first')
                                        .eq(0);
                                 
                                    var $vwg_video = $product_img_wrap.find('div.vwg_video_js');
                                    var $gallery_first_img_icon = $('.product-thumbnails .flickity-slider').find('div.col.first a i');
                                    
                                    // Hide video and icon
                                    $vwg_video.hide();
                                    $gallery_first_img_icon.hide();
                                    
                                    // Check if we have vwg-test image, if not - create it
                                    var $vwg_custom_img = $product_img_wrap.find('a').find('img.vwg-test');
                                    if (!$vwg_custom_img.length) {
                                        $product_img_wrap.find('a').append('<img class="vwg-test" />');
                                        $vwg_custom_img = $product_img_wrap.find('a').find('img.vwg-test');
                                    }
                                    
                                    // Set image attributes
                                    $vwg_custom_img.attr('src', variation.image.src);
                                    if (variation.image.srcset) {
                                        $vwg_custom_img.attr('srcset', variation.image.srcset);
                                    }
                                    $vwg_custom_img.attr('height', variation.image.src_h);
                                    $vwg_custom_img.attr('width', variation.image.src_w);
                                    $vwg_custom_img.attr('title', variation.image.title || '');
                                    $vwg_custom_img.attr('alt', variation.image.alt || '');
                                    $vwg_custom_img.attr('data-src', variation.image.full_src || '');
                                    $vwg_custom_img.attr('data-large_image', variation.image.full_src || '');                                
                                    
                                    // Resize and zoom after processing
                                    setTimeout(function() {
                                        $(window).trigger('resize');
                                        $product_gallery.trigger('woocommerce_gallery_init_zoom');
                                    }, 20);
                                }
                            });
                            
                            // Handle reset_image event
                            $(document).on('reset_image', 'form.variations_form', function(event) {
                                var $product_gallery = $('.images');
                                var $product_img_wrap = $product_gallery
                                    .find('.woocommerce-product-gallery__image.vwg_show_first, .woocommerce-product-gallery__image--placeholder.vwg_show_first')
                                    .eq(0);
                                
                                var $vwg_video = $product_img_wrap.find('div.vwg_video_js');
                                var $vwg_custom_img = $product_img_wrap.find('a').find('img.vwg-test');
                                var $gallery_first_img_icon = $('.product-thumbnails .flickity-slider').find('div.col.first a i');
                                
                                // Show video and icon again
                                $vwg_video.show();
                                $gallery_first_img_icon.show();
                                
                                // Remove custom image
                                if ($vwg_custom_img.length) {
                                    $vwg_custom_img.remove();
                                }
                                
                                // Additional attempt to show icons
                                setTimeout(function() {
                                    $('.product-thumbnails .flickity-slider').find('div.col.first a i').show();
                                }, 50);
                            });
                            
                            // Handle reset_variations button
                            $(document).on('click', '.reset_variations', function() {
                                var $product_gallery = $('.images');
                                var $product_img_wrap = $product_gallery
                                    .find('.woocommerce-product-gallery__image.vwg_show_first, .woocommerce-product-gallery__image--placeholder.vwg_show_first')
                                    .eq(0);
                                
                                var $vwg_video = $product_img_wrap.find('div.vwg_video_js');
                                var $vwg_custom_img = $product_img_wrap.find('a').find('img.vwg-test');
                                var $gallery_first_img_icon = $('.product-thumbnails .flickity-slider').find('div.col.first a i');
                                
                                // Show video and icon again
                                $vwg_video.show();
                                $gallery_first_img_icon.show();
                                
                                // Remove custom image
                                if ($vwg_custom_img.length) {
                                    $vwg_custom_img.remove();
                                }
                            });
                        }, 500); // Give enough time for WooCommerce to load
                    });
                    <?php endif; ?>

                 // Add vwg-variable class to first element
                if (<?php echo $useDefaultAttrVariable; ?> === 1) {
                    $(document).on('wc_variation_form', function() {
                        setTimeout(function() {
                            $('.product-thumbnails .flickity-slider').find('div.col.first a i').hide();
                        }, 50);
                    });
                }
            });
        </script>

        <?php else: ?>
            <script>
                jQuery( document ).ready(function($) {
                    var li_height;
                    setInterval(function () {
                        jQuery('ol.flex-control-nav').each(function() {
                            jQuery(this).find('li img').each(function(index) {
                                var src = jQuery(this).attr('src');
                                // PRO
                                if (!src.includes('/video-wc-gallery-thumb') && !src.includes('/vwg-optimized-thumbnails') && !src.includes('img.youtube.com')) {
                                    li_height = jQuery(this).height();
                                }
                                // PRO

                                // Check if use default variable value and show first option
                                if (index === 0 ) {
                                    jQuery(this).parent('li').attr('use-default-att-variable', <?php echo esc_attr($useDefaultAttrVariable) ?>)
                                    if (jQuery(this).parent('li').attr('use-default-att-variable') === 1 && jQuery(this).closest('.vwg-video-wrapper').length === 0) {
                                        jQuery(this).wrap(`<div class="vwg-video-wrapper"></div>`);
                                        // PRO
                                        <?php if (isset($proSettings['vwg_settings_custom_svg_icon']) && $proSettings['vwg_settings_custom_svg_icon'] == 1): ?>
                                            jQuery(this).closest('.vwg-video-wrapper').append('<div class="vwg-custom-svg" style="background-image: url(<?= esc_url($proSettings['svg_data']['url']) ?>);"></div>');
                                        <?php else: ?>
                                            jQuery(this).closest('.vwg-video-wrapper').append('<i class="<?= esc_html($icon) ?>"></i>');
                                        <?php endif; ?>
                                        // PRO
                                    }
                                    jQuery(this).closest('.vwg-video-wrapper').css(`height`, `${li_height}px`)
                                }

                                // Check if the src attribute includes '/video-wc-gallery-thumb' or PRO ( '/vwg-optimized-thumbnails' )
                                // PRO
                                if (src.includes('/video-wc-gallery-thumb') || src.includes('/vwg-optimized-thumbnails') || src.includes('img.youtube.com')) {
                                    var vwg_video_wrapper = jQuery(this).closest('.vwg-video-wrapper')
                                    if (vwg_video_wrapper.length === 0) {
                                        jQuery(this).wrap(`<div class="vwg-video-wrapper"></div>`);
                                        <?php if (isset($proSettings['vwg_settings_custom_svg_icon']) && $proSettings['vwg_settings_custom_svg_icon'] == 1): ?>
                                            jQuery(this).closest('.vwg-video-wrapper').append('<div class="vwg-custom-svg" style="background-image: url(<?= esc_url($proSettings['svg_data']['url']) ?>);"></div>');
                                        <?php else: ?>
                                            jQuery(this).closest('.vwg-video-wrapper').append('<i class="<?= esc_html($icon) ?>"></i>');
                                        <?php endif; ?>       
                                    }
                                    jQuery(this).closest('.vwg-video-wrapper').css(`height`, `${li_height}px`)
                                }
                                // PRO
                            });
                        });

                    }, 500); // Check every 0.5 seconds

                    // PRO
                    jQuery(document).on('click touchend', '.vwg-video-wrapper i, .vwg-video-wrapper div.vwg-custom-svg', function(event) {
                        event.preventDefault();
                        if (event.type === 'touchend' || (event.originalEvent && event.originalEvent.touches)) {
                            jQuery(this).prev().trigger('touchend')
                        } else {
                            jQuery(this).prev().trigger('click');
                        }
                    });
                    // PRO

                    setInterval(function () {
                        var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || /apple/i.test(navigator.vendor);
                        var $activeVideoSlide = jQuery('.woocommerce-product-gallery__image.flex-active-slide .woocommerce-product-gallery__vwg_video')
                                                
                        // Pause all inactive videos
                        jQuery('.woocommerce-product-gallery__image').each(function() {
                            var $slide = jQuery(this);
                            var isActive = $slide.hasClass('flex-active-slide');
                            var $video = $slide.find('.woocommerce-product-gallery__vwg_video video');
                            
                            if ($video.length > 0) {
                                var videoId = $video.attr('id');
                                var hasAutoplay = $video.attr('autoplay') !== undefined;
                                var hasControls = $video.hasClass('.vjs-controls-enabled');

                                // When video player is initialized
                                if (typeof videojs !== 'undefined' && videoId) {
                                    var player = videojs(videoId);

                                    // Set user active/inactive state based on slide
                                    if (isActive) {
                                        player.options_.inactivityTimeout = 10000; // 10 seconds
                                        player.userActive(true);
                                    } else {
                                        player.userActive(false);
                                    }

                                    if (!hasControls) {
                                        jQuery($slide).on('click', function() {
                                            if (player.paused()) {  
                                                player.play();
                                            } else {
                                                player.pause();
                                            }
                                        });
                                    } 
    
                                    if (hasAutoplay) {
                                        // User became inactive (vjs-user-inactive class added)
                                        player.on('userinactive', function() {
                                            player.pause();
                                        });
    
                                        // User became active (vjs-user-inactive class removed)
                                        player.on('useractive', function() {
                                            player.play();
                                        });

                                        // Video was paused
                                        // player.on('pause', function() {
                                        //     console.log('Video paused');
                                        // });

                                        // Video started playing
                                        // player.on('play', function() {
                                        //     console.log('Video playing');
                                        // });
                                    }
                                }
                            }
                        });
    
                        if ($activeVideoSlide.length > 0 ) {
                            var vwg_video_ID = jQuery('.woocommerce-product-gallery__image.flex-active-slide').attr('data-vwg-video')
                            var vwg_video_isAutoPlay = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('autoplay')
                            var vwg_video_loop = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('loop')
                            var vwg_video_pause = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('pause')
                            var vwg_user_pause = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('user_pause')
                            var vwg_controls_enabled = $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).hasClass('.vjs-controls-enabled')
                            if (isSafari && vwg_video_isAutoPlay && !vwg_video_pause ) {
                                var vwgPlayer = videojs(`vwg_video_js_${vwg_video_ID}`);
                                if (vwg_video_loop) {
                                    if(vwg_controls_enabled) {
                                        vwgPlayer.play();
                                    } else {
                                        if (!vwg_user_pause) {
                                            vwgPlayer.play();
                                            // Listen for the 'pause' event to detect when the video is paused
                                            vwgPlayer.on('pause', function () {
                                                vwgPlayer.pause();
                                                var posterUrl = vwgPlayer.poster();
                                                if (posterUrl) {
                                                    var posterStyle = 'url("' + posterUrl + '")';
                                                    vwgPlayer.el().style.display = 'block';
                                                    vwgPlayer.el().style.backgroundImage = posterStyle;
                                                    vwgPlayer.el().style.backgroundSize = 'cover';
                                                    vwgPlayer.el().style.backgroundPosition = 'center';
                                                }
                                                $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('user_pause', 'true');
                                            });
                                        }
                                    }
                                } else {
                                    vwgPlayer.play();
                                    vwgPlayer.on('ended', function () {
                                        vwgPlayer.currentTime(0);
                                        $activeVideoSlide.find(`#vwg_video_js_${vwg_video_ID}`).attr('pause', 'true');
                                    });
                                }
                            }
                            jQuery('.woocommerce-product-gallery__trigger').hide()
                        } else {
                            jQuery('.woocommerce-product-gallery__trigger').show()
                        }
                    }, 500); // Check every 0.5 seconds

                     /**
                     * Add function fix variable product with option video show first
                     *
                     * @since 1.40
                     */
                    <?php if (isset($showFirstClassSettings) && $showFirstClassSettings == 1) : ?>
                    var isFirstLoad = true;
                    $.fn.wc_variations_image_update = function(variation) {
                        var $form             = this,
                            $product          = $form.closest('.product'),
                            $product_gallery  = $product.find('.images'),
                            $gallery_nav      = $product.find('.flex-control-nav'),
                            $gallery_img      = $gallery_nav.find('li:not(:has(div.vwg-video-wrapper)):eq(0) img'),
                            $product_img_wrap = $product_gallery
                                .find('.woocommerce-product-gallery__image:not(.vwg_show_first), .woocommerce-product-gallery__image--placeholder:not(.vwg_show_first)')
                                .eq(0),
                            $product_img      = $product_img_wrap.find('.wp-post-image'),
                            $product_link     = $product_img_wrap.find('a').eq(0);

                        if (variation && variation.image && variation.image.src && variation.image.src.length > 1) {
                            // Update main image
                            $product_img.wc_set_variation_attr('src', variation.image.src);
                            $product_img.wc_set_variation_attr('height', variation.image.src_h);
                            $product_img.wc_set_variation_attr('width', variation.image.src_w);
                            $product_img.wc_set_variation_attr('srcset', variation.image.srcset);
                            $product_img.wc_set_variation_attr('sizes', variation.image.sizes);
                            $product_img.wc_set_variation_attr('title', variation.image.title);
                            $product_img.wc_set_variation_attr('data-caption', variation.image.caption);
                            $product_img.wc_set_variation_attr('alt', variation.image.alt);
                            $product_img.wc_set_variation_attr('data-src', variation.image.full_src);
                            $product_img.wc_set_variation_attr('data-large_image', variation.image.full_src);
                            $product_img.wc_set_variation_attr('data-large_image_width', variation.image.full_src_w);
                            $product_img.wc_set_variation_attr('data-large_image_height', variation.image.full_src_h);
                            $product_img_wrap.wc_set_variation_attr('data-thumb', variation.image.src);
                            $product_link.wc_set_variation_attr('href', variation.image.full_src);
                            $product_img_wrap.addClass('vwg-variation-image-changed');

                            window.setTimeout(function() {
                                // Clear previous executions
                                clearTimeout(window.vwgClickTimeout);
                                
                                var $flexSlider = $('.woocommerce-product-gallery').data('flexslider');
                                if ($flexSlider && $flexSlider.slides) {
                                    var slideIndex = -1;
                                    $($flexSlider.slides).each(function(index) {
                                        if ($(this).hasClass('vwg-variation-image-changed')) {
                                            slideIndex = index;
                                            return false;
                                        }
                                    });
                                    
                                    if (slideIndex >= 0) {
                                        // Activate the variation slide
                                        $flexSlider.flexAnimate(slideIndex, true);
                                    }
                                }
                                
                                // Trigger resize and zoom after processing
                                $(window).trigger('resize');
                                $product_gallery.trigger('woocommerce_gallery_init_zoom');
                            }, 100);
                        } else {
                            $form.wc_variations_image_reset();
                        }
                    };

                    $.fn.wc_variations_image_reset = function() {
                        var $form             = this,
                            $product          = $form.closest('.product'),
                            $product_gallery  = $product.find('.images'),
                            $product_img_wrap = $product_gallery
                                .find('.woocommerce-product-gallery__image:not(.vwg_show_first), .woocommerce-product-gallery__image--placeholder:not(.vwg_show_first)')
                                .eq(0),
                            $product_img      = $product_img_wrap.find('.wp-post-image'),
                            $product_link     = $product_img_wrap.find('a').eq(0);

                        // Reset all variation attributes
                        $product_img.wc_reset_variation_attr('src');
                        $product_img.wc_reset_variation_attr('width');
                        $product_img.wc_reset_variation_attr('height');
                        $product_img.wc_reset_variation_attr('srcset');
                        $product_img.wc_reset_variation_attr('sizes');
                        $product_img.wc_reset_variation_attr('title');
                        $product_img.wc_reset_variation_attr('data-caption');
                        $product_img.wc_reset_variation_attr('alt');
                        $product_img.wc_reset_variation_attr('data-src');
                        $product_img.wc_reset_variation_attr('data-large_image');
                        $product_img.wc_reset_variation_attr('data-large_image_width');
                        $product_img.wc_reset_variation_attr('data-large_image_height');
                        $product_img_wrap.wc_reset_variation_attr('data-thumb');
                        $product_link.wc_reset_variation_attr('href');
                        $product_img_wrap.removeClass('vwg-variation-image-changed');
                    };
                    <?php endif; ?>

                });
            </script>
        <?php endif; ?>

        <script>
            jQuery( document ).ready(function($) {
                // Fix if have problem with first loading classes
                if ( jQuery('.vwg_video_js').attr('autoplay') && !jQuery('.vwg_video_js').hasClass('.vjs-has-started')) {
                    jQuery('.vwg_video_js').addClass('vjs-has-started')
                } else if (!jQuery('.vwg_video_js').attr('autoplay') && !jQuery('.vwg_video_js').hasClass('.vjs-has-started')) {
                    jQuery(document).on('click touchend', '.vwg_video_js .vjs-big-play-button', function(event) {
                        event.preventDefault();
                        jQuery('.vwg_video_js').addClass('vjs-has-started')
                    });
                }
            });
        </script>

        <?php if ( $use_webp ) : ?>
        <script>
        (function(){
            function toWebp(val){
                if(!val) return val;
                return val.replace(/video-wc-gallery-thumb\/([^"'()\s]+)\.png/gi, 'vwg-optimized-thumbnails/$1.webp');
            }
            function swapSrcset(el){
                var ss = el.getAttribute('srcset');
                if(!ss) return;
                var parts = ss.split(',');
                var changed = false;
                for(var i=0;i<parts.length;i++){
                    var seg = parts[i].trim();
                    var sp = seg.split(/\s+/);
                    if(sp.length>0){
                        var nv = toWebp(sp[0]);
                        if(nv !== sp[0]){
                            sp[0]=nv; changed=true;
                            parts[i]=sp.join(' ');
                        }
                    }
                }
                if(changed){
                    el.setAttribute('srcset', parts.join(', '));
                }
            }
            function swapAttrs(el, attrs){
                attrs.forEach(function(a){
                    var v = el.getAttribute(a);
                    if(!v) return;
                    var nv = toWebp(v);
                    if(nv !== v){ el.setAttribute(a, nv); }
                });
            }
            function swapStyle(el){
                var st = el.getAttribute('style');
                if(!st) return;
                var ns = toWebp(st);
                if(ns !== st){ el.setAttribute('style', ns); }
            }
            function runWebpSwap(){
                var root = document.querySelector('.woocommerce-product-gallery');
                if(!root) return;
                var nodes = root.querySelectorAll('img, source, video, [poster], [style], .vjs-poster');
                nodes.forEach(function(el){
                    swapAttrs(el, ['src','data-src','data-large_image','data-thumb','poster','data-woocommerce_gallery_thumbnail_url','data-woocommerce_thumbnail_url']);
                    swapSrcset(el);
                    swapStyle(el);
                });
            }
            function setupObserver(){
                var root = document.querySelector('.woocommerce-product-gallery');
                if(!root) return;
                var mo = new MutationObserver(function(){
                    runWebpSwap();
                });
                mo.observe(root, { childList:true, subtree:true, attributes:true, attributeFilter:['src','srcset','data-src','poster','style'] });
            }
            if(document.readyState === 'loading'){
                document.addEventListener('DOMContentLoaded', function(){
                    runWebpSwap();
                    setupObserver();
                    setTimeout(runWebpSwap, 300);
                    setTimeout(runWebpSwap, 1200);
                });
            } else {
                runWebpSwap();
                setupObserver();
                setTimeout(runWebpSwap, 300);
                setTimeout(runWebpSwap, 1200);
            }
        })();
        </script>
        <?php endif; ?>

        <?php
        global $product;
        $video_url = get_post_meta( $product->get_id(), 'vwg_video_url', true );
        $video_urls = maybe_unserialize($video_url);
        $product_main_image =  wp_get_attachment_image_src($product->get_image_id(), 'woocommerce_single');
        if (is_array($product_main_image)) {
            if (isset($product_main_image[1]) && isset($product_main_image[2])) {
                $width = $product_main_image[1];
                $height = $product_main_image[2];
            }
        }

        if ( $video_url ) {
            $countVideo = 0;
            // PRO
            foreach ($video_urls as $video) :
                $countVideo++;
                ?>
                <script type="application/ld+json">
                    {
                    "@context": "http://schema.org",
                    "@type": "VideoObject",
                    "name": "<?php 
                        $seo_settings = get_post_meta($product->get_id(), 'vwg_video_seo_settings', true);
                        $video_id = array_keys($video_urls)[$countVideo-1];
                        if (is_array($seo_settings) && isset($seo_settings[$video_id]) && !empty($seo_settings[$video_id]['video_title'])) {
                            echo esc_attr($seo_settings[$video_id]['video_title']);
                        } else {
                            echo esc_attr($product->get_name() . ' Video - ' . esc_attr($countVideo));
                        }
                    ?>",
                    "description": "<?php 
                        if (is_array($seo_settings) && isset($seo_settings[$video_id]) && !empty($seo_settings[$video_id]['video_description'])) {
                            echo esc_attr($seo_settings[$video_id]['video_description']);
                        } else {
                            echo esc_attr($product->get_short_description());
                        }
                    ?>",
                    "thumbnailUrl": "<?=esc_url($video['video_thumb_url']) ?>",
                    "contentUrl": "<?=esc_url($video['video_url']) ?>",
                    "encodingFormat": "<?php 
                        if (is_array($seo_settings) && isset($seo_settings[$video_id]) && !empty($seo_settings[$video_id]['video_encoding_format'])) {
                            echo esc_attr($seo_settings[$video_id]['video_encoding_format']);
                        } else {
                            echo 'video/mp4';
                        }
                    ?>",
                    "width": "<?=esc_attr($width) ?>",
                    "height": "<?=esc_attr($height) ?>",
                    "uploadDate": "<?php 
                        if (is_array($seo_settings) && isset($seo_settings[$video_id]) && !empty($seo_settings[$video_id]['video_upload_date'])) {
                            echo esc_attr($seo_settings[$video_id]['video_upload_date']);
                        } else {
                            echo esc_attr(date('c', strtotime($product->get_date_created()->date('Y-m-d H:i:s'))));
                        }
                    ?>",
                    "duration": "<?php 
                        if (is_array($seo_settings) && isset($seo_settings[$video_id]) && !empty($seo_settings[$video_id]['video_duration'])) {
                            echo esc_attr($seo_settings[$video_id]['video_duration']);
                        } else {
                            echo 'PT1M30S';
                        }
                    ?>"
                }
                </script>
            <?php endforeach;
            // PRO
        }

    }
}