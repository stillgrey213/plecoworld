<?php
/**
 * SEO Settings functionality for Video Gallery for WooCommerce PRO
 *
 * @package     VideoWCGalleryPro
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Generates HTML code for the SEO modal
 *
 * @since 1.0
 * @return string HTML code for the SEO modal window
 */
function vwg_pro_seo_modal_html() {
    ob_start();
    ?>
    <!-- SEO Modal PRO Version - This modal replaces the basic modal in the free version -->
    <div id="vwg-seo-modal" class="vwg-modal vwg-pro-modal">
        <div class="vwg-modal-content">
            <div class="vwg-modal-header">
                <h3><?php echo esc_html__('Video SEO Settings', 'video-wc-gallery-pro'); ?></h3>
                <span class="vwg-modal-close">&times;</span>
            </div>
            <div class="vwg-modal-body">
                <div class="vwg-seo-form">
                    <div class="form-group">
                        <label for="video_title_field"><?php echo esc_html__('Title', 'video-wc-gallery-pro'); ?></label>
                        <input type="text" id="video_title_field" placeholder="<?php echo esc_attr__('Enter video title', 'video-wc-gallery-pro'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="video_description_field"><?php echo esc_html__('Description', 'video-wc-gallery-pro'); ?></label>
                        <textarea id="video_description_field" placeholder="<?php echo esc_attr__('Enter video description', 'video-wc-gallery-pro'); ?>"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="video_upload_date"><?php echo esc_html__('Upload Date', 'video-wc-gallery-pro'); ?></label>
                        <input type="datetime-local" id="video_upload_date" placeholder="<?php echo esc_attr__('Select upload date', 'video-wc-gallery-pro'); ?>">
                        <p class="field-description"><?php echo esc_html__('The format will be saved as: 2020-10-26T18:15:46+00:00', 'video-wc-gallery-pro'); ?></p>
                    </div>
                    <div class="form-group duration-group">
                        <label><?php echo esc_html__('Duration', 'video-wc-gallery-pro'); ?></label>
                        <div class="duration-inputs">
                            <div class="duration-field">
                                <input type="number" id="video_duration_minutes" min="0" max="999" placeholder="<?php echo esc_attr__('min', 'video-wc-gallery-pro'); ?>">
                                <span class="duration-label"><?php echo esc_html__('minutes', 'video-wc-gallery-pro'); ?></span>
                            </div>
                            <div class="duration-field">
                                <input type="number" id="video_duration_seconds" min="0" max="59" placeholder="<?php echo esc_attr__('sec', 'video-wc-gallery-pro'); ?>">
                                <span class="duration-label"><?php echo esc_html__('seconds', 'video-wc-gallery-pro'); ?></span>
                            </div>
                        </div>
                        <p class="field-description"><?php echo esc_html__('The format will be saved as: PT1M30S', 'video-wc-gallery-pro'); ?></p>
                        <input type="hidden" id="video_duration_field">
                    </div>
                    <div class="form-group">
                        <label for="video_encoding_format"><?php echo esc_html__('Encoding Format', 'video-wc-gallery-pro'); ?></label>
                        <select id="video_encoding_format">
                            <option value="video/mp4"><?php echo esc_html__('video/mp4', 'video-wc-gallery-pro'); ?></option>
                            <option value="video/mov"><?php echo esc_html__('video/mov', 'video-wc-gallery-pro'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="vwg-modal-footer">
                <button type="button" class="button reset-seo-settings"><?php echo esc_html__('Reset', 'video-wc-gallery-pro'); ?></button>
                <button type="button" class="button vwg-modal-close"><?php echo esc_html__('Cancel', 'video-wc-gallery-pro'); ?></button>
                <button type="button" class="button button-primary" id="save-seo-settings"><?php echo esc_html__('Save', 'video-wc-gallery-pro'); ?></button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Adds JavaScript functionality for the SEO modal
 *
 * @since 1.0
 */
function vwg_pro_seo_modal_scripts() {
    ?>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // SEO button functionality - PRO version
        $(document).on('click', '.action-btn.seo-btn', function() {
            var videoID = $(this).data('video-id');
            var videoItem = $(`.video_id_${videoID}`);
            var video_title = videoItem.find('.video_title').val() || '';
            var video_description = videoItem.find('.video_description').val() || '';
            var video_upload_date = videoItem.find('.video_upload_date').val() || '';
            var video_duration = videoItem.find('.video_duration').val() || '';
            var video_encoding_format = videoItem.find('.video_encoding_format').val() || 'video/mp4';
            
            // Load SEO settings from the server
            var postID = $('#post_ID').val();
            var data = {
                action: 'vwg_load_video_seo_settings',
                post_id: postID,
                video_id: videoID,
                nonce: '<?php echo wp_create_nonce('vwg_load_video_seo_settings_nonce'); ?>'
            };
            
            $.post(ajaxurl, data, function(response) {
                if (response.success && response.data) {
                    // If there are saved settings, update the fields
                    if (response.data.video_title) {
                        video_title = response.data.video_title;
                    }
                    if (response.data.video_description) {
                        video_description = response.data.video_description;
                    }
                    if (response.data.video_upload_date) {
                        video_upload_date = response.data.video_upload_date;
                        // Convert format for input datetime-local
                        try {
                            var date = new Date(response.data.video_upload_date);
                            video_upload_date = date.toISOString().slice(0, 16);
                        } catch (e) {
                            console.error('Error parsing date', e);
                        }
                    }
                    if (response.data.video_duration) {
                        video_duration = response.data.video_duration;
                        // Parse the PT1M30S format and extract minutes and seconds
                        try {
                            var durationMinutes = 0;
                            var durationSeconds = 0;
                            
                            if (video_duration) {
                                var minutesMatch = video_duration.match(/(\d+)M/);
                                var secondsMatch = video_duration.match(/(\d+)S/);
                                
                                if (minutesMatch && minutesMatch[1]) {
                                    durationMinutes = parseInt(minutesMatch[1]);
                                }
                                
                                if (secondsMatch && secondsMatch[1]) {
                                    durationSeconds = parseInt(secondsMatch[1]);
                                }
                            }
                            
                            $('#video_duration_minutes').val(durationMinutes);
                            $('#video_duration_seconds').val(durationSeconds);
                        } catch (e) {
                            console.error('Error parsing duration', e);
                        }
                    }
                    if (response.data.video_encoding_format) {
                        video_encoding_format = response.data.video_encoding_format;
                    }
                }
                
                // Open the SEO modal window and fill in the fields
                $('#vwg-seo-modal').data('video-id', videoID);
                $('#video_title_field').val(video_title);
                $('#video_description_field').val(video_description);
                $('#video_upload_date').val(video_upload_date);
                $('#video_encoding_format').val(video_encoding_format);
                
                // Update the hidden duration field
                updateDurationField();
                
                $('#vwg-seo-modal').show();
            });
        });
        
        // Function to update the hidden duration field
        function updateDurationField() {
            var minutes = parseInt($('#video_duration_minutes').val()) || 0;
            var seconds = parseInt($('#video_duration_seconds').val()) || 0;
            var durationFormat = 'PT';
            
            if (minutes > 0) {
                durationFormat += minutes + 'M';
            }
            
            if (seconds > 0) {
                durationFormat += seconds + 'S';
            } else if (durationFormat === 'PT') {
                // If there are no minutes and seconds, set at least 0 seconds
                durationFormat += '0S';
            } else if (minutes > 0 && seconds === 0) {
                // If we have minutes but no seconds, add 0S to make the format complete
                durationFormat += '0S';
            }
            
            $('#video_duration_field').val(durationFormat);
        }
        
        // Update the hidden duration field whenever minutes or seconds change
        $('#video_duration_minutes, #video_duration_seconds').on('input', function() {
            updateDurationField();
        });
        
        // Modal close functionality
        $('.vwg-modal-close').on('click', function() {
            $(this).closest('.vwg-modal').hide();
        });
        
        // Click outside modal to close
        $(window).on('click', function(event) {
            if ($(event.target).hasClass('vwg-modal')) {
                $('.vwg-modal').hide();
            }
        });
        
        // Save SEO settings
        $('#save-seo-settings').on('click', function() {
            var videoID = $('#vwg-seo-modal').data('video-id');
            var videoItem = $(`.video_id_${videoID}`);
            var video_title = $('#video_title_field').val();
            var video_description = $('#video_description_field').val();
            var video_upload_date = $('#video_upload_date').val();
            var video_duration = $('#video_duration_field').val();
            var video_encoding_format = $('#video_encoding_format').val();
            
            // Format date to ISO format
            if (video_upload_date) {
                try {
                    var date = new Date(video_upload_date);
                    video_upload_date = date.toISOString();
                } catch (e) {
                    console.error('Error formatting date', e);
                }
            }
            
            // Save values to hidden fields in the video element
            videoItem.find('.video_title').val(video_title);
            videoItem.find('.video_description').val(video_description);
            
            // Add hidden fields for new values if they don't exist
            if (videoItem.find('.video_upload_date').length === 0) {
                videoItem.append(`<input type="hidden" class="video_upload_date" name="video_url[${videoID}][video_upload_date]" value="${video_upload_date}"/>`);
            } else {
                videoItem.find('.video_upload_date').val(video_upload_date);
            }
            
            if (videoItem.find('.video_duration').length === 0) {
                videoItem.append(`<input type="hidden" class="video_duration" name="video_url[${videoID}][video_duration]" value="${video_duration}"/>`);
            } else {
                videoItem.find('.video_duration').val(video_duration);
            }
            
            if (videoItem.find('.video_encoding_format').length === 0) {
                videoItem.append(`<input type="hidden" class="video_encoding_format" name="video_url[${videoID}][video_encoding_format]" value="${video_encoding_format}"/>`);
            } else {
                videoItem.find('.video_encoding_format').val(video_encoding_format);
            }
            
            $('#vwg-seo-modal').hide();
            
            // Show a short success message
            Swal.fire({
                title: '<?php echo esc_js(__('Saved!', 'video-wc-gallery-pro')); ?>',
                text: '<?php echo esc_js(__('SEO settings have been saved successfully.', 'video-wc-gallery-pro')); ?>',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false,
                background: '#fff'
            });
            
            // Send AJAX request to save SEO settings
            var postID = $('#post_ID').val();
            var data = {
                action: 'vwg_save_video_seo_settings',
                post_id: postID,
                video_id: videoID,
                video_title: video_title,
                video_description: video_description,
                video_upload_date: video_upload_date,
                video_duration: video_duration,
                video_encoding_format: video_encoding_format,
                nonce: '<?php echo wp_create_nonce('vwg_save_video_seo_settings_nonce'); ?>'
            };
            
            $.post(ajaxurl, data, function(response) {
                if (response.success) {
                    console.log('SEO settings saved via AJAX');
                } else {
                    console.error('Error saving SEO settings');
                }
            });
        });
        
        // Reset SEO settings
        $('.reset-seo-settings').on('click', function() {
            // First hide the modal to prevent the confirmation dialog from appearing under it
            $('#vwg-seo-modal').hide();
            
            // Show confirmation before deleting data
            Swal.fire({
                title: '<?php echo esc_js(__('Are you sure?', 'video-wc-gallery-pro')); ?>',
                text: '<?php echo esc_js(__('This operation will delete all SEO settings for this video!', 'video-wc-gallery-pro')); ?>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: '<?php echo esc_js(__('Yes, delete!', 'video-wc-gallery-pro')); ?>',
                cancelButtonText: '<?php echo esc_js(__('Cancel', 'video-wc-gallery-pro')); ?>',
                allowOutsideClick: false
            }).then((result) => {
                if (result.isConfirmed) {
                    var videoID = $('#vwg-seo-modal').data('video-id');
                    var postID = $('#post_ID').val();
                    
                    // Reset fields in the form
                    $('#video_title_field').val('');
                    $('#video_description_field').val('');
                    $('#video_upload_date').val('');
                    $('#video_duration_minutes').val('');
                    $('#video_duration_seconds').val('');
                    $('#video_duration_field').val('');
                    $('#video_encoding_format').val('video/mp4');
                    
                    // Send AJAX request to delete SEO settings
                    var data = {
                        action: 'vwg_reset_video_seo_settings',
                        post_id: postID,
                        video_id: videoID,
                        nonce: '<?php echo wp_create_nonce('vwg_reset_video_seo_settings_nonce'); ?>'
                    };
                    
                    $.post(ajaxurl, data, function(response) {
                        if (response.success) {
                            // Show successful deletion notification
                            Swal.fire({
                                title: '<?php echo esc_js(__('Deleted!', 'video-wc-gallery-pro')); ?>',
                                text: response.data,
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            });
                            
                            // Delete hidden fields of video element
                            var videoItem = $(`.video_id_${videoID}`);
                            videoItem.find('.video_title').val('');
                            videoItem.find('.video_description').val('');
                            videoItem.find('.video_upload_date').val('');
                            videoItem.find('.video_duration').val('');
                            videoItem.find('.video_encoding_format').val('video/mp4');
                        } else {
                            // Show error message
                            Swal.fire({
                                title: '<?php echo esc_js(__('Error!', 'video-wc-gallery-pro')); ?>',
                                text: response.data,
                                icon: 'error'
                            });
                        }
                    });
                } else {
                    // If user cancels, show the modal again
                    $('#vwg-seo-modal').show();
                }
            });
        });
        
        // Add custom styles to ensure SweetAlert appears in front of other modals
        $('<style>.swal2-container { z-index: 99999 !important; }</style>').appendTo('head');
    });
    </script>
    <?php
}

/**
 * Filter to add SEO modal
 *
 * @since 1.0
 * @param string $content HTML content, to which to add the modal
 * @return string Modified HTML content with added modal
 */
function vwg_pro_add_seo_modal($content) {
    $modal_html = vwg_pro_seo_modal_html();
    return $content . $modal_html;
}

/**
 * AJAX function to save SEO settings
 *
 * @since 1.0
 */
function vwg_pro_save_video_seo_settings() {
    // Security check
    check_ajax_referer('vwg_save_video_seo_settings_nonce', 'nonce');
    
    // Security check for administrative privileges
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('You do not have sufficient privileges for this operation.');
        return;
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $video_id = isset($_POST['video_id']) ? sanitize_text_field($_POST['video_id']) : '';
    $video_title = isset($_POST['video_title']) ? sanitize_text_field($_POST['video_title']) : '';
    $video_description = isset($_POST['video_description']) ? sanitize_textarea_field($_POST['video_description']) : '';
    $video_upload_date = isset($_POST['video_upload_date']) ? sanitize_text_field($_POST['video_upload_date']) : '';
    $video_duration = isset($_POST['video_duration']) ? sanitize_text_field($_POST['video_duration']) : '';
    $video_encoding_format = isset($_POST['video_encoding_format']) ? sanitize_text_field($_POST['video_encoding_format']) : '';
    
    if (!$post_id || !$video_id) {
        wp_send_json_error('Invalid data.');
        return;
    }
    
    // Get current SEO settings
    $seo_settings = get_post_meta($post_id, 'vwg_video_seo_settings', true);
    if (!is_array($seo_settings)) {
        $seo_settings = array();
    }
    
    // Update settings for specific video
    $seo_settings[$video_id] = array(
        'video_id' => $video_id,
        'video_title' => $video_title,
        'video_description' => $video_description,
        'video_upload_date' => $video_upload_date,
        'video_duration' => $video_duration,
        'video_encoding_format' => $video_encoding_format
    );
    
    // Save settings
    update_post_meta($post_id, 'vwg_video_seo_settings', $seo_settings);
    
    wp_send_json_success('SEO settings have been saved successfully.');
}

/**
 * AJAX function to load SEO settings
 *
 * @since 1.0
 */
function vwg_pro_load_video_seo_settings() {
    // Security check
    check_ajax_referer('vwg_load_video_seo_settings_nonce', 'nonce');
    
    // Security check for administrative privileges
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('You do not have sufficient privileges for this operation.');
        return;
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $video_id = isset($_POST['video_id']) ? sanitize_text_field($_POST['video_id']) : '';
    
    if (!$post_id || !$video_id) {
        wp_send_json_error('Invalid data.');
        return;
    }
    
    // Get current SEO settings
    $seo_settings = get_post_meta($post_id, 'vwg_video_seo_settings', true);
    if (!is_array($seo_settings) || !isset($seo_settings[$video_id])) {
        wp_send_json_success(array()); // No settings, return empty array
        return;
    }
    
    // Return settings for specific video
    wp_send_json_success($seo_settings[$video_id]);
}

/**
 * AJAX function to reset SEO settings for a specific video
 *
 * @since 1.0
 */
function vwg_pro_reset_video_seo_settings() {
    // Security check
    check_ajax_referer('vwg_reset_video_seo_settings_nonce', 'nonce');
    
    // Security check for administrative privileges
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('You do not have sufficient privileges for this operation.');
        return;
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $video_id = isset($_POST['video_id']) ? sanitize_text_field($_POST['video_id']) : '';
    
    if (!$post_id || !$video_id) {
        wp_send_json_error('Invalid data.');
        return;
    }
    
    // Get current SEO settings
    $seo_settings = get_post_meta($post_id, 'vwg_video_seo_settings', true);
    
    if (!is_array($seo_settings)) {
        wp_send_json_success('No SEO settings found to delete.');
        return;
    }
    
    // Remove settings for specific video
    if (isset($seo_settings[$video_id])) {
        unset($seo_settings[$video_id]);
        
        // Update meta field without deleted data
        update_post_meta($post_id, 'vwg_video_seo_settings', $seo_settings);
        
        wp_send_json_success('SEO settings have been deleted successfully.');
    } else {
        wp_send_json_success('No SEO settings found for this video.');
    }
}

// Register AJAX actions
add_action('wp_ajax_vwg_save_video_seo_settings', 'vwg_pro_save_video_seo_settings');
add_action('wp_ajax_vwg_load_video_seo_settings', 'vwg_pro_load_video_seo_settings');
add_action('wp_ajax_vwg_reset_video_seo_settings', 'vwg_pro_reset_video_seo_settings');

// Register hooks for SEO modal
add_filter('vwg_after_video_gallery_content', 'vwg_pro_add_seo_modal');
add_action('admin_footer-post.php', 'vwg_pro_seo_modal_scripts');
add_action('admin_footer-post-new.php', 'vwg_pro_seo_modal_scripts'); 