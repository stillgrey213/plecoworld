<?php
/**
 * Image Optimization functionality for Video Gallery for WooCommerce PRO
 *
 * @package     VideoWCGalleryPro
 * @since       1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Optimize and convert images
 *
 * @since 1.0
 */
function optimize_and_convert_images() {
    // Check for nonce security
    check_ajax_referer('image_optimize_nonce', 'nonce');

    // Check if either Imagick or GD library is available
    if ( ! extension_loaded('imagick') && ! extension_loaded('gd') ) {
        wp_send_json_error('Neither Imagick nor GD library is available. Please enable either of those 2 libraries on your server');
        return;
    }

    // Path to the directory containing images
    $upload_dir = wp_upload_dir();
    $images_dir = $upload_dir['basedir'] . '/video-wc-gallery-thumb/';
    $optimized_dir = $upload_dir['basedir'] . '/vwg-optimized-thumbnails/';

    // Create the optimized directory if it doesn't exist
    if ( ! is_dir($optimized_dir) ) {
        wp_mkdir_p($optimized_dir);
    }

    if ( ! is_dir($images_dir) ) {
        wp_send_json_error('Directory does not exist.');
        return;
    }

    // Get all image files in the directory
    $images = glob($images_dir . '*.{jpg,jpeg,png}', GLOB_BRACE);

    if ( empty($images) ) {
        wp_send_json_error('No images found in the directory.');
        return;
    }

    // Get the total number of images
    $total_images = count($images);
    $current_index = isset($_POST['current_index']) ? intval($_POST['current_index']) : 0;

    if ( $current_index >= $total_images ) {
        wp_send_json_success('All images have been optimized and converted to WebP.');
        return;
    }

    // Process the current image
    $image = $images[$current_index];
    $image_info = pathinfo($image);
    $webp_image = $optimized_dir . $image_info['filename'] . '.webp';

    // Check if Imagick is available
    if ( extension_loaded('imagick') ) {
        try {
            $imagick = new Imagick($image);
            $imagick->setImageFormat('webp');
            $imagick->setImageCompressionQuality(80);
            $imagick->writeImage($webp_image);
            $imagick->clear();
            $imagick->destroy();
        } catch (Exception $e) {
            wp_send_json_error('Error processing image with Imagick: ' . $image_info['basename']);
            return;
        }
    } else {
        // Fall back to GD library if Imagick is not available
        $img = null;
        if ( $image_info['extension'] == 'jpg' || $image_info['extension'] == 'jpeg' ) {
            $img = imagecreatefromjpeg($image);
        } elseif ( $image_info['extension'] == 'png' ) {
            $img = imagecreatefrompng($image);
        }

        if ( $img ) {
            imagewebp($img, $webp_image, 80); // 80 is the quality for WebP
            imagedestroy($img);
        } else {
            wp_send_json_error('Error processing image with GD library: ' . $image_info['basename']);
            return;
        }
    }

    // Calculate the progress percentage
    $progress = ($current_index + 1) / $total_images * 100;

    // Return the progress and additional info
    wp_send_json_success(array(
        'message' => 'Images are being optimized and converted to WebP.',
        'progress' => (int)$progress,
        'current_index' => $current_index + 1,
        'total_images' => $total_images,
        'current_filename' => $image_info['basename']
    ));
}
add_action('wp_ajax_optimize_and_convert_images', 'optimize_and_convert_images');
add_action('wp_ajax_nopriv_optimize_and_convert_images', 'optimize_and_convert_images');

/**
 * Delete optimized files
 *
 * @since 1.0
 */
function delete_optimized_files() {
    // Check for nonce security
    check_ajax_referer('image_optimize_nonce', 'nonce');

    // Path to the optimized directory
    $upload_dir = wp_upload_dir();
    $optimized_dir = $upload_dir['basedir'] . '/vwg-optimized-thumbnails/';

    // Check if the directory exists
    if ( ! is_dir($optimized_dir) ) {
        wp_send_json_error('Optimized directory does not exist.');
        return;
    }

    // Get all files in the optimized directory
    $files = glob($optimized_dir . '*');

    if ( empty($files) ) {
        wp_send_json_error('No files found in the optimized directory.');
        return;
    }

    // Delete all files
    foreach ( $files as $file ) {
        if ( is_file($file) ) {
            unlink($file);
        }
    }

    wp_send_json_success('All optimized files have been deleted.');
}
add_action('wp_ajax_delete_optimized_files', 'delete_optimized_files');
add_action('wp_ajax_nopriv_delete_optimized_files', 'delete_optimized_files');

/**
 * Replace product thumbnails with webp
 *
 * @since 1.2
 */
function replace_product_thumbnails_with_webp($html, $attachment_id = null) {
    global $product;

    // Resolve product id
    $pid = 0;
    if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
        $pid = $product->get_id();
    } elseif ( is_singular( 'product' ) ) {
        $pid = get_the_ID();
    } elseif ( $attachment_id ) {
        $parent = wp_get_post_parent_id( $attachment_id );
        if ( $parent ) {
            $pid = $parent;
        }
    }

    if ( ! $pid ) {
        return $html;
    }

    $video_url_raw = get_post_meta($pid, 'vwg_video_url', true);
    $video_url = maybe_unserialize( $video_url_raw );

    if ( empty( $video_url ) || ! is_array( $video_url ) ) {
        return $html;
    }

    $upload_dir = wp_upload_dir();
    $optimized_dir = $upload_dir['basedir'] . '/vwg-optimized-thumbnails/';

    foreach ( $video_url as $video_index => $video ) {
        foreach ( $video as $key => $v ) {
            if ( $key == 'video_url' ) {
                continue;
            }
            if ( empty( $v ) ) {
                continue;
            }
            $file_info = pathinfo($v);
            if ( empty( $file_info['filename'] ) ) {
                continue;
            }
            $filename = $file_info['filename'];
            $webp_path = $optimized_dir . $filename . '.webp';
            if ( file_exists($webp_path) ) {
                $webp_url = $upload_dir['baseurl'] . '/vwg-optimized-thumbnails/' . $filename . '.webp';
                $escaped_v = preg_quote($v, '/');
                $pattern = '/(data-thumb|poster|data-woocommerce_gallery_thumbnail_url|data-woocommerce_thumbnail_url)="' . $escaped_v . '"/';
                $replacement = '$1="' . esc_url($webp_url) . '"';
                $html = preg_replace($pattern, $replacement, $html);
                $html = str_replace($v, esc_url($webp_url), $html);
            }
        }
    }

    return $html;
}

/**
 * Function convert on upload
 *
 * @since 1.0
 */
function vwg_pro_convert_on_upload($image_path, $thumbnail_path, $gallery_thumbnail_path) {
    // Check if either Imagick or GD library is available
    if ( ! extension_loaded('imagick') && ! extension_loaded('gd') ) {
        error_log('Neither Imagick nor GD library is available. Please enable either of those two libraries on your server.');
        return;
    }

    // Path to the optimized directory
    $upload_dir = wp_upload_dir();
    $optimized_dir = $upload_dir['basedir'] . '/vwg-optimized-thumbnails/';

    // Create the optimized directory if it doesn't exist
    if ( ! is_dir($optimized_dir) ) {
        wp_mkdir_p($optimized_dir);
    }

    // Function to optimize a single image
    function optimize_image($image, $optimized_dir) {
        $image_info = pathinfo($image);
        $webp_image = $optimized_dir . $image_info['filename'] . '.webp';

        // Check if Imagick is available
        if ( extension_loaded('imagick') ) {
            try {
                $imagick = new Imagick($image);
                $imagick->setImageFormat('webp');
                $imagick->setImageCompressionQuality(80);
                $imagick->writeImage($webp_image);
                $imagick->clear();
                $imagick->destroy();
            } catch (Exception $e) {
                error_log('Error processing image with Imagick: ' . $image_info['basename']);
                return false;
            }
        } else {
            // Fall back to GD library if Imagick is not available
            $img = null;
            if ( $image_info['extension'] == 'jpg' || $image_info['extension'] == 'jpeg' ) {
                $img = imagecreatefromjpeg($image);
            } elseif ( $image_info['extension'] == 'png' ) {
                $img = imagecreatefrompng($image);
            }

            if ( $img ) {
                imagewebp($img, $webp_image, 80); // 80 is the quality for WebP
                imagedestroy($img);
            } else {
                error_log('Error processing image with GD library: ' . $image_info['basename']);
                return false;
            }
        }
        error_log('Processed: ' . $webp_image);
        return true;
    }

    // Optimize the provided image paths
    $paths = [$image_path, $thumbnail_path, $gallery_thumbnail_path];
    foreach ( $paths as $path ) {
        if ( file_exists($path) ) {
            optimize_image($path, $optimized_dir);
        } else {
            error_log('File does not exist: ' . $path);
        }
    }

    error_log('All provided images have been optimized and converted to WebP.');
}