<?php
/**
 * YouTube Video URL functionality
 * Adds support for YouTube videos using videojs-youtube
 *
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Add YouTube functionality to admin
 * 
 * @since 1.0
 */
function vwg_pro_add_youtube_functionality() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Wait for free version to initialize first
            setTimeout(function() {
                var isPro = $('#vwg_video_tab_content').attr('is-pro');
                
                if (isPro == 1) {
                    // Wait for VideoJS to be available
                    var initAttempts = 0;
                    var maxAttempts = 10;
                    
                    function tryInitYouTubeVideos() {
                        if (typeof videojs !== 'undefined') {
                            initExistingYouTubeVideos();
                        } else if (initAttempts < maxAttempts) {
                            initAttempts++;
                            setTimeout(tryInitYouTubeVideos, 200);
                        }
                    }
                    
                    tryInitYouTubeVideos();
                    
                           // Override YouTube button handler (remove PRO upsell)
                           $('#add_youtube_button').off('click').on('click.vwgProYoutube', function(e) {
                               e.preventDefault();
                               e.stopImmediatePropagation();

                               // Use same logic as free version
                               var currentCount = $('.video_gallery_wrapper > li[class*="video_id_"]').length;
                               var limit = parseInt($('#vwg_video_tab_content').attr('v-limit'));
                        
                        if (currentCount >= limit) {
                            Swal.fire({
                                title: '<?php echo esc_html__('Ops..' , 'video-wc-gallery') ?>',
                                text: `<?php echo esc_html__('Can add only', 'video-wc-gallery') ?> ${ $('#vwg_video_tab_content').attr('v-limit') } <?php echo esc_html__('videos !', 'video-wc-gallery') ?>`,
                                icon: 'warning',
                                confirmButtonColor: '#6C5CE7',
                                confirmButtonText: '<?php echo esc_js(__('OK', 'video-wc-gallery')); ?>',
                                buttonsStyling: true,
                                focusConfirm: false,
                                background: '#fff',
                                backdrop: 'rgba(0,0,0,0.4)'
                            });
                            return;
                        }
                        
                        // Show YouTube URL input
                        $('#youtube_url_container').slideDown();
                        $('#youtube_url_input').focus();
                    });
                    
                    // Add YouTube URL input container if not exists
                    if ($('#youtube_url_container').length === 0) {
                        var html = '<div id="youtube_url_container" class="vwg-youtube-input-container" style="display: none;">' +
                            '<input type="url" id="youtube_url_input" placeholder="<?php echo esc_attr__("Enter YouTube URL...", "video-wc-gallery-pro"); ?>" class="vwg-youtube-input" />' +
                            '<button id="confirm_youtube_button" type="button" class="button button-primary"><?php echo esc_html__("Add Video", "video-wc-gallery-pro"); ?></button>' +
                            '<button id="cancel_youtube_button" type="button" class="button button-secondary"><?php echo esc_html__("Cancel", "video-wc-gallery-pro"); ?></button>' +
                        '</div>';
                        $('.vwg-add-video-button-container').after(html);
                    }
                    
                    // Confirm button - add YouTube video
                    $(document).off('click.vwgProYoutubeConfirm', '#confirm_youtube_button').on('click.vwgProYoutubeConfirm', '#confirm_youtube_button', function(e) {
                        e.preventDefault();
                        
                        var url = $('#youtube_url_input').val().trim();
                        
                        if (!url) {
                            Swal.fire({
                                title: '<?php echo esc_js(__("Error", "video-wc-gallery-pro")); ?>',
                                text: '<?php echo esc_js(__("Please enter a YouTube URL", "video-wc-gallery-pro")); ?>',
                                icon: 'error',
                                confirmButtonColor: '#6C5CE7'
                            });
                            return;
                        }
                        
                        var videoId = extractYouTubeId(url);
                        
                        if (!videoId) {
                            Swal.fire({
                                title: '<?php echo esc_js(__("Invalid URL", "video-wc-gallery-pro")); ?>',
                                text: '<?php echo esc_js(__("Please enter a valid YouTube URL", "video-wc-gallery-pro")); ?>',
                                icon: 'error',
                                confirmButtonColor: '#6C5CE7'
                            });
                            return;
                        }
                        
                        addYouTubeVideo(url, videoId);
                        
                        $('#youtube_url_input').val('');
                        $('#youtube_url_container').slideUp();
                    });
                    
                    // Cancel button
                    $(document).off('click.vwgProYoutubeCancel', '#cancel_youtube_button').on('click.vwgProYoutubeCancel', '#cancel_youtube_button', function(e) {
                        e.preventDefault();
                        $('#youtube_url_input').val('');
                        $('#youtube_url_container').slideUp();
                    });
                }
                
                // Initialize existing YouTube videos on page load
                function initExistingYouTubeVideos() {
                    $('.video_gallery_wrapper > li[class*="video_id_"]').each(function() {
                        var $li = $(this);
                        var videoUrl = $li.find('input.video_url').val();
                        var $videoTypeInput = $li.find('input.video_type');
                        var videoType = $videoTypeInput.length ? $videoTypeInput.val() : '';
                        var isYouTube = videoUrl && (videoUrl.indexOf('youtube.com') !== -1 || videoUrl.indexOf('youtu.be') !== -1);
                        
                        if ((videoType === 'youtube' || isYouTube) && videoUrl) {
                            // Add video_type input if it doesn't exist
                            if (!$videoTypeInput.length) {
                                var classMatch = $li.attr('class').match(/video_id_(\S+)/);
                                if (classMatch) {
                                    var videoKey = classMatch[1];
                                    $li.append('<input type="hidden" class="video_type" name="video_url[' + videoKey + '][video_type]" value="youtube"/>');
                                }
                            }
                            
                            var videoId = $li.attr('class').match(/video_id_(\S+)/)[1];
                            var playerElementId = 'admin_player_' + videoId;
                            var thumbnail = $li.find('input.video_thumb_url').val();
                            
                            var playerHtml = '<video id="' + playerElementId + '" ' +
                                'class="video-js vjs-default-skin vwg-admin-youtube-player" ' +
                                'width="100%" height="180" ' +
                                'controls preload="none" ' +
                                'poster="' + thumbnail + '">' +
                                '</video>';
                            
                            $li.find('.video-player').removeAttr('style').html(playerHtml);
                            
                            if (typeof videojs !== 'undefined') {
                                try {
                                    var existingPlayer = videojs.getPlayer(playerElementId);
                                    if (existingPlayer) {
                                        existingPlayer.dispose();
                                    }
                                } catch(e) {}
                                
                                var player = videojs(playerElementId, {
                                    techOrder: ['youtube'],
                                    sources: [{
                                        type: 'video/youtube',
                                        src: videoUrl
                                    }],
                                    youtube: {
                                        ytControls: 2,
                                        iv_load_policy: 3
                                    },
                                    controls: true,
                                    preload: 'none'
                                });
                            }
                        }
                    });
                }
                
                function extractYouTubeId(url) {
                    var regex = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
                    var match = url.match(regex);
                    return (match && match[7].length == 11) ? match[7] : false;
                }
                
                   function addYouTubeVideo(url, videoId) {
                       // Use same logic as free version
                       var position = $('.video_gallery_wrapper > li[class*="video_id_"]').length + 1;

                       if ($('.video_gallery_wrapper > li[class*="video_id_"]').length > 0) {
                           var lastPos = parseInt($('.video_gallery_wrapper > li[class*="video_id_"]').last().data('position'));
                           position = lastPos + 1;
                       }
                    
                    var uniqueId = 'youtube_' + videoId + '_' + Date.now();
                    var playerElementId = 'admin_player_' + uniqueId;
                    var thumbnail = 'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg';
                    
                    var html = '<li class="ui-state video_id_' + uniqueId + '" data-position="' + position + '">' +
                        '<div class="video-player">' +
                            '<video id="' + playerElementId + '" class="video-js vjs-default-skin vwg-admin-youtube-player" ' +
                                'width="100%" height="180" ' +
                                'controls preload="none" ' +
                                'poster="' + thumbnail + '">' +
                            '</video>' +
                        '</div>' +
                        '<div class="video-actions">' +
                            '<div class="action-btn seo-btn" data-video-id="' + uniqueId + '"><i class="fas fa-cog"></i></div>' +
                            '<div class="action-btn delete-btn" data-video-id="' + uniqueId + '"><i class="fas fa-trash-alt"></i></div>' +
                        '</div>' +
                        '<input type="hidden" class="video_url" name="video_url[' + uniqueId + '][video_url]" value="' + url + '"/>' +
                        '<input type="hidden" class="video_thumb_url" name="video_url[' + uniqueId + '][video_thumb_url]" value="' + thumbnail + '"/>' +
                        '<input type="hidden" class="video_type" name="video_url[' + uniqueId + '][video_type]" value="youtube"/>' +
                        '<input type="hidden" class="video_title" name="video_url[' + uniqueId + '][video_title]" value=""/>' +
                        '<input type="hidden" class="video_description" name="video_url[' + uniqueId + '][video_description]" value=""/>' +
                    '</li>';
                    
                    $('.video_gallery_wrapper').append(html);
                    $('.bar-btns').show();
                    
                    // Initialize VideoJS player
                    setTimeout(function() {
                        if (typeof videojs !== 'undefined') {
                            try {
                                var existingPlayer = videojs.getPlayer(playerElementId);
                                if (existingPlayer) {
                                    existingPlayer.dispose();
                                }
                            } catch(e) {}
                            
                            videojs(playerElementId, {
                                techOrder: ['youtube'],
                                sources: [{
                                    type: 'video/youtube',
                                    src: url
                                }],
                                youtube: {
                                    ytControls: 2,
                                    iv_load_policy: 3
                                },
                                controls: true,
                                preload: 'none'
                            });
                        }
                    }, 200);
                    
                    // Update video counter - same logic as free version
                    var currentCount = $('.video_gallery_wrapper > li[class*="video_id_"]').length;
                    var maxLimit = parseInt($('#vwg_video_tab_content').attr('v-limit'));
                    var percentage = (maxLimit > 0) ? Math.min(100, Math.round((currentCount / maxLimit) * 100)) : 0;
                    var isLimitReached = currentCount >= maxLimit;

                    $('.counter-progress-bar').css('width', percentage + '%');
                    $('.current-count').text(currentCount);
                    $('.counter-progress-bar').attr('data-count', currentCount);
                    
                    if (isLimitReached) {
                        $('.current-count').addClass('counter-limit-reached');
                        $('.counter-progress-bar').addClass('progress-limit-reached');
                    } else {
                        $('.current-count').removeClass('counter-limit-reached');
                        $('.counter-progress-bar').removeClass('progress-limit-reached');
                    }
                }
            }, 300);
        });
    </script>
    
    <style>
        .vwg-youtube-input-container {
            margin: 15px 0;
            padding: 15px;
            background: #f8f9fa;
            border: 1px solid #ddd;
        }
        .vwg-youtube-input {
            width: 100%;
            max-width: 500px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .vwg-youtube-input:focus {
            outline: none;
            border-color: #6c5ce7;
            box-shadow: 0 0 0 2px rgba(108, 92, 231, 0.1);
        }
        #confirm_youtube_button {
            background: #6c5ce7;
            color: white;
            border-color: #6c5ce7;
            margin-right: 5px;
        }
        #confirm_youtube_button:hover {
            background: #5649c0;
            border-color: #5649c0;
        }
        
        /* Admin YouTube player styles */
        .vwg-admin-youtube-player {
            width: 100% !important;
            height: 180px !important;
        }
        .vwg-admin-youtube-player .vjs-tech {
            width: 100% !important;
            height: 100% !important;
        }
        #vwg_video_tab_content .video-player {
            position: relative;
            width: 100% !important;
            height: 180px !important;
            background: #000 !important;
            overflow: hidden;
        }
        
        /* Fix text track display blocking clicks */
        .vwg-admin-youtube-player .vjs-text-track-display {
            pointer-events: none !important;
        }
        .vwg-admin-youtube-player .vjs-text-track-display > div {
            pointer-events: none !important;
        }
    </style>
    <?php
}
add_action( 'admin_footer-post.php', 'vwg_pro_add_youtube_functionality', 20 );
add_action( 'admin_footer-post-new.php', 'vwg_pro_add_youtube_functionality', 20 );

/**
 * Save video_type field for YouTube videos
 * 
 * @since 1.0
 */
function vwg_pro_save_video_type($post_id) {
    if (isset($_POST['video_url'])) {
        $video_urls = get_post_meta($post_id, 'vwg_video_url', true);
        $video_urls = maybe_unserialize($video_urls);
        
        if (is_array($video_urls)) {
            foreach ($_POST['video_url'] as $key => $video_data) {
                if (isset($video_data['video_type']) && isset($video_urls[$key])) {
                    $video_urls[$key]['video_type'] = sanitize_text_field($video_data['video_type']);
                }
            }
            update_post_meta($post_id, 'vwg_video_url', $video_urls);
        }
    }
}
add_action('woocommerce_process_product_meta', 'vwg_pro_save_video_type', 20);

/**
 * Enqueue videojs-youtube for frontend
 * 
 * @since 1.0
 */
function vwg_pro_enqueue_youtube_script() {
    if (is_product()) {
        wp_enqueue_script('videojs-youtube', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/videojs-youtube/Youtube.min.js', array('jquery', 'videojs'), '3.0.0', true);
    }
}
add_action('wp_enqueue_scripts', 'vwg_pro_enqueue_youtube_script', 15);

/**
 * Initialize YouTube videos on frontend
 * 
 * @since 1.0
 */
function vwg_pro_init_youtube_videos() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            setTimeout(function() {
                $('.vwg_video_js').each(function() {
                    var videoId = $(this).attr('id');
                    var youtubeUrl = $(this).find('source[type="video/youtube"]').attr('src');

                    if (youtubeUrl && typeof videojs !== 'undefined') {
                        try {
                            if (videojs.getPlayer(videoId)) {
                                videojs.getPlayer(videoId).dispose();
                            }
                        } catch(e) {}
                        
                        videojs(videoId, {
                            techOrder: ['youtube'],
                            sources: [{
                                type: 'video/youtube',
                                src: youtubeUrl
                            }]
                        });
                    }
                });
            }, 1500);
        });
    </script>
    <?php
}
add_action('wp_footer', 'vwg_pro_init_youtube_videos', 30);

/**
 * Render YouTube videos on frontend
 * 
 * @since 1.0
 */
function vwg_pro_render_youtube_videos() {
    global $product;

    if (!is_object($product)) {
        $product = wc_get_product(get_the_ID());
    }

    if (!is_object($product)) {
        return;
    }

    $video_urls = maybe_unserialize(get_post_meta($product->get_id(), 'vwg_video_url', true));

    if (empty($video_urls)) {
        return;
    }

    $settings = get_option('vwg_settings_group');
    $controls = isset($settings['vwg_settings_video_controls']) ? $settings['vwg_settings_video_controls'] : '';
    $loop = isset($settings['vwg_settings_loop']) ? $settings['vwg_settings_loop'] : '';
    $muted = isset($settings['vwg_settings_muted']) ? $settings['vwg_settings_muted'] : '';
    $autoplay = isset($settings['vwg_settings_autoplay']) ? $settings['vwg_settings_autoplay'] : '';
    $adaptSettings = isset($settings['vwg_settings_video_adapt_sizes']) ? $settings['vwg_settings_video_adapt_sizes'] : '';
    $showFirst = isset($settings['vwg_settings_show_first']) ? $settings['vwg_settings_show_first'] : '';

    $product_image = wp_get_attachment_image_src($product->get_image_id(), 'woocommerce_single');
    $width = isset($product_image[1]) ? $product_image[1] : 600;
    $height = isset($product_image[2]) ? $product_image[2] : 600;

    $adaptClass = ($adaptSettings == 1) ? '' : 'vjs-fluid';

    $countVideo = 0;
    $limit = vwg_get_video_limit();

    foreach ($video_urls as $key => $video) {
        $countVideo++;

        if ($countVideo > $limit) {
            break;
        }

        $video_type = isset($video['video_type']) ? $video['video_type'] : 'mp4';
        $showFirstClass = ($showFirst == 1) ? 'vwg_show_first' : '';

        echo '<div data-thumb="' . esc_url($video['video_thumb_url']) . '" ';
        echo 'data-woocommerce_gallery_thumbnail_url="' . esc_url(isset($video['woocommerce_gallery_thumbnail_url']) ? $video['woocommerce_gallery_thumbnail_url'] : '') . '" ';
        echo 'data-woocommerce_thumbnail_url="' . esc_url(isset($video['woocommerce_thumbnail_url']) ? $video['woocommerce_thumbnail_url'] : '') . '" ';
        echo 'data-vwg-video="' . esc_attr($countVideo) . '" ';
        echo 'class="woocommerce-product-gallery__image ' . esc_attr($showFirstClass) . '">';
        echo '<a href="' . esc_url($video['video_url']) . '" class="woocommerce-product-gallery__vwg_video">';
        
        if ($video_type === 'youtube') {
            echo '<video id="vwg_video_js_' . esc_attr($countVideo) . '" ';
            echo 'class="video-js ' . esc_attr($adaptClass) . ' vwg_video_js" ';
            echo 'width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" ';
            echo 'preload="auto" ' . esc_attr($controls) . ' ' . esc_attr($autoplay) . ' ';
            echo esc_attr($loop) . ' ' . esc_attr($muted) . ' playsinline ';
            echo 'poster="' . esc_url($video['video_thumb_url']) . '">';
            echo '<source src="' . esc_url($video['video_url']) . '" type="video/youtube" />';
            echo '</video>';
        } else {
            echo '<video id="vwg_video_js_' . esc_attr($countVideo) . '" ';
            echo 'class="video-js ' . esc_attr($adaptClass) . ' vwg_video_js" ';
            echo 'width="' . esc_attr($width) . '" height="' . esc_attr($height) . '" ';
            echo 'preload="auto" ' . esc_attr($controls) . ' ' . esc_attr($autoplay) . ' ';
            echo esc_attr($loop) . ' ' . esc_attr($muted) . ' playsinline data-setup="{}" ';
            echo 'poster="' . esc_url($video['video_thumb_url']) . '">';
            echo '<source src="' . esc_url($video['video_url']) . '" type="video/mp4" />';
            echo '</video>';
        }
        
        echo '</a></div>';
    }
}

// Replace default gallery function
function vwg_pro_replace_gallery() {
    remove_action('woocommerce_product_thumbnails', 'vwg_add_video_to_product_gallery', 99);
    remove_action('vwg_woocommerce_product_thumbnails_first_show', 'vwg_add_video_to_product_gallery', 1);
    remove_action('vwg_woocommerce_product_thumbnails_first_show_flatsome_theme', 'vwg_add_video_to_product_gallery', 1);

    $settings = get_option('vwg_settings_group');
    $showFirst = isset($settings['vwg_settings_show_first']) ? $settings['vwg_settings_show_first'] : '';

    if ($showFirst == 1) {
        if (vwg_active_theme_checker() === 'default') {
            add_action('vwg_woocommerce_product_thumbnails_first_show', 'vwg_pro_render_youtube_videos', 1);
        } elseif (vwg_active_theme_checker() === 'Flatsome') {
            add_action('vwg_woocommerce_product_thumbnails_first_show_flatsome_theme', 'vwg_pro_render_youtube_videos', 1);
        }
    } else {
        add_action('woocommerce_product_thumbnails', 'vwg_pro_render_youtube_videos', 99);
    }
}
add_action('init', 'vwg_pro_replace_gallery', 25);
