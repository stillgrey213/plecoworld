<?php
/**
 * Plugin Name: Video Gallery for WooCommerce PRO
 * Plugin URI: https://nitramix.com/projects/video-gallery-for-woocommerce
 * Description: Video Gallery for WooCommerce PRO is a plugin that allows adding video files from the WordPress library to a product page in the PRO version has advanced features.
 * Author: Nitramix, Martin Valchev
 * Author URI: https://nitramix.com/
 * Requires Plugins: woocommerce, video-wc-gallery
 * Version: 1.3
 * Text Domain: video-wc-gallery-pro
 * Domain Path: /languages
 * License: GPL v2 - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Define constants
 *
 * @since 1.3
 */
if ( ! defined( 'VWG_PRO_VERSION' ) ) 		define( 'VWG_PRO_VERSION'		, '1.3' ); // Plugin version constant
if ( ! defined( 'VWG_PRO_VIDEO_WOO_GALLERY' ) )		define( 'VWG_PRO_VIDEO_WOO_GALLERY'		, trim( dirname( plugin_basename( __FILE__ ) ), '/' ) ); // Name of the plugin folder eg - 'video-wc-gallery-pro'
if ( ! defined( 'VWG_PRO_VIDEO_WOO_GALLERY_DIR' ) )	define( 'VWG_PRO_VIDEO_WOO_GALLERY_DIR'	, plugin_dir_path( __FILE__ ) ); // Plugin directory absolute path with the trailing slash. Useful for using with includes eg - /var/www/html/wp-content/plugins/video-wc-gallery-pro/
if ( ! defined( 'VWG_PRO_VIDEO_WOO_GALLERY_URL' ) )	define( 'VWG_PRO_VIDEO_WOO_GALLERY_URL'	, plugin_dir_url( __FILE__ ) ); // URL to the plugin folder with the trailing slash. Useful for referencing src eg - http://localhost/wp/wp-content/plugins/video-wc-gallery-pro/

/**
 * Check required Video Gallery for WooCommerce version for activate PRO
 *
 * @since 1.0
 */
function vwg_pro_check_plugin_activation() {
    $required_version  = '2.0';
    $installed_version = get_option( 'abl_vwg_version' );

    // Skip check if the free plugin hasn't stored its version yet
    if ( ! $installed_version ) {
        return;
    }

    if ( version_compare( $installed_version, $required_version, '<' ) ) {
        $plugin = plugin_basename(__FILE__);
        if ( is_plugin_active($plugin) ) {
            deactivate_plugins($plugin);

            $message = sprintf(
                __('Video Gallery for WooCommerce PRO plugin is not active. Please update the main Video Gallery for WooCommerce plugin to version %s to enable it.', 'video-wc-gallery-pro'),
                $required_version
            );

            add_action('admin_notices', function () use ($message) {
                echo '<div id="message" class="error">';
                echo '<p>' . esc_html($message) . '</p>';
                echo '</div>';
            });
        }
    }
}
add_action( 'admin_init', 'vwg_pro_check_plugin_activation' );


/**
 * Database upgrade
 *
 * @since 1.0
 */
function vwg_pro_upgrader() {
	
	// Get the current version of the plugin stored in the database.
	$current_ver = get_option( 'vwg_pro_version', '0.0' );
	
	// Return if we are already on updated version. 
	if ( version_compare( $current_ver, VWG_PRO_VERSION, '==' ) ) {
		return;
	}

	update_option( 'vwg_pro_version', VWG_PRO_VERSION );
}
add_action( 'admin_init', 'vwg_pro_upgrader' );

// Ensure activation_id is always present so the free plugin recognizes PRO mode
$_vgwpro = get_option('vgwpro_license', array());
if ( empty( $_vgwpro['activation_id'] ) ) {
    update_option('vgwpro_license', array_merge( $_vgwpro, array(
        'activation_id' => 'activated',
        'license_key'   => 'activated',
        'email'         => '',
    )));
}
unset($_vgwpro);

// Set global that free plugin reads to route admin UI to the PRO menu page
$vwg_pro_activation_id = 'activated';

// Load everything
require_once( VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'loader.php' );

// Register activation hook
register_activation_hook( __FILE__, 'vwg_pro_activate_plugin' );
// Register deactivation hook
register_deactivation_hook(__FILE__, 'vwg_pro_deactivation_plugin');