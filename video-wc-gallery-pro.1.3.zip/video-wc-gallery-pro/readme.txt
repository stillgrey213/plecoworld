=== Video Gallery for WooCommerce PRO ===
Contributors: nitramix, martinvalchev
Donate link: https://nitramix.com/donate/
Tags: video gallery, video player, product video, for woocommerce, product page, pro, premium, youtube video product page
Requires at least: 5.3
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.3
License: Commercial


Video Gallery for WooCommerce PRO: Advanced video gallery solution with YouTube support, custom icons, and SEO optimization. Requires WooCommerce and Video Gallery for WooCommerce activation.

== Description ==

**Video Gallery for WooCommerce PRO** is the ultimate solution for e-commerce businesses looking to create stunning product showcases with video content. Transform your WooCommerce store with professional video galleries that boost engagement and conversions.

**🚀 Professional Features:**
* **Unlimited products with video
* **Up to 6 videos per product** - Showcase products from multiple angles
* **YouTube video integration** - Embed videos directly from YouTube URLs
* **Custom SVG icons** - Use your own brand icons for video thumbnails
* **Optimized thumbnails** - Automatic thumbnail generation for faster loading
* **Auto thumbnail conversion** - Smart optimization when uploading videos
* **Advanced SEO settings** - Custom titles, descriptions, and alt text per video
* **Premium priority support** - 24-48 hour response time
* **Regular updates** - New features and security patches

**Commercial License:**
This is a commercial plugin. You need a valid license key to activate all features and receive updates.


Purchase licenses and get support at: https://nitramix.com/projects/video-gallery-for-woocommerce/


== Notes ==

*   Video Gallery for WooCommerce requires the Woocommerce plugin to be activated in order to function properly. If you do not have Woocommerce installed, you will need to install and activate it before using Video Gallery for WooCommerce.
*   The plugin supports a wide range of video file formats, but it is important to ensure that your videos are in a format that is supported by WordPress. Commonly used formats such as MP4 and MOV are typically supported.
*   The plugin works with WooCommerce base elements. Added support for someone on known themes. If you have a problem with a theme, write to support to check if it can be made compatible.

== Installation ==

To install this plugin:

1. Install the plugin through the WordPress admin interface, or upload the plugin folder to /wp-content/plugins/ using ftp.
2. Activate the plugin through the 'Plugins' screen in WordPress. On a Multisite you can either network activate it or let users activate it individually.
3. Purchase a license from https://nitramix.com/projects/video-gallery-for-woocommerce/
4. Go to WordPress Admin > WooCommerce > Settings > Video Gallery for WooCommerce
5. Enter your license key in the license settings section to activate PRO features


== Changelog ==

= 1.3 =
* **Fix:** Function to pause a video if we move to another slide in the gallery - optimized
**Release date: December 18, 2025**

= 1.2 =
* **Fix:** Optimized thumbnails
* **Added:** Copy button and functionality for copy in clipboard for faster configuration - admin menu
**Release date: December 12, 2025**

= 1.1 =
* **Added:** Function to pause a video if we move to another slide in the gallery
* **Added:** Unlimited Products with video
* **Improvement:** Code cleanup and improvements
**Release date: December 10, 2025**

= 1.0 =
* **Added:** PRO licensing feature
**Release date: December 3, 2025**

== Support ==

For technical support, bug reports, or feature requests:

**Premium Support (License Required):**
* Email: contact@nitramix.com
* Response time: 24-48 hours
* Priority support for licensed users

== Credits ==

**Developed by:**
* Nitramix Ltd. (Company)
* Martin Valchev (Lead Developer)

== Upgrade Notice ==

= 1.0 =
* Initial PRO version release. Requires license activation for full functionality.