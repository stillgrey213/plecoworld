<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * Everything in uninstall.php will be executed when user decides to delete the plugin. 
 * @since		1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// If uninstall not called from WordPress, then die.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) die;

/**
 * Delete database settings
 *
 * @since		1.0
 */ 
delete_option( 'vwg_pro_settings' );
delete_option( 'vwg_pro_version' );
delete_option( 'vgwpro_license' );
delete_option('vwg_pro_update_data');
wp_clear_scheduled_hook('vwg_pro_check_for_updates');