<?php 
/**
 * Basic setup functions for the plugin
 *
 * @since 1.0
 * @function	vwg_pro_activate_plugin()		Plugin activation todo list
 * @function	vwg_pro_load_plugin_textdomain()	Load plugin text domain
 * @function	vwg_pro_settings_link()			Print direct link to plugin settings in plugins list in admin
 * @function	vwg_pro_plugin_row_meta()		Add donate and other links to plugins list
 * @function	vwg_pro_footer_text()			Admin footer text
 * @function	vwg_pro_footer_version()			Admin footer version
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Plugin activation
 *
 * This function runs when user activates the plugin. Used in register_activation_hook in the main plugin file. 
 * @since 1.0
 */
function vwg_pro_activate_plugin() {
    // The plugin activation does nothing special
}

/**
 * Plugin deactivation
 *
 * This function runs when user deactivates the plugin. Used in register_deactivation_hook in the main plugin file.
 * @since 1.0
 */
function vwg_pro_deactivation_plugin() {
    // Clear the cron event for checking updates
    wp_clear_scheduled_hook('vwg_pro_check_for_updates');
    
    // Delete options on plugin deactivation
    delete_option('vgwpro_license');
    delete_option('vwg_pro_settings');
    delete_option('vwg_pro_update_data');
}


/**
 * Load plugin text domain
 *
 * @since 1.0
 */
function vwg_pro_load_plugin_textdomain() {
    load_plugin_textdomain( 'video-wc-gallery-pro', false, '/video-wc-gallery-pro/languages/' );
}
add_action( 'plugins_loaded', 'vwg_pro_load_plugin_textdomain' );

/**
 * Print direct link to plugin settings in plugins list in admin
 *
 * @since 1.0
 */
function vwg_pro_settings_link( $links ) {
    return array_merge(
        array(
            'settings' => '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=vwg_tab' ) . '">' . __( 'Settings', 'video-wc-gallery-pro' ) . '</a>'
        ),
        $links
    );
}
add_filter( 'plugin_action_links_' . VWG_PRO_VIDEO_WOO_GALLERY . '/video-wc-gallery-pro.php', 'vwg_pro_settings_link' );

/**
 * Add donate and other links to plugins list
 *
 * @since 1.0
 */
function vwg_pro_plugin_row_meta( $links, $file ) {
    if ( strpos( $file, 'video-wc-gallery-pro.php' ) !== false ) {
        $new_links = array(
            'donate' 	=> '<a href="https://nitramix.com/donate/" target="_blank">Donate</a>',
            'hireme' 	=> '<a href="https://nitramix.com/contact" target="_blank">Hire Me For A Project</a>',
        );
        $links = array_merge( $links, $new_links );
    }
    return $links;
}
add_filter( 'plugin_row_meta', 'vwg_pro_plugin_row_meta', 10, 2 );

/**
 * Admin footer text for PRO version
 *
 * A function to add footer text to the PRO plugin pages. Footer text contains plugin rating and donation links.
 *
 * @since 1.0
 * @refer https://codex.wordpress.org/Function_Reference/get_current_screen
 */
function vwg_pro_footer_text($default) {

     // Retun default on non-plugin pages
     $screen = get_current_screen();
     if ( $screen->id !== 'video-gallery_page_vwg-pro-license') {
         return $default;
     }

    $text = '<i><a target="_blank" href="https://nitramix.com/projects/video-gallery-for-woocommerce">Video Gallery for WooCommerce PRO</a> v' . VWG_PRO_VERSION . ' by <a href="https://nitramix.com/" title="' . __('Visit our site to get more great plugins', 'video-wc-gallery-pro') . '" target="_blank">Nitramix</a>.';
    $text .= ' Please <a target="_blank" href="https://wordpress.org/support/plugin/video-wc-gallery/reviews/?filter=5" title="' . __('Rate the plugin', 'video-wc-gallery-pro') . '">' . __('Rate the plugin ★★★★★', 'video-wc-gallery-pro') . '</a>.</i> | <a href="https://translate.wordpress.org/projects/wp-plugins/video-wc-gallery/" target="_blank"><span class="dashicons dashicons-translation"></span></a> ';
    return $text;
}
add_filter('admin_footer_text', 'vwg_pro_footer_text');