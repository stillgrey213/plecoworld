<?php
/**
 * Admin setup for the plugin
 *
 * @since 1.2
 * @function	vwg_pro_add_menu_links()		Add admin menu pages
 * @function	vwg_pro_register_settings	Register Settings
 * @function	vwg_pro_validater_and_sanitizer()	Validate And Sanitize User Input Before Its Saved To Database
 * @function	vwg_pro_get_settings()		Get settings from database
 */

// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;

/**
 * Enqueue Admin CSS and JS
 *
 * @since 1.2
 */
function vwg_pro_enqueue_css_js( $hook ) {
    global $vwg_adminPage, $vwg_pro_adminPage, $vwg_pro_license_page;

	if ( $hook != $vwg_adminPage && $hook != $vwg_pro_adminPage && $hook != $vwg_pro_license_page && $hook != "post.php" && $hook != "post-new.php") {
		return;
	}

    if ( $hook == $vwg_pro_adminPage ) { // if settings page VWG plugin

        $vwg_pro_settings = get_option('vwg_pro_settings');
        $custom_svg_icon_settings = isset($vwg_pro_settings['vwg_settings_custom_svg_icon']) ? $vwg_pro_settings['vwg_settings_custom_svg_icon'] : '';

        // CSS
        wp_enqueue_style('vwg-pro-admin-css', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/css/vwg-pro-admin.css', '', VWG_PRO_VERSION);

        // JS
        wp_enqueue_media();
        wp_dequeue_script('vwg-pricing');
        wp_enqueue_script('vwg-pro-admin', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/vwg-pro-admin.js', array('jquery'), false, true);

        wp_localize_script('vwg-pro-admin', 'vwg_pro_data', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
            'svg_nonce' => wp_create_nonce('vwg_pro_save_svg_attachment_nonce'),
            'optimize_nonce' => wp_create_nonce('image_optimize_nonce'),
            'custom_svg_icon_settings' => $custom_svg_icon_settings,
        ));

    }

    if ( 'post.php' == $hook || 'post-new.php' == $hook ) {
        // CSS
        wp_enqueue_style('vwg-pro-admin-css', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/css/vwg-pro-admin.css', '', VWG_PRO_VERSION);

        // JS
        // Enqueue Video.js YouTube library for YouTube video support
        wp_enqueue_script('videojs-youtube', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/videojs-youtube/Youtube.min.js', array('jquery', 'videojs'), '3.0.0', true);
    }
    
    if ( $hook == $vwg_pro_license_page ) { // if license page VWG plugin
        // CSS for license page
        wp_enqueue_style('vwg-pro-license-css', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/css/vwg-pro-license.css', '', VWG_PRO_VERSION);
    }
}
add_action('admin_enqueue_scripts', 'vwg_pro_enqueue_css_js');

/**
 * Add menu page for license management
 *
 * @since 1.0
 */
function vwg_pro_add_license_menu() {
    global $vwg_pro_license_page, $vwg_pro_activation_id;
    
    $vwg_pro_license_page = add_submenu_page(
        'video-gallery-wc', // Parent slug
        __('Manage License', 'video-wc-gallery-pro'), // Page title
        __('Manage License', 'video-wc-gallery-pro'), // Menu title
        'manage_options', // Capability
        'vwg-pro-license', // Menu slug
        'vwg_pro_license_page_content' // Function to display the page
    );
}
add_action('admin_menu', 'vwg_pro_add_license_menu', 20);

/**
 * Display license page content
 *
 * @since 1.0
 */
function vwg_pro_license_page_content() {
    // Declare the global variable
    global $vwg_pro_activation_id;
    
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Process form submission
    if (isset($_POST['vwg_pro_license_action'])) {
        $nonce = isset($_POST['vwg_pro_license_nonce']) ? sanitize_text_field($_POST['vwg_pro_license_nonce']) : '';
        
        if (wp_verify_nonce($nonce, 'vwg_pro_license_nonce')) {
            $action = sanitize_text_field($_POST['vwg_pro_license_action']);
            $license_key = isset($_POST['vwg_pro_license_key']) ? sanitize_text_field($_POST['vwg_pro_license_key']) : '';
            $email = isset($_POST['vwg_pro_license_email']) ? sanitize_email($_POST['vwg_pro_license_email']) : '';
            
            if ($action === 'activate') {
                // Validate inputs
                if (empty($license_key) || empty($email)) {
                    add_settings_error(
                        'vwg_pro_license',
                        'empty_fields',
                        __('Please enter both license key and email address.', 'video-wc-gallery-pro'),
                        'error'
                    );
                } else {
                    // Activate the license
                    $result = vwg_pro_api_verify_license($license_key, $email, get_option('siteurl'));
                    
                    if ($result['success']) {
                        // Save license data
                        update_option('vgwpro_license', array(
                            'license_key' => $license_key,
                            'email' => $email,
                            'activation_id' => $result['activation_id']
                        ));
                        
                        // Update the global variable
                        $vwg_pro_activation_id = $result['activation_id'];
                        
                        // Schedule a cron event for update checks
                        if (!wp_next_scheduled('vwg_pro_check_for_updates')) {
                            wp_schedule_event(time(), 'weekly', 'vwg_pro_check_for_updates');
                        }
                        
                        add_settings_error(
                            'vwg_pro_license',
                            'license_activated',
                            $result['message'],
                            'updated'
                        );
                    } else {
                        add_settings_error(
                            'vwg_pro_license',
                            'license_failed',
                            $result['message'],
                            'error'
                        );
                    }
                }
            } elseif ($action === 'deactivate') {
                // Completely delete the option from the database
                delete_option('vgwpro_license');
                
                // Update the global variable
                $vwg_pro_activation_id = false;
                
                // Clear the cron event when deactivating the license
                wp_clear_scheduled_hook('vwg_pro_check_for_updates');
                
                add_settings_error(
                    'vwg_pro_license',
                    'license_deactivated',
                    __('License deactivated successfully.', 'video-wc-gallery-pro'),
                    'updated'
                );
            }
        }
    }
    
    // Get license data
    $license_data = get_option('vgwpro_license', array());
    $is_active = !empty($license_data['activation_id']);
    $license_key = isset($license_data['license_key']) ? $license_data['license_key'] : '';
    $email = isset($license_data['email']) ? $license_data['email'] : '';
    ?>
    <div class="wrap vwg-pro-license-page">
        <h1 class="vwg-pro-logo-wrapper" style="margin-bottom: 15px;">
           <img src="<?php echo esc_url(VWG_VIDEO_WOO_GALLERY_URL); ?>includes/images/vwg-logo.png" class="logo-image" title="Video Gallery for WooCommerce PRO" alt="Video Gallery for WooCommerce PRO">
           <span class="logo-text"><?php _e('Video Gallery for WooCommerce PRO - License Management', 'video-wc-gallery-pro'); ?></span>
        </h1>
        
        <?php settings_errors('vwg_pro_license'); ?>
        
        <div class="vwg-pro-license-box">
            <?php if ($is_active): ?>
                <div class="vwg-pro-license-status active">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php _e('License is active', 'video-wc-gallery-pro'); ?>
                </div>
                
                <form method="post" class="vwg-pro-license-form">
                    <?php wp_nonce_field('vwg_pro_license_nonce', 'vwg_pro_license_nonce'); ?>
                    <input type="hidden" name="vwg_pro_license_action" value="deactivate">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('License Key', 'video-wc-gallery-pro'); ?></th>
                            <td>
                                <input type="text" class="regular-text" value="<?php echo esc_attr($license_key); ?>" disabled readonly>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Email', 'video-wc-gallery-pro'); ?></th>
                            <td>
                                <input type="email" class="regular-text" value="<?php echo esc_attr($email); ?>" disabled readonly>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="submit" id="submit" class="button button-secondary" value="<?php _e('Deactivate License', 'video-wc-gallery-pro'); ?>">
                    </p>
                </form>
            <?php else: ?>
                <div class="vwg-pro-license-status inactive">
                    <span class="dashicons dashicons-warning"></span>
                    <?php _e('License is inactive', 'video-wc-gallery-pro'); ?>
                </div>
                
                <form method="post" class="vwg-pro-license-form">
                    <?php wp_nonce_field('vwg_pro_license_nonce', 'vwg_pro_license_nonce'); ?>
                    <input type="hidden" name="vwg_pro_license_action" value="activate">
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('License Key', 'video-wc-gallery-pro'); ?></th>
                            <td>
                                <input type="text" name="vwg_pro_license_key" class="regular-text" value="<?php echo esc_attr($license_key); ?>" required>
                                <p class="description"><?php _e('Enter your license key', 'video-wc-gallery-pro'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Email', 'video-wc-gallery-pro'); ?></th>
                            <td>
                                <input type="email" name="vwg_pro_license_email" class="regular-text" value="<?php echo esc_attr($email); ?>" required>
                                <p class="description"><?php _e('Enter the email address associated with your license', 'video-wc-gallery-pro'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Activate License', 'video-wc-gallery-pro'); ?>">
                    </p>
                </form>
            <?php endif; ?>
        </div>
        
        <div class="vwg-pro-license-info">
            <h3><?php _e('License Activation Guide', 'video-wc-gallery-pro'); ?></h3>
            
            <div class="vwg-pro-guide-steps">
                <div class="vwg-pro-guide-step">
                    <span class="vwg-pro-step-number">1</span>
                    <div class="vwg-pro-step-content">
                        <h4><?php _e('Access Your Account', 'video-wc-gallery-pro'); ?></h4>
                        <p><?php _e('Log in to your account on our website where you purchased the plugin.', 'video-wc-gallery-pro'); ?></p>
                        <a href="https://nitramix.com/dashboard" target="_blank" class="button"><?php _e('Go to My Account', 'video-wc-gallery-pro'); ?></a>
                    </div>
                </div>
                
                <div class="vwg-pro-guide-step">
                    <span class="vwg-pro-step-number">2</span>
                    <div class="vwg-pro-step-content">
                        <h4><?php _e('Navigate to Licenses', 'video-wc-gallery-pro'); ?></h4>
                        <p><?php _e('In your account dashboard, go to the "Licenses" section where all your purchased licenses are listed.', 'video-wc-gallery-pro'); ?></p>
                    </div>
                </div>
                
                <div class="vwg-pro-guide-step">
                    <span class="vwg-pro-step-number">3</span>
                    <div class="vwg-pro-step-content">
                        <h4><?php _e('Configure Domain', 'video-wc-gallery-pro'); ?></h4>
                        <p><?php _e('Add your website domain to the license. This is required to reveal your license key.', 'video-wc-gallery-pro'); ?></p>
                        <p class="vwg-pro-domain-row">
                            <strong><?php _e('Current domain:', 'video-wc-gallery-pro'); ?></strong>
                            <span class="vwg-pro-domain-text"><?php echo parse_url(get_site_url(), PHP_URL_HOST); ?></span>
                            <button type="button" class="vwg-pro-copy-domain-btn" aria-label="<?php esc_attr_e('Copy domain', 'video-wc-gallery-pro'); ?>" data-domain="<?php echo esc_attr( parse_url(get_site_url(), PHP_URL_HOST) ); ?>">
                                <span class="vwg-pro-copy-label"><?php _e('Copy', 'video-wc-gallery-pro'); ?></span>
                            </button>
                            <span class="vwg-pro-copy-feedback"><?php _e('Copied!', 'video-wc-gallery-pro'); ?></span>
                        </p>
                    </div>
                </div>
                
                <div class="vwg-pro-guide-step">
                    <span class="vwg-pro-step-number">4</span>
                    <div class="vwg-pro-step-content">
                        <h4><?php _e('Copy Your License Key', 'video-wc-gallery-pro'); ?></h4>
                        <p><?php _e('After configuring your domain, your license key will be visible. Copy it to use in the form above.', 'video-wc-gallery-pro'); ?></p>
                    </div>
                </div>
                
                <div class="vwg-pro-guide-step">
                    <span class="vwg-pro-step-number">5</span>
                    <div class="vwg-pro-step-content">
                        <h4><?php _e('Activate Your License', 'video-wc-gallery-pro'); ?></h4>
                        <p><?php _e('Paste your license key in the form above, add the email address used for purchase, and click "Activate License".', 'video-wc-gallery-pro'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="vwg-pro-license-faq">
                <h4><?php _e('Frequently Asked Questions', 'video-wc-gallery-pro'); ?></h4>
                
                <div class="vwg-pro-faq-item">
                    <h5><?php _e('I can\'t see my license key', 'video-wc-gallery-pro'); ?></h5>
                    <p><?php _e('You must configure your domain in your account before the license key becomes visible. This is a security measure to protect your license.', 'video-wc-gallery-pro'); ?></p>
                </div>
                
                <div class="vwg-pro-faq-item">
                    <h5><?php _e('My license key isn\'t working', 'video-wc-gallery-pro'); ?></h5>
                    <p><?php _e('Make sure you\'re using the exact email address used during purchase and that the domain you configured matches this website.', 'video-wc-gallery-pro'); ?></p>
                </div>
                
                <div class="vwg-pro-faq-item">
                    <h5><?php _e('Can I move my license to another site?', 'video-wc-gallery-pro'); ?></h5>
                    <p><?php _e('Yes. First deactivate the license here, then go to your account on our website and update the domain configuration.', 'video-wc-gallery-pro'); ?></p>
                </div>
                
                <div class="vwg-pro-support">
                    <span class="dashicons dashicons-sos"></span>
                    <p><?php _e('Need help? <a href="https://nitramix.com/contact" target="_blank">Contact our support team</a> and we\'ll assist you with activating your license.', 'video-wc-gallery-pro'); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// Inline JS for copy domain button (keeps styling minimal)
add_action('admin_footer', function() {
    ?>
    <style>
    .vwg-pro-domain-row { display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .vwg-pro-copy-domain-btn { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; cursor: pointer; background: transparent; color: #7e3fec; border: 1px solid #7e3fec; border-radius: 4px; font-weight: 600; transition: all .15s ease; }
    .vwg-pro-copy-domain-btn:hover { color: #5f1ec2; border-color: #5f1ec2; }
    .vwg-pro-copy-domain-btn .vwg-pro-copy-label { line-height: 1; }
    .vwg-pro-copy-domain-btn.is-copied { background: #2fbf71; border-color: #2fbf71; color: #ffffff; box-shadow: none; cursor: default; }
    .vwg-pro-copy-feedback { display: none; }
    </style>
    <script type="text/javascript">
    (function(){
        const domainVal = '<?php echo esc_js( parse_url(get_site_url(), PHP_URL_HOST) ); ?>';

        function copyText(text) {
            // Try modern API first
            if (navigator.clipboard && navigator.clipboard.writeText) {
                return navigator.clipboard.writeText(text);
            }
            // Fallback for older/blocked clipboard
            return new Promise(function(resolve, reject){
                var ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                try {
                    var ok = document.execCommand('copy');
                    document.body.removeChild(ta);
                    if (ok) { resolve(); } else { reject(); }
                } catch(e) {
                    document.body.removeChild(ta);
                    reject(e);
                }
            });
        }

        function bindCopy() {
            const btn = document.querySelector('.vwg-pro-copy-domain-btn');
            if (!btn) return;
            const feedback = document.querySelector('.vwg-pro-copy-feedback');
            const label = btn.querySelector('.vwg-pro-copy-label');
            const originalLabel = label ? label.textContent : '';
            const copiedText = feedback ? feedback.textContent : 'Copied!';
            btn.addEventListener('click', function(){
                if (!domainVal) return;
                copyText(domainVal).then(function(){
                    if (btn) {
                        btn.classList.add('is-copied');
                        btn.disabled = true;
                        if (label) { label.textContent = copiedText; }
                        setTimeout(function(){
                            btn.classList.remove('is-copied');
                            btn.disabled = false;
                            if (label) { label.textContent = originalLabel; }
                        }, 1400);
                    }
                    if (feedback) {
                        feedback.classList.remove('is-error');
                        feedback.classList.add('is-visible');
                        setTimeout(function(){ feedback.classList.remove('is-visible'); }, 1500);
                    }
                }).catch(function(){
                    if (feedback) {
                        feedback.textContent = '<?php echo esc_js( __('Copy failed', 'video-wc-gallery-pro') ); ?>';
                        feedback.classList.add('is-error', 'is-visible');
                        setTimeout(function(){
                            feedback.classList.remove('is-visible', 'is-error');
                            feedback.textContent = copiedText;
                        }, 1800);
                    }
                });
            });
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', bindCopy);
        } else {
            bindCopy();
        }
    })();
    </script>
    <?php
});