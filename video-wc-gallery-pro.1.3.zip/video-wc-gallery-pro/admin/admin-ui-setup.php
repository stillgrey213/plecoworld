<?php
/**
 * Admin setup for the plugin
 *
 * @since 1.2
 * @function	vwg_pro_add_menu_links()		Add admin menu pages
 * @function	vwg_pro_register_settings	Register Settings
 * @function	vwg_pro_validater_and_sanitizer()	Validate And Sanitize User Input Before Its Saved To Database
 * @function	vwg_pro_get_settings()		Get settings from database
 */

// Exit if accessed directly
if ( ! defined('ABSPATH') ) exit;

/**
 * Enqueue Admin CSS and JS
 *
 * @since 1.2
 */
function vwg_pro_enqueue_css_js( $hook ) {
    global $vwg_adminPage, $vwg_pro_adminPage;

	if ( $hook != $vwg_adminPage && $hook != $vwg_pro_adminPage && $hook != "post.php" && $hook != "post-new.php") {
		return;
	}

    if ( $hook == $vwg_pro_adminPage ) { // if settings page VWG plugin

        $vwg_pro_settings = get_option('vwg_pro_settings');
        $custom_svg_icon_settings = isset($vwg_pro_settings['vwg_settings_custom_svg_icon']) ? $vwg_pro_settings['vwg_settings_custom_svg_icon'] : '';

        // CSS
        wp_enqueue_style('vwg-pro-admin-css', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/css/vwg-pro-admin.css', '', VWG_PRO_VERSION);

        // JS
        wp_enqueue_media();
        wp_dequeue_script('vwg-pricing');
        wp_enqueue_script('vwg-pro-admin', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/vwg-pro-admin.js', array('jquery'), false, true);

        wp_localize_script('vwg-pro-admin', 'vwg_pro_data', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
            'svg_nonce' => wp_create_nonce('vwg_pro_save_svg_attachment_nonce'),
            'optimize_nonce' => wp_create_nonce('image_optimize_nonce'),
            'custom_svg_icon_settings' => $custom_svg_icon_settings,
        ));

    }

    if ( 'post.php' == $hook || 'post-new.php' == $hook ) {
        // CSS
        wp_enqueue_style('vwg-pro-admin-css', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/css/vwg-pro-admin.css', '', VWG_PRO_VERSION);

        // JS
        // Enqueue Video.js YouTube library for YouTube video support
        wp_enqueue_script('videojs-youtube', VWG_PRO_VIDEO_WOO_GALLERY_URL . 'includes/js/videojs-youtube/Youtube.min.js', array('jquery', 'videojs'), '3.0.0', true);
    }
    
}
add_action('admin_enqueue_scripts', 'vwg_pro_enqueue_css_js');

