<?php
/**
 * Updates API Integration
 *
 * @package Video Gallery for WooCommerce PRO
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * API endpoint for updates verification
 * Switch between localhost (development) and nitramix.com (production) as needed
 */
define('VWG_PRO_UPDATES_API_URL', 'https://nitramix.com/api/downloads/plugin-version');
// define('VWG_PRO_UPDATES_API_URL', 'http://localhost:3000/api/downloads/plugin-version');

/**
 * Check for plugin updates
 */
function vwg_pro_check_for_plugin_updates() {
    $license_data = get_option('vgwpro_license', array());
    $license_key = isset($license_data['license_key']) ? sanitize_text_field($license_data['license_key']) : false;
    
    // If license key is not available, don't check for updates
    if (!$license_key) {
        return;
    }
    
    // Current installed version
    $current_version = VWG_PRO_VERSION;
    
    // API URL for updates check
    $api_url = VWG_PRO_UPDATES_API_URL;
    
    // Prepare request parameters
    $api_params = array(
        'slug' => 'video-wc-gallery-pro',
        'license_key' => $license_key
    );
    
    // Send request
    $response = wp_remote_get(add_query_arg($api_params, $api_url), array(
        'timeout' => 15,
        'sslverify' => false
    ));
    
    // Check for errors
    if (is_wp_error($response)) {
        return;
    }

    // Get response code
    $response_code = wp_remote_retrieve_response_code($response);

    // Get response body
    $response_body = wp_remote_retrieve_body($response);
    $update_data = json_decode($response_body, true);
    
    // If response is valid and successful
    if ($response_code == 200 && isset($update_data['success']) && $update_data['success'] && isset($update_data['version'])) {
        // Compare versions
        if (version_compare($update_data['version'], $current_version, '>')) {
            // Save update information
            update_option('vwg_pro_update_data', $update_data);
        } else {
            // Clear update data if we're already on the latest version
            delete_option('vwg_pro_update_data');
        }
    }
}
add_action('vwg_pro_check_for_updates', 'vwg_pro_check_for_plugin_updates');

/**
 * Manual update check (for testing)
 *
 * @return bool True if there is an update available, false otherwise
 */
function vwg_pro_force_update_check() {
    // Clear all requests and update data from the cache
    delete_option('vwg_pro_update_data');
    delete_site_transient('update_plugins');
    wp_clean_plugins_cache(true);
    
    $license_data = get_option('vgwpro_license', array());
    $license_key = isset($license_data['license_key']) ? sanitize_text_field($license_data['license_key']) : false;
    
    // If license key is not available, don't check for updates
    if (!$license_key) {
        return false;
    }
    
    // Current installed version
    $current_version = VWG_PRO_VERSION;
    
    // API URL for updates check
    $api_url = VWG_PRO_UPDATES_API_URL;
    
    // Prepare request parameters
    $api_params = array(
        'slug' => 'video-wc-gallery-pro',
        'license_key' => $license_key
    );
    
    // Send request with no-cache headers
    $response = wp_remote_get(add_query_arg($api_params, $api_url), array(
        'timeout' => 15,
        'sslverify' => false,
        'headers' => array(
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
            'Expires' => '0'
        )
    ));
    
    // Check for errors
    if (is_wp_error($response)) {
        return false;
    }

    // Get response code
    $response_code = wp_remote_retrieve_response_code($response);

    // Get response body
    $response_body = wp_remote_retrieve_body($response);
    $update_data = json_decode($response_body, true);
    
    // If response is valid and successful
    if ($response_code == 200 && isset($update_data['success']) && $update_data['success'] && isset($update_data['version'])) {
        // Compare versions
        if (version_compare($update_data['version'], $current_version, '>')) {
            // Save update information
            update_option('vwg_pro_update_data', $update_data);
            
            // Force update WordPress plugin update cache
            wp_update_plugins();

            return true; // There is an available update
        } else {
            // Clear update data if we're already on the latest version
            delete_option('vwg_pro_update_data');
            return false; // No available update
        }
    }
    
    return false; // By default, no update
}

/**
 * Filter the update check transient to add our plugin
 */
function vwg_pro_check_for_updates($update_data) {
    if (!current_user_can('update_plugins')) {
        return $update_data;
    }
    
    // Check if we have a valid object
    if (!is_object($update_data)) {
        $update_data = new stdClass();
    }
    
    if (!isset($update_data->response)) {
        $update_data->response = array();
    }
    
    // Delete existing update data for our plugin if any
    $plugin_slug = plugin_basename(VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'video-wc-gallery-pro.php');
    if (isset($update_data->response[$plugin_slug])) {
        unset($update_data->response[$plugin_slug]);
    }
    
    // Update data from our check
    $update_info = get_option('vwg_pro_update_data', false);
    
    if (!$update_info || !isset($update_info['version'])) {
        return $update_data;
    }
    
    // If we have update information
    if (version_compare($update_info['version'], VWG_PRO_VERSION, '>')) {
        // Plugin slug
        $plugin_slug = plugin_basename(VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'video-wc-gallery-pro.php');
        
        // Validate download URL
        $download_url = isset($update_info['download_url']) ? $update_info['download_url'] : '';

        // Check if download URL is valid
        if (empty($download_url) || !filter_var($download_url, FILTER_VALIDATE_URL)) {
            return $update_data;
        }
        
        // Create update object
        if (!isset($update_data->response[$plugin_slug])) {
            $update_data->response[$plugin_slug] = new stdClass();
        }
        
        // Add update information
        $update_data->response[$plugin_slug]->slug = 'video-wc-gallery-pro';
        $update_data->response[$plugin_slug]->plugin = $plugin_slug;
        $update_data->response[$plugin_slug]->new_version = $update_info['version'];
        $update_data->response[$plugin_slug]->url = isset($update_info['url']) ? $update_info['url'] : 'https://nitramix.com/projects/video-gallery-for-woocommerce';
        $update_data->response[$plugin_slug]->package = $download_url;
        $update_data->response[$plugin_slug]->name = isset($update_info['name']) ? $update_info['name'] : 'Video Gallery for WooCommerce PRO';
    }
    
    return $update_data;
}
add_filter('pre_set_site_transient_update_plugins', 'vwg_pro_check_for_updates');

/**
 * Plugin update information
 */
function vwg_pro_plugin_update_information($result, $action, $args) {
    // Check if we're looking for information about our plugin
    if ($action != 'plugin_information' || 
        !isset($args->slug) || 
        $args->slug != 'video-wc-gallery-pro') {
        return $result;
    }
    
    // Get update information
    $update_info = get_option('vwg_pro_update_data', false);
    
    if (!$update_info) {
        return $result;
    }
    
    // Create information object
    $information = new stdClass();
    $information->name = isset($update_info['name']) ? $update_info['name'] : 'Video Gallery for WooCommerce PRO';
    $information->slug = 'video-wc-gallery-pro';
    $information->version = $update_info['version'];
    $information->author = 'Nitramix, Martin Valchev';
    $information->homepage = 'https://nitramix.com/projects/video-gallery-for-woocommerce';
    $information->sections = array(
        'description' => isset($update_info['description']) ? $update_info['description'] : 'Video Gallery for WooCommerce PRO is a plugin that allows adding video files from the WordPress library to a product page in the PRO version with extended features.'
    );
    $information->download_link = $update_info['download_url'];
    
    return $information;
}
add_filter('plugins_api', 'vwg_pro_plugin_update_information', 10, 3);

/**
 * Add manual check button to plugin actions
 */
function vwg_pro_add_check_updates_button($actions, $plugin_file) {
    $plugin_slug = plugin_basename(VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'video-wc-gallery-pro.php');
    
    if ($plugin_file == $plugin_slug) {
        // We use the method to get the current URL
        $current_page = add_query_arg(array());
        $check_url = add_query_arg(array('vwg_check_update' => 'true'), $current_page);
        $actions['vwg_check_update'] = '<a href="' . wp_nonce_url($check_url, 'vwg_check_update_nonce') . '">' . __('Check for updates', 'video-wc-gallery-pro') . '</a>';
    }
    
    return $actions;
}
add_filter('plugin_action_links', 'vwg_pro_add_check_updates_button', 10, 2);

/**
 * Process manual update check from any admin page
 */
function vwg_pro_process_admin_update_check() {
    // Check if we are in the admin panel
    if (!is_admin()) {
        return;
    }
    
    // Check for manual request for update check
    if (isset($_GET['vwg_check_update']) && $_GET['vwg_check_update'] == 'true' && 
        isset($_GET['_wpnonce']) && wp_verify_nonce($_GET['_wpnonce'], 'vwg_check_update_nonce')) {
        
        // Call the function to check for updates
        $has_update = vwg_pro_force_update_check();
        
        // Perform a full check for current versions
        wp_update_plugins();
        $update_data = get_site_transient('update_plugins');
        $plugin_slug = plugin_basename(VWG_PRO_VIDEO_WOO_GALLERY_DIR . 'video-wc-gallery-pro.php');
        
        // If there is an available update, get version information
        $version_info = '';
        if ($has_update && isset($update_data->response[$plugin_slug])) {
            $version_info = $update_data->response[$plugin_slug]->new_version;
        }
        
        // Save the result of the check in the session along with version information
        set_transient('vwg_pro_update_check_result', array(
            'has_update' => $has_update ? 'has_update' : 'no_update',
            'version' => $version_info
        ), 30);
    }
    
    // Show a message if we have a result from the check
    $update_check_result = get_transient('vwg_pro_update_check_result');
    if ($update_check_result) {
        // Delete the result from the session
        delete_transient('vwg_pro_update_check_result');
        
        // Show the corresponding message
        add_action('admin_notices', function() use ($update_check_result) {
            if ($update_check_result['has_update'] === 'has_update') {
                $version_text = !empty($update_check_result['version']) ? 
                    sprintf(__('version %s', 'video-wc-gallery-pro'), $update_check_result['version']) : 
                    __('a new version', 'video-wc-gallery-pro');
                
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                    sprintf(
                        __('A new version of Video Gallery for WooCommerce PRO (%s) has been found! You can update from %supdate page%s.', 'video-wc-gallery-pro'),
                        $version_text,
                        '<a href="' . admin_url('update-core.php') . '">',
                        '</a>'
                    ) . 
                    '</p></div>';
            } else {
                echo '<div class="notice notice-success is-dismissible"><p>' . 
                    sprintf(
                        __('You are using the latest version of Video Gallery for WooCommerce PRO (%s).', 'video-wc-gallery-pro'),
                        VWG_PRO_VERSION
                    ) . 
                    '</p></div>';
            }
        });
    }
}
add_action('admin_init', 'vwg_pro_process_admin_update_check');

/**
 * Custom download function that bypasses WordPress URL restrictions
 */
function vwg_pro_custom_download($url) {
    // Create temporary file
    $temp_file = wp_tempnam($url);
    if (!$temp_file) {
        return new WP_Error('http_no_file', __('Could not create temporary file.', 'video-wc-gallery-pro'));
    }

    // Make HTTP request
    $response = wp_remote_get($url, array(
        'timeout' => 300,
        'stream' => true,
        'filename' => $temp_file,
        'sslverify' => false,
        'redirection' => 10
    ));

    // Check for errors
    if (is_wp_error($response)) {
        @unlink($temp_file);
        return $response;
    }

    // Check response code
    $response_code = wp_remote_retrieve_response_code($response);
    if ($response_code != 200) {
        @unlink($temp_file);
        return new WP_Error('http_404', sprintf(__('Download failed with HTTP code %s', 'video-wc-gallery-pro'), $response_code));
    }

    // Check if file exists and has content
    if (!file_exists($temp_file)) {
        return new WP_Error('http_no_file', __('Downloaded file does not exist.', 'video-wc-gallery-pro'));
    }

    return $temp_file;
}

/**
 * Modify download arguments to handle our custom download URL
 */
function vwg_pro_upgrader_pre_download($reply, $package, $upgrader) {
    // Check if this is our plugin update (works with both localhost:3000 and nitramix.com)
    if (empty($package) ||
        (strpos($package, 'nitramix.com') === false && strpos($package, 'localhost:3000') === false)) {
        return $reply;
    }

    // Validate URL format
    if (!filter_var($package, FILTER_VALIDATE_URL)) {
        return new WP_Error('invalid_url', __('Invalid download URL format.', 'video-wc-gallery-pro'));
    }

    // Parse URL to check components
    $parsed_url = parse_url($package);
    if (!$parsed_url || !isset($parsed_url['scheme']) || !isset($parsed_url['host'])) {
        return new WP_Error('invalid_url', __('Could not parse download URL.', 'video-wc-gallery-pro'));
    }

    // Use custom download function to bypass WordPress restrictions
    $temp_file = vwg_pro_custom_download($package);

    // Check for errors
    if (is_wp_error($temp_file)) {
        return $temp_file;
    }

    // Return the downloaded file path
    return $temp_file;
}
add_filter('upgrader_pre_download', 'vwg_pro_upgrader_pre_download', 10, 3);

/**
 * Add custom HTTP request args for plugin download
 */
function vwg_pro_http_request_args($args, $url) {
    // Check if this is our plugin download (works with both localhost:3000 and nitramix.com)
    if (strpos($url, 'nitramix.com') !== false || strpos($url, 'localhost:3000') !== false) {
        // Add longer timeout for downloads
        $args['timeout'] = 300;
        $args['sslverify'] = false;
        $args['redirection'] = 10; // Allow more redirects
    }

    return $args;
}
add_filter('http_request_args', 'vwg_pro_http_request_args', 10, 2);

/**
 * Log HTTP API response for debugging
 */
function vwg_pro_http_response($response, $parsed_args, $url) {
    // Could add logging here if needed for nitramix.com URLs
    return $response;
}
add_filter('http_response', 'vwg_pro_http_response', 10, 3); 