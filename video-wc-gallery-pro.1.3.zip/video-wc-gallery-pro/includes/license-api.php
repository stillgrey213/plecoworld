<?php
/**
 * License API Integration
 *
 * @package Video Gallery for WooCommerce PRO
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * API endpoint for license verification
 */
define('VWG_PRO_LICENSE_API_URL', 'https://nitramix.com/api/licenses');
// define('VWG_PRO_LICENSE_API_URL', 'http://localhost:3000/api/licenses');

/**
 * Verify license with remote API
 *
 * @param string $license_key License key to verify
 * @param string $email Email associated with license
 * @param string $site_url Site URL where license is being used
 * @return array Response with success/error and message
 */
function vwg_pro_api_verify_license($license_key, $email, $site_url) {
    // Remove http:// or https:// from site_url
    $site_url = preg_replace('#^https?://#', '', $site_url);
    
    // Prepare the API request data
    $api_params = array(
        'license_key' => $license_key,
        'email'       => $email,
        'site_url'    => $site_url
    );

    // Construct the URL with query parameters
    $url = add_query_arg($api_params, VWG_PRO_LICENSE_API_URL . '/activate');

    // Make remote GET request to the API
    $response = wp_remote_get($url, array(
        'timeout'   => 15,
        'sslverify' => false
    ));

    // Check for errors
    if (is_wp_error($response)) {
        return array(
            'success' => false,
            'message' => $response->get_error_message()
        );
    }

    // Get response code
    $response_code = wp_remote_retrieve_response_code($response);
    
    // Decode the response
    $license_data = json_decode(wp_remote_retrieve_body($response));

    // Check if response is valid
    if (!is_object($license_data) && $response_code != 200) {
        return array(
            'success' => false,
            'message' => __('Invalid API response. Please try again later.', 'video-wc-gallery-pro')
        );
    }

    // For testing and development
    if ($response_code == 200) {
        // Successful response
        return array(
            'success'       => true,
            'activation_id' => isset($license_data->activation_id) ? $license_data->activation_id : md5($license_key . $email . $site_url),
            'message'       => isset($license_data->message) ? $license_data->message : __('License activated successfully!', 'video-wc-gallery-pro')
        );
    } else {
        // Error response
        return array(
            'success' => false,
            'message' => isset($license_data->message) ? $license_data->message : __('License activation failed.', 'video-wc-gallery-pro')
        );
    }
}

/**
 * Deactivate license with remote API
 *
 * @param string $activation_id Activation ID to deactivate
 * @param string $license_key License key
 * @param string $email Email associated with license
 * @return array Response with success/error and message
 */
function vwg_pro_api_deactivate_license($activation_id, $license_key, $email) {
    // Remove http:// or https:// from site_url
    $site_url = get_option('siteurl');
    $site_url = preg_replace('#^https?://#', '', $site_url);
    
    // Prepare the API request data
    $api_params = array(
        'activation_id' => $activation_id,
        'license_key'   => $license_key,
        'email'         => $email,
        'site_url'      => $site_url
    );

    // Construct the URL with query parameters
    $url = add_query_arg($api_params, VWG_PRO_LICENSE_API_URL . '/deactivate');

    // Make remote GET request to the API
    $response = wp_remote_get($url, array(
        'timeout'   => 15,
        'sslverify' => false
    ));

    // Check for errors
    if (is_wp_error($response)) {
        return array(
            'success' => false,
            'message' => $response->get_error_message()
        );
    }

    // Get response code
    $response_code = wp_remote_retrieve_response_code($response);
    
    // Decode the response
    $license_data = json_decode(wp_remote_retrieve_body($response));

    // For testing and development
    if ($response_code == 200) {
        // Successful response
        return array(
            'success' => true,
            'message' => isset($license_data->message) ? $license_data->message : __('License deactivated successfully!', 'video-wc-gallery-pro')
        );
    } else {
        // Error response
        return array(
            'success' => false,
            'message' => isset($license_data->message) ? $license_data->message : __('License deactivation failed.', 'video-wc-gallery-pro')
        );
    }
} 