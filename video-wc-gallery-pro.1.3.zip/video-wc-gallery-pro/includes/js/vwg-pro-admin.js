jQuery(document).ready(function($) {

    /**
     * @since 1.0 Function when click checkbox settings use Custom SVG icon
     */
    if (vwg_pro_data.custom_svg_icon_settings) {
        $('#vwg-upload-svg-btn').attr('disabled', false)
        $('#bypass-icon-color').show()
    } else {
        $('#vwg-upload-svg-btn').attr('disabled', true)
        $('#bypass-icon-color').hide()
    }

    $('#vwg_settings_custom_svg_icon').on('change', function (){
        if (this.checked) {
            $('#vwg-upload-svg-btn').attr('disabled', false)
            $('#bypass-icon-color').show()
        } else {
            $('#vwg-upload-svg-btn').attr('disabled', true)
            $('#bypass-icon-color').hide()
        }
    })

    /**
     * @since 1.0 Function Upload svg icon
     */
    var svg_file_frame;
    $('#vwg-upload-svg-btn').on('click', function(event) {
        if ($(this).attr('disabled')) {
            event.preventDefault();
        } else {
            event.preventDefault();
            if (svg_file_frame) {
                svg_file_frame.open();
                return;
            }
            svg_file_frame = wp.media.frames.svg_file_frame = wp.media({
                title: 'Upload SVG',
                button: {
                    text: 'Insert SVG'
                },
                library: {
                    type: 'image/svg+xml' // Restrict to SVG files
                },
                multiple: false
            });
            svg_file_frame.on('select', function() {
                var attachment = svg_file_frame.state().get('selection').first().toJSON();

                // Send the attachment details to the server using AJAX
                $.ajax({
                    url: vwg_pro_data.ajaxurl, // WordPress AJAX handler URL
                    type: 'POST',
                    data: {
                        action: 'vwg_pro_action_save_svg_attachment',
                        nonce: vwg_pro_data.svg_nonce,
                        attachment: attachment
                    },
                    success: function(response) {
                        if (response.success) {
                            if ($('.vwg-custom-svg-wrapper').length > 0) {
                                $('.vwg-custom-svg-wrapper img').remove()
                                $('.vwg-custom-svg-wrapper').append(`<img src="${response.data.svg_data.url}">`)
                            } else {
                                $('.vwg-custom-svg-wrapper').remove()
                                $('.vwg-upload-wrapper #vwg-upload-svg-btn').after(`
                                    <span class="vwg-custom-svg-wrapper">
                                        <img src="${response.data.svg_data.url}">
                                    </span>
                                `)
                            }

                            Swal.fire({
                                position: "top-end",
                                icon: "success",
                                title: response.data.message,
                                showConfirmButton: false,
                                timer: 1500,
                                customClass: {
                                    title: 'vwg-pro-swal-title-svg-upload',
                                },
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });

            });
            svg_file_frame.open();
        }
    });

    /**
     * @since 1.0 Function Bulk Convert
     */
    $('#vwg_bulk_convert').on('click', function() {
        var currentIndex = 0;
        Swal.fire({
            title: 'Converting Images...',
            html: `
                <div id="vwg-progress-container" style="margin-top: 20px;">
                    <div id="vwg-image-info" style="margin-top: 10px; text-align: left;">
                        <span style="font-size: 12px;"><span id="vwg-current-image">0</span> of <span id="vwg-total-images">0</span> images</span>
                    </div>
                    <div id="vwg-progress-bar" style="position: relative; width: 100%; background-color: #f3f3f3; border-radius: 4px; height: 32px;">
                        <div id="vwg-progress-percent" style="text-align: center; position: absolute;left: 50%;top: 50%;transform: translate(-50%, -50%);font-weight: bold;">0%</div>
                        <div id="vwg-progress" style="width: 0; height: 100%; background-color: #4caf50; border-radius: 4px;"></div>
                    </div>
                    <div id="vwg-filename" style="text-align: left; font-size: 12px">Processing: </div>
                </div>
            `,
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                optimizeImages(currentIndex);
            }
        });

        function optimizeImages(currentIndex) {
            $.ajax({
                url: vwg_pro_data.ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'optimize_and_convert_images',
                    nonce: vwg_pro_data.optimize_nonce,
                    current_index: currentIndex
                },
                success: function(response) {
                    if (response.success) {
                        var progress = Math.round(response.data.progress);
                        $('#vwg-progress').css('width', progress + '%');
                        $('#vwg-progress-percent').text(progress + '%');
                        $('#vwg-current-image').text(response.data.current_index);
                        $('#vwg-total-images').text(response.data.total_images);
                        $('#vwg-filename').text('Processing: ' + response.data.current_filename);

                        if (progress < 100) {
                            optimizeImages(response.data.current_index);
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: 'Images Converted!',
                                text: 'All images have been successfully optimized and converted to WebP.',
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#7e3fec'
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Conversion Failed',
                            text: response.data,
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#7e3fec'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Conversion Failed',
                        text: 'There was an error converting your images. Please try again.',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#7e3fec'
                    });
                }
            });
        }
    });


    /**
     * @since 1.0 Function Delete converted files
     */
    $('#vwg_delete_converted_files').on('click', function() {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will delete all optimized files!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete them!',
            cancelButtonText: 'No, keep them',
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: vwg_pro_data.ajaxurl,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'delete_optimized_files',
                        nonce: vwg_pro_data.optimize_nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: response.data,
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#7e3fec'
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Deletion Failed',
                                text: response.data,
                                confirmButtonText: 'OK',
                                confirmButtonColor: '#7e3fec'
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Deletion Failed',
                            text: 'There was an error deleting the files. Please try again.',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#7e3fec'
                        });
                    }
                });
            }
        });
    });

});