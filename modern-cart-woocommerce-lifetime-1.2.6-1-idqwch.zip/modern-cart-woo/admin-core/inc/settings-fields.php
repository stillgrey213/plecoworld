<?php
/**
 * Settings Fields for Modern Cart WooCommerce.
 *
 * @package modern-cart-woo
 * @since 1.2.0
 */

namespace ModernCart_Pro\Admin_Core\Inc;

use ModernCart_Pro\Inc\Traits\Get_Instance;

/**
 * Settings_Fields
 *
 * @since 1.2.0
 */
class Settings_Fields {
	use Get_Instance;

	/**
	 * Holds the settings fields for Modern Cart Woo.
	 *
	 * @since 1.2.0
	 * @var array<string, mixed>
	 */
	private array $fields;

	/**
	 * Constructor
	 *
	 * @since 1.2.0
	 */
	public function __construct() {
		add_filter( 'moderncart_settings_tabs', [ $this, 'add_pro_tabs' ] );
		add_filter( 'moderncart_settings_icons', [ $this, 'add_pro_icons' ] );
		add_filter( 'moderncart_settings_fields', [ $this, 'add_pro_fields' ] );
	}

	/**
	 * Add the "Products" tab for product recommendations to the settings tabs array.
	 *
	 * @param array<string, mixed> $tabs Existing settings tabs.
	 * @return array<string, mixed> Modified settings tabs with the product recommendations tab added.
	 * @since 1.2.0
	 */
	public function add_pro_tabs( array $tabs ): array {
		$tabs['moderncart_license']                 = [
			'name'     => __( 'My Account', 'modern-cart-woo' ),
			'title'    => __( 'My Account', 'modern-cart-woo' ), // Page title.
			'slug'     => 'moderncart_license',
			'priority' => 5,
		];
		$tabs['moderncart_product_recommendations'] = [
			'name'     => __( 'Products', 'modern-cart-woo' ),
			'title'    => __( 'Product Recommendations', 'modern-cart-woo' ), // Page title.
			'slug'     => 'moderncart_product_recommendations',
			'priority' => 10,
		];

		return $tabs;
	}

	/**
	 * Add the icon SVG for the product recommendations tab to the settings icons array.
	 *
	 * @param array<string, string> $icons Existing settings icons.
	 * @return array<string, string> Modified settings icons with the product recommendations icon added.
	 * @since 1.2.0
	 */
	public function add_pro_icons( array $icons ): array {
		$icons['moderncart_product_recommendations'] = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.7" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 10.5V6a3.75 3.75 0 1 0-7.5 0v4.5m11.356-1.993 1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 0 1-1.12-1.243l1.264-12A1.125 1.125 0 0 1 5.513 7.5h12.974c.576 0 1.059.435 1.119 1.007ZM8.625 10.5a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm7.5 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"/></svg>';

		return $icons;
	}

	/**
	 * Add pro fields to the settings fields array.
	 *
	 * @param array<string, mixed> $fields Existing fields array.
	 * @return array<string, mixed> Modified fields array with pro fields.
	 * @since 1.2.0
	 */
	public function add_pro_fields( array $fields ): array {
		$this->fields = $fields;

		$this->add_moderncart_setting_fields();
		$this->add_moderncart_product_recommendations_fields();
		$this->add_moderncart_text_fields();
		$this->add_moderncart_floating_fields();
		$this->add_moderncart_styling_fields();

		return $this->fields;
	}

	/**
	 * Adds or modifies the Modern Cart setting fields.
	 *
	 * This method updates the available options and settings for the Modern Cart,
	 * such as cart theme styles, cart type, and cart opening direction.
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function add_moderncart_setting_fields(): void {
		if ( ! isset( $this->fields['moderncart_setting'] ) || ! is_array( $this->fields['moderncart_setting'] ) ) {
			return;
		}
		if ( ! isset( $this->fields['moderncart_setting']['moderncart_cart_cart_theme_style'] ) ) {
			$this->fields['moderncart_setting']['moderncart_cart_cart_theme_style'] = [];
		}
		$this->fields['moderncart_setting']['moderncart_cart_cart_theme_style']['options'] = [
			[
				'id'   => 'style1',
				'name' => __( 'Style 1', 'modern-cart-woo' ),
			],
			[
				'id'   => 'style2',
				'name' => __( 'Style 2', 'modern-cart-woo' ),
			],
			[
				'id'   => 'style3',
				'name' => __( 'Style 3', 'modern-cart-woo' ),
			],
			[
				'id'   => 'style4',
				'name' => __( 'Style 4', 'modern-cart-woo' ),
			],
			[
				'id'   => 'style5',
				'name' => __( 'Style 5', 'modern-cart-woo' ),
			],
			[
				'id'   => 'style6',
				'name' => __( 'Style 6', 'modern-cart-woo' ),
			],
		];

		$this->fields['moderncart_setting']['moderncart_setting_enable_moderncart']['options'] = [
			[
				'id'   => 'disabled',
				'name' => __( 'Disable', 'modern-cart-woo' ),
			],
			[
				'id'   => 'wc_pages',
				'name' => __( 'WooCommerce Pages', 'modern-cart-woo' ),
			],
			[
				'id'   => 'all',
				'name' => __( 'Entire Website', 'modern-cart-woo' ),
			],
			[
				'id'   => 'selected_pages',
				'name' => __( 'Selected Pages', 'modern-cart-woo' ),
			],
		];

		if ( ! is_array( $this->fields['moderncart_setting'] ) ) {
			return;
		}
		$this->fields['moderncart_setting'] = array_merge(
			$this->fields['moderncart_setting'],
			[
				'moderncart_cart_cart_selected_pages'     => [
					'type'        => 'page_selector',
					'label'       => __( 'Selected Pages', 'modern-cart-woo' ),
					'description' => __( 'Choose the pages where you want the cart to appear.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[cart_selected_pages]',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_setting[enable_moderncart]',
								'operator' => '===',
								'value'    => 'selected_pages',
							],
						],
					],
					'hide_image'  => false,
					'priority'    => 15,
				],
				'moderncart_cart_cart_type'               => [
					'type'        => 'dropdown',
					'label'       => __( 'Cart Type', 'modern-cart-woo' ),
					'description' => sprintf(
						/* translators: %1$s: link html start, %2$s: link html end. */
						__( 'Choose how the cart appears to your customers. %1$sLearn More%2$s', 'modern-cart-woo' ),
						'<a href="https://cartflows.com/docs/modern-cart-general-settings/#_2--cart-type--pro-" class="text-wpcolor hover:text-wphovercolor no-underline" target="_blank">',
						'</a>'
					),
					'name'        => 'moderncart_cart[cart_type]',
					'options'     => [
						[
							'id'   => 'slideout',
							'name' => __( 'Slideout', 'modern-cart-woo' ),
						],
						[
							'id'   => 'popup',
							'name' => __( 'Popup', 'modern-cart-woo' ),
						],
					],
					'priority'    => 15,
				],
				'moderncart_cart_cart_opening_direction'  => [
					'type'        => 'dropdown',
					'label'       => __( 'Cart Opening Direction', 'modern-cart-woo' ),
					'description' => sprintf(
						/* translators: %1$s: link html start, %2$s: link html end. */
						__( 'Choose the direction from which the cart slides into view. %1$sLearn More%2$s', 'modern-cart-woo' ),
						'<a href="https://cartflows.com/docs/modern-cart-general-settings/#_4--cart-opening-direction--pro-" class="text-wpcolor hover:text-wphovercolor no-underline" target="_blank">',
						'</a>'
					),
					'name'        => 'moderncart_cart[cart_opening_direction]',
					'options'     => [
						[
							'id'   => 'right',
							'name' => __( 'From Right', 'modern-cart-woo' ),
						],
						[
							'id'   => 'left',
							'name' => __( 'From Left', 'modern-cart-woo' ),
						],
					],
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_cart[cart_type]',
								'operator' => '===',
								'value'    => 'slideout',
							],
						],
					],
					'priority'    => 22,
				],
				'moderncart_cart_cart_header_style'       => [
					'type'        => 'dropdown',
					'label'       => __( 'Cart Header Style', 'modern-cart-woo' ),
					'description' => sprintf(
						/* translators: %1$s: link html start, %2$s: link html end. */
						__( 'Pick a cart header design that best suits your store\'s look and feel. %1$sLearn More%2$s', 'modern-cart-woo' ),
						'<a href="https://cartflows.com/docs/modern-cart-general-settings/#_5--cart-header-style--pro-" class="text-wpcolor hover:text-wphovercolor no-underline" target="_blank">',
						'</a>'
					),
					'name'        => 'moderncart_cart[cart_header_style]',
					'options'     => [
						[
							'id'   => 'style1',
							'name' => __( 'Style 1', 'modern-cart-woo' ),
						],
						[
							'id'   => 'style2',
							'name' => __( 'Style 2', 'modern-cart-woo' ),
						],
					],
					'priority'    => 24,
				],
				'moderncart_cart_order_summary_style'     => [
					'type'        => 'dropdown',
					'label'       => __( 'Order Summary Style', 'modern-cart-woo' ),
					'description' => sprintf(
						/* translators: %1$s: link html start, %2$s: link html end. */
						__( 'Pick order summary style that best suits your store\'s look and feel. %1$sLearn More%2$s', 'modern-cart-woo' ),
						'<a href="https://cartflows.com/docs/modern-cart-general-settings/#_6--order-summary-style--pro-" class="text-wpcolor hover:text-wphovercolor no-underline" target="_blank">',
						'</a>'
					),
					'name'        => 'moderncart_cart[order_summary_style]',
					'options'     => [
						[
							'id'   => 'style1',
							'name' => __( 'Style 1', 'modern-cart-woo' ),
						],
						[
							'id'   => 'style2',
							'name' => __( 'Style 2', 'modern-cart-woo' ),
						],
					],
					'priority'    => 25,
				],
				'moderncart_cart_count_behavior'          => [
					'type'        => 'dropdown',
					'label'       => __( 'Count Behavior', 'modern-cart-woo' ),
					'description' => __( 'Product Quantity shows total items (2 shirts + 3 pants = 5), Cart Quantity shows unique products (2 shirts + 3 pants = 2)', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[count_behavior]',
					'options'     => [
						[
							'id'   => 'product-qty',
							'name' => __( 'Product Quantity', 'modern-cart-woo' ),
						],
						[
							'id'   => 'cart-qty',
							'name' => __( 'Cart Quantity', 'modern-cart-woo' ),
						],
					],
					'priority'    => 26,
				],
				'moderncart_cart_cart_auto_open_behavior' => [
					'type'        => 'dropdown',
					'label'       => __( 'Cart Auto-Open Behavior', 'modern-cart-woo' ),
					'description' => sprintf(
						/* translators: %1$s: link html start, %2$s: link html end. */
						__( 'Automatically open the cart after a product is added to help users review their items easily—great for faster checkouts! %1$sLearn More%2$s', 'modern-cart-woo' ),
						'<a href="https://cartflows.com/docs/modern-cart-general-settings/#_7--cart-auto-open-behavior--pro-" class="text-wpcolor hover:text-wphovercolor no-underline" target="_blank">',
						'</a>'
					),
					'name'        => 'moderncart_cart[cart_auto_open_behavior]',
					'options'     => [
						[
							'id'   => 'always-auto-open-cart',
							'name' => __( 'For every item added', 'modern-cart-woo' ),
						],
						[
							'id'   => 'show-cart-on-first-add',
							'name' => __( 'For the first item added', 'modern-cart-woo' ),
						],
						[
							'id'   => 'never-auto-open-cart',
							'name' => __( "Don't open automatically", 'modern-cart-woo' ),
						],
					],
					'priority'    => 28,
				],
				'moderncart_cart_enable_product_image_in_mobile_view' => [
					'type'        => 'toggle',
					'label'       => __( 'Show Product Image In Mobile View', 'modern-cart-woo' ),
					'description' => __( 'Enable this option to display product images in the cart on mobile devices. When disabled, product images will be hidden on mobile to save space and improve performance.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_product_image_in_mobile_view]',
					'priority'    => 35,
				],
				'moderncart_cart_enable_shipping'         => [
					'type'        => 'toggle',
					'label'       => __( 'Show Shipping', 'modern-cart-woo' ),
					'description' => __( 'Display the shipping charges for the order.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_shipping]',
					'priority'    => 40,
				],
				'moderncart_cart_enable_subtotal'         => [
					'type'        => 'toggle',
					'label'       => __( 'Show Subtotal', 'modern-cart-woo' ),
					'description' => __( 'Display subtotal before taxes, discounts, and other charges.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_subtotal]',
					'priority'    => 45,
				],
				'moderncart_cart_enable_total'            => [
					'type'        => 'toggle',
					'label'       => __( 'Show Total', 'modern-cart-woo' ),
					'description' => __( 'Display the total amount for the order.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_total]',
					'priority'    => 50,
				],
				'moderncart_cart_enable_discount'         => [
					'type'        => 'toggle',
					'label'       => __( 'Show Discount', 'modern-cart-woo' ),
					'description' => __( 'Display the discount for the order.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_discount]',
					'priority'    => 55,
				],
				'moderncart_cart_enable_tax'              => [
					'type'        => 'toggle',
					'label'       => __( 'Show Tax', 'modern-cart-woo' ),
					'description' => __( 'Display the tax for the order.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[enable_tax]',
					'priority'    => 60,
				],
			]
		);
	}

	/**
	 * Adds the product recommendations fields to the settings.
	 *
	 * This method defines the fields for configuring product recommendations,
	 * including recommendation types and list styles, and adds them to the
	 * 'moderncart_product_recommendations' section of the settings fields array.
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function add_moderncart_product_recommendations_fields(): void {
		$this->fields['moderncart_product_recommendations'] = [
			'moderncart_cart_recommendation_types'      => [
				'type'        => 'dropdown',
				'label'       => __( 'Increase AOV with Product Recommendations', 'modern-cart-woo' ),
				'description' => __( "Automatically suggest relevant products to shoppers as they add items to their cart—helping them discover more while increasing your order value. (This feature works only with simple products. Also, items that are already in the cart won't be shown as recommendations.)", 'modern-cart-woo' ),
				'name'        => 'moderncart_cart[recommendation_types]',
				'options'     => [
					[
						'id'   => 'disabled',
						'name' => __( 'Disable', 'modern-cart-woo' ),
					],
					[
						'id'   => 'custom_recommendations',
						'name' => __( 'Custom', 'modern-cart-woo' ),
					],
					[
						'id'   => 'upsells',
						'name' => __( 'From Upsell', 'modern-cart-woo' ),
					],
					[
						'id'   => 'cross_sells',
						'name' => __( 'From Cross Sells', 'modern-cart-woo' ),
					],
				],
				'priority'    => 10,
			],
			'moderncart_cart_recommendation_list_style' => [
				'type'        => 'dropdown',
				'label'       => __( 'Recommendation List Style', 'modern-cart-woo' ),
				'description' => __( 'Choose how product recommendations are displayed to your customers.', 'modern-cart-woo' ),
				'name'        => 'moderncart_cart[recommendation_list_style]',
				'options'     => [
					[
						'id'   => 'style1',
						'name' => __( 'Style 1', 'modern-cart-woo' ),
					],
					[
						'id'   => 'style2',
						'name' => __( 'Style 2', 'modern-cart-woo' ),
					],
				],
				'conditions'  => [
					'fields' => [
						[
							'name'     => 'moderncart_cart[recommendation_types]',
							'operator' => '!==',
							'value'    => 'disabled',
						],
					],
				],
				'priority'    => 20,
			],
			'moderncart_cart_custom_recommendations'    => [
				'type'        => 'product_selector',
				'label'       => __( 'Custom Recommendations', 'modern-cart-woo' ),
				'description' => __( 'Select products to use as custom recommendations.', 'modern-cart-woo' ),
				'name'        => 'moderncart_cart[custom_recommendations]',
				'conditions'  => [
					'fields' => [
						[
							'name'     => 'moderncart_cart[recommendation_types]',
							'operator' => '===',
							'value'    => 'custom_recommendations',
						],
					],
				],
				'priority'    => 25,
			],
			'moderncart_cart_empty_cart_recommendation' => [
				'type'        => 'dropdown',
				'label'       => __( 'Product Recommendation Source for Empty Cart', 'modern-cart-woo' ),
				'description' => __( "Select the source of the product to recommend when a customer's cart is empty. This helps keep users engaged and encourages purchases even when no items are in the cart.", 'modern-cart-woo' ),
				'name'        => 'moderncart_cart[empty_cart_recommendation]',
				'options'     => [
					[
						'id'   => 'disabled',
						'name' => __( 'Disable', 'modern-cart-woo' ),
					],
					[
						'id'   => 'upsells',
						'name' => __( 'From Upsell', 'modern-cart-woo' ),
					],
					[
						'id'   => 'featured',
						'name' => __( 'From Featured', 'modern-cart-woo' ),
					],
					[
						'id'   => 'cross_sells',
						'name' => __( 'From Cross Sells', 'modern-cart-woo' ),
					],
				],
				'priority'    => 30,
			],
		];
	}

	/**
	 * Adds or modifies the Modern Cart text fields.
	 *
	 * This method updates the available text fields for the Modern Cart,
	 * such as product recommendation titles and empty cart recommendation titles.
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function add_moderncart_text_fields(): void {
		if ( ! is_array( $this->fields['moderncart_text'] ) ) {
			return;
		}
		$this->fields['moderncart_text'] = array_merge(
			$this->fields['moderncart_text'],
			[
				'moderncart_cart_recommendation_title' => [
					'type'        => 'text',
					'label'       => __( 'Product Recommendation Title', 'modern-cart-woo' ),
					'description' => __( 'Set a clear and engaging title for your recommendation slider to grab attention.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[recommendation_title]',
					'badge'       => __( 'Default value: You might also like this item!', 'modern-cart-woo' ),
					'priority'    => 12,
				],
				'moderncart_cart_empty_cart_recommendation_title' => [
					'type'        => 'text',
					'label'       => __( 'Empty Cart Recommendation Title', 'modern-cart-woo' ),
					'description' => __( 'Set a clear and engaging title for the product recommendation area shown when the cart is empty. This will be displayed above the recommended product.', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[empty_cart_recommendation_title]',
					'badge'       => __( "Default value: Your Cart Is Empty, Let's Fix That!", 'modern-cart-woo' ),
					'priority'    => 14,
				],
			]
		);
	}

	/**
	 * Adds or modifies the Modern Cart floating cart fields.
	 *
	 * This method updates the available floating cart settings for the Modern Cart,
	 * such as displaying the floating cart button, hiding the button when the cart is empty,
	 * selecting the floating cart icon, and setting custom trigger selectors.
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function add_moderncart_floating_fields(): void {
		if ( ! is_array( $this->fields['moderncart_floating'] ) ) {
			return;
		}
		$this->fields['moderncart_floating'] = array_merge(
			$this->fields['moderncart_floating'],
			[
				'moderncart_floating_display_floating_cart_icon' => [
					'type'        => 'toggle',
					'label'       => __( 'Display Floating Cart Button', 'modern-cart-woo' ),
					'description' => __( 'Use this option to hide/show the floating cart button. This does not affect the custom triggers.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[display_floating_cart_icon]',
					'priority'    => 5,
				],
				'moderncart_floating_enable_floating_if_empty' => [
					'type'        => 'toggle',
					'label'       => __( 'Hide Cart Button When Empty', 'modern-cart-woo' ),
					'description' => __( 'Enable this option to hide the floating cart button when there are no items in the cart.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[enable_floating_if_empty]',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
					'priority'    => 30,
				],
				'moderncart_floating_floating_cart_icon' => [
					'type'           => 'icon_picker',
					'label'          => __( 'Select Floating Cart Button Icon', 'modern-cart-woo' ),
					'description'    => __( 'Choose from predefined icons or upload your own custom icon that fits your brand.', 'modern-cart-woo' ),
					'name'           => 'moderncart_floating[floating_cart_icon]',
					'customIconName' => 'moderncart_floating[custom_cart_icon_url]',
					'conditions'     => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
					'priority'       => 40,
				],
				'moderncart_floating_custom_trigger_selectors' => [
					'type'        => 'text',
					'label'       => __( 'Use Custom Trigger', 'modern-cart-woo' ),
					'description' => __( 'Enter element selector (#id or .class) for your custom trigger which will trigger the cart panel. You can add multiple selectors separated by commas.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[custom_trigger_selectors]',
					'badge'       => __( 'Example: .my-class, #my_id', 'modern-cart-woo' ),
					'priority'    => 50,
				],
			]
		);
	}

	/**
	 * Adds the styling fields to the Modern Cart settings.
	 *
	 * This method defines and merges the color-related appearance fields
	 * (such as button text color, background color, header colors, and quantity badge colors)
	 * into the 'moderncart_styling' section of the settings fields array.
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function add_moderncart_styling_fields(): void {
		if ( ! isset( $this->fields['moderncart_styling'] ) || ! is_array( $this->fields['moderncart_styling'] ) ) {
			return;
		}
		if ( ! isset( $this->fields['moderncart_styling']['sections'] ) ) {
			$this->fields['moderncart_styling']['sections'] = [];
		}
		if ( ! isset( $this->fields['moderncart_styling']['sections']['colors'] ) ) {
			$this->fields['moderncart_styling']['sections']['colors'] = [];
		}
		if ( ! isset( $this->fields['moderncart_styling']['sections']['colors']['field_args'] ) ) {
			$this->fields['moderncart_styling']['sections']['colors']['field_args'] = [];
		}
		$this->fields['moderncart_styling']['sections']['colors']['field_args'] = array_merge(
			$this->fields['moderncart_styling']['sections']['colors']['field_args'],
			[
				'moderncart_appearance_button_font_color' => [
					'type'        => 'color',
					'label'       => __( 'Button Text Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a color for the button text in the cart.', 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[button_font_color]',
					'default_var' => 'button_font_color',
					'priority'    => 10,
				],
				'moderncart_appearance_background_color'  => [
					'type'        => 'color',
					'label'       => __( 'Background Color', 'modern-cart-woo' ),
					'description' => __( "Choose a color for your cart's background to match your style.", 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[background_color]',
					'default_var' => 'background_color',
					'priority'    => 20,
				],
				'moderncart_appearance_header_font_color' => [
					'type'        => 'color',
					'label'       => __( 'Header Font Color', 'modern-cart-woo' ),
					'description' => __( "Choose a color for the cart's header text.", 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[header_font_color]',
					'default_var' => 'header_font_color',
					'priority'    => 30,
				],
				'moderncart_appearance_header_background_color' => [
					'type'        => 'color',
					'label'       => __( 'Header Background Color', 'modern-cart-woo' ),
					'description' => __( "Choose a background color for the cart's header to match your style.", 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[header_background_color]',
					'default_var' => 'header_background_color',
					'priority'    => 40,
				],
				'moderncart_appearance_quantity_font_color' => [
					'type'        => 'color',
					'label'       => __( 'Quantity Font Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a color for the quantity badge text.', 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[quantity_font_color]',
					'default_var' => 'quantity_font_color',
					'priority'    => 50,
				],
				'moderncart_appearance_quantity_background_color' => [
					'type'        => 'color',
					'label'       => __( 'Quantity Background Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a background color for the quantity badge.', 'modern-cart-woo' ),
					'name'        => 'moderncart_appearance[quantity_background_color]',
					'default_var' => 'quantity_background_color',
					'priority'    => 60,
				],
			]
		);

		if ( ! isset( $this->fields['moderncart_styling']['sections'] ) ) {
			$this->fields['moderncart_styling']['sections'] = [];
		}
		$this->fields['moderncart_styling']['sections']['floating_icon'] = [
			'label'      => __( 'Floating Cart Icon', 'modern-cart-woo' ),
			'priority'   => 30,
			'field_args' => [
				'moderncart_floating_cart_live_preview'  => [
					'type'       => 'live_preview',
					'name'       => 'moderncart_floating[cart_live_preview]',
					'priority'   => 5,
					'conditions' => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_icon_color'         => [
					'type'        => 'color',
					'label'       => __( 'Icon Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a color for the cart icon.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[icon_color]',
					'default_var' => 'icon_color',
					'priority'    => 10,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_icon_background_color' => [
					'type'        => 'color',
					'label'       => __( 'Icon Background Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a background color for the cart icon.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[icon_background_color]',
					'default_var' => 'icon_background_color',
					'priority'    => 20,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_count_text_color'   => [
					'type'        => 'color',
					'label'       => __( 'Count Text Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a color for the cart count text.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[count_text_color]',
					'default_var' => 'count_text_color',
					'priority'    => 30,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_count_background_color' => [
					'type'        => 'color',
					'label'       => __( 'Count Background Color', 'modern-cart-woo' ),
					'description' => __( 'Choose a background color for the cart count.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[count_background_color]',
					'default_var' => 'count_background_color',
					'priority'    => 40,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_icon_width'         => [
					'type'        => 'number',
					'label'       => __( 'Icon Width', 'modern-cart-woo' ),
					'description' => __( 'Set the width and height of the floating cart icon.', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[icon_width]',
					'badge'       => __( 'Default: 60px', 'modern-cart-woo' ),
					'type_attr'   => 'px',
					'min'         => 30,
					'priority'    => 50,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
				'moderncart_floating_icon_border_radius' => [
					'type'        => 'number',
					'label'       => __( 'Border Radius', 'modern-cart-woo' ),
					'description' => __( 'Set the border radius of the floating cart icon (in pixels).', 'modern-cart-woo' ),
					'name'        => 'moderncart_floating[icon_border_radius]',
					'badge'       => __( 'Default: 200px', 'modern-cart-woo' ),
					'type_attr'   => 'px',
					'min'         => 0,
					'max'         => 200,
					'priority'    => 60,
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_floating[display_floating_cart_icon]',
								'operator' => '===',
								'value'    => true,
							],
						],
					],
				],
			],
		];

		if ( ! isset( $this->fields['moderncart_styling']['sections'] ) ) {
			$this->fields['moderncart_styling']['sections'] = [];
		}
		$this->fields['moderncart_styling']['sections']['width'] = [
			'label'      => __( 'Width', 'modern-cart-woo' ),
			'priority'   => 40,
			'field_args' => [
				'moderncart_cart_slide_out_width_desktop' => [
					'type'        => 'number',
					'label'       => __( 'Slide Out Width (Desktop)', 'modern-cart-woo' ),
					'description' => __( 'Set how wide the slide-out window should be on Desktop (in pixels).', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[slide_out_width_desktop]',
					'badge'       => __( 'Default width: 450px', 'modern-cart-woo' ),
					'type_attr'   => 'px',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_cart[cart_type]',
								'operator' => '===',
								'value'    => 'slideout',
							],
						],
					],
					'priority'    => 10,
				],
				'moderncart_cart_slide_out_width_mobile'  => [
					'type'        => 'number',
					'label'       => __( 'Slide Out Width (Mobile)', 'modern-cart-woo' ),
					'description' => __( 'Set how wide the slide-out window should be on Mobile (in percentage).', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[slide_out_width_mobile]',
					'badge'       => __( 'Default width: 80%', 'modern-cart-woo' ),
					'max'         => 100,
					'type_attr'   => '%',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_cart[cart_type]',
								'operator' => '===',
								'value'    => 'slideout',
							],
						],
					],
					'priority'    => 20,
				],
				'moderncart_cart_popup_width_desktop'     => [
					'type'        => 'number',
					'label'       => __( 'Popup width (Desktop)', 'modern-cart-woo' ),
					'description' => __( 'Width of popup window (in percentage).', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[popup_width_desktop]',
					'badge'       => __( 'Default width: 50%', 'modern-cart-woo' ),
					'max'         => 100,
					'type_attr'   => 'px',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_cart[cart_type]',
								'operator' => '===',
								'value'    => 'popup',
							],
						],
					],
					'priority'    => 30,
				],
				'moderncart_cart_popup_width_mobile'      => [
					'type'        => 'number',
					'label'       => __( 'Popup width (Mobile)', 'modern-cart-woo' ),
					'description' => __( 'Width of popup window (in percentage).', 'modern-cart-woo' ),
					'name'        => 'moderncart_cart[popup_width_mobile]',
					'badge'       => __( 'Default width: 80%', 'modern-cart-woo' ),
					'max'         => 100,
					'type_attr'   => 'px',
					'conditions'  => [
						'fields' => [
							[
								'name'     => 'moderncart_cart[cart_type]',
								'operator' => '===',
								'value'    => 'popup',
							],
						],
					],
					'priority'    => 40,
				],
			],
		];
	}

	/**
	 * Adds or modifies the Modern Cart extensions fields.
	 *
	 * This method defines the fields for configuring Modern Cart extensions,
	 * such as enabling express checkout buttons, and adds them to the
	 * 'moderncart_extensions' section of the settings fields array.
	 *
	 * @since 1.2.0
	 * @access private
	 * @phpstan-ignore-next-line
	 */
	private function add_moderncart_extensions_fields(): void {
		$this->fields['moderncart_extensions'] = [
			[
				'type'        => 'toggle',
				'label'       => __( 'Display Express Checkout Buttons', 'modern-cart-woo' ),
				'description' => __( 'Enable express checkout payment on slide out window after checkout button.', 'modern-cart-woo' ),
				'name'        => 'moderncart_setting[enable_express_checkout]',
				'priority',
			],
		];
	}
}
