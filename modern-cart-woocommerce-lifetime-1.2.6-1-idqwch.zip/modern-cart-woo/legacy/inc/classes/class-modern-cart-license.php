<?php
/**
 * Moder Cart Woo License.
 *
 * @package Moder Cart Woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Inc\Classes;

use ModernCart_Pro\Inc\Helper;
use ModernCart_Pro\Inc\Traits\Get_Instance;

/**
 * Modern Cart License
 *
 * @since 1.0.0
 */
class Modern_Cart_License {
	use Get_Instance;

	/**
	 * Wc_am_instance_id
	 *
	 * @since 1.0.0
	 * @access public
	 * @var string wc_am_instance_id.
	 */
	public $wc_am_instance_id;

	/**
	 * Wc_am_domain
	 *
	 * @since 1.0.0
	 * @access public
	 * @var string wc_am_domain.
	 */
	public $wc_am_domain;

	/**
	 * Wc_am_software_version
	 *
	 * @since 1.0.0
	 * @access public
	 * @var string wc_am_software_version.
	 */
	public $wc_am_software_version;

	/**
	 * Product_id Product ID
	 *
	 * @since 1.0.0
	 * @access public
	 * @var string product_id.
	 */
	public $product_id;

	/**
	 * Activate_status License Status
	 *
	 * @since 1.0.0
	 * @access public
	 * @var string activate_status.
	 */
	public $activate_status;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		global $modern_cart_wcam_lib;
		$this->product_id             = MODERNCART_PRO_PRODUCT_ID;
		$this->wc_am_domain           = str_ireplace( [ 'http://', 'https://' ], '', home_url() ); // blog domain name.
		$this->wc_am_software_version = MODERNCART_PRO_VER;
		$this->wc_am_instance_id      = Helper::convert_to_string( get_option( 'wc_am_client_' . $this->product_id . '_instance' ) ); // A unique password generated for each installation.
		$this->activate_status        = Helper::convert_to_string( get_option( 'wc_am_client_' . $this->product_id . '_activated', 'Deactivated' ) );

		add_filter( 'plugin_action_links_' . MODERNCART_PRO_BASE, [ $this, 'license_popup_link' ] );

		add_action( 'admin_enqueue_scripts', [ $this, 'admin_scripts' ] );

		add_action( 'wp_ajax_modern_cart_activate_license', [ $this, 'activate_license' ] );

		add_action( 'wp_ajax_modern_cart_deactivate_license', [ $this, 'deactivate_license' ] );

		add_action( 'admin_head', [ $this, 'reset_license_info' ] );

		add_filter( 'wc_am_client_inactive_notice_override', '__return_false' );

		add_action( 'admin_notices', [ $this, 'inactive_notice' ] );

		add_action( 'wp_ajax_modern_cart_disable_activate_license_notice', [ $this, 'disable_activate_license_notice' ] );

		// Disabled un-install hook.
		add_filter( 'wc_am_uninstall_disable', '__return_true' );

		// Disabled un-install hook.
		remove_action( 'admin_menu', [ $modern_cart_wcam_lib, 'register_menu' ] );
		remove_action( 'admin_init', [ $modern_cart_wcam_lib, 'load_settings' ] );
	}

	/**
	 * Show action links on the plugin screen.
	 *
	 * @param   array<string> $links Plugin Action links.
	 * @return  array<string> $links Plugins modified links.
	 */
	public function license_popup_link( $links ) {

		$license_tab_url = admin_url( 'admin.php?page=moderncart_settings&path=settings&tab=moderncart_license' );
		if ( 'Deactivated' === $this->activate_status ) {
			$links['license_key'] = '<a href="' . esc_url( $license_tab_url ) . '" class="modern-cart-license-popup-open-button active" aria-label="' . esc_attr__( 'Activate License', 'modern-cart-woo' ) . '" style="color: #3db634;">' . esc_html__( 'Activate License', 'modern-cart-woo' ) . '</a>';
		} else {
			$links['license_key'] = '<a href="' . esc_url( $license_tab_url ) . '" class="modern-cart-license-popup-open-button inactive" aria-label="' . esc_attr__( 'Deactivate License', 'modern-cart-woo' ) . '" style="color: #f44336;">' . esc_html__( 'Deactivate License', 'modern-cart-woo' ) . '</a>';
		}

		return $links;
	}

	/**
	 * Enqueues the needed CSS/JS for Backend.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_scripts(): void {

		wp_register_script( 'modern-cart-admin-notice', MODERNCART_PRO_URL . 'admin-core/assets/js/admin-notice.js', [ 'jquery' ], MODERNCART_PRO_VER, true );

		$vars = [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'_nonce'  => wp_create_nonce( 'modern-cart-admin-notice-nonce' ),
		];

		wp_localize_script( 'modern-cart-admin-notice', 'ModernCart_ProAdminNoticeVars', $vars );
	}

	/**
	 * Disable the Activate License Notice
	 *
	 * @return void
	 */
	public function disable_activate_license_notice(): void {

		check_ajax_referer( 'modern-cart-admin-notice-nonce', 'security' );

		// Saving the `true` for 10 minutes into transient `my_transient`.
		set_transient( 'modern-cart-activate-license', true, 10 * MINUTE_IN_SECONDS );

		wp_send_json_success();
	}

	/**
	 * License Inactive Notice
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function inactive_notice(): void {

		if ( 'Activated' === $this->activate_status ) {
			return;
		}

		$expired = get_transient( 'modern-cart-activate-license' );

		// Is transient expired?
		if ( false !== $expired && ! empty( $expired ) ) {
			return;
		}

		wp_enqueue_script( 'modern-cart-admin-notice' );

		/* translators: %1$s Software Title, %2$s Plugin, %3$s Anchor opening tag, %4$s Anchor closing tag, %5$s Software Title. */
		$message = sprintf( __( 'The <strong>%1$s</strong> License Key has not been activated, so the %2$s is inactive! %3$sClick here%4$s to activate <strong>%5$s</strong>.', 'modern-cart-woo' ), 'Modern Cart for WooCommerce', 'plugin', '<a class="modern-cart-license-popup-open-button" href="' . esc_url( admin_url( 'admin.php?page=moderncart_settings&path=settings&tab=moderncart_license' ) ) . '">', '</a>', 'Modern Cart for WooCommerce' );

		$output  = '<div class="modern-cart-dismissible-license-notice notice notice-error is-dismissible">';
		$output .= '<p>' . wp_kses_post( $message ) . '</p>';
		$output .= '</div>';

		echo wp_kses_post( $output );
	}

	/**
	 * Reset License Info
	 *
	 * @since 1.0.0
	 */
	public function reset_license_info(): void {
		if ( ! isset( $_GET['modern-cart-license-reset'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		delete_option( 'wc_am_client_' . $this->product_id . '_activated' );
		delete_option( 'wc_am_client_' . $this->product_id . '_api_key' );
	}

	/**
	 * Deactivate license.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function deactivate_license(): void {

		$nonce    = Helper::convert_to_string( filter_input( INPUT_POST, 'security', FILTER_SANITIZE_STRING ) );
		$response = [];

		if ( ! wp_verify_nonce( $nonce, 'modern_cart_license_deactivation_nonce' ) ) {

			$response['data'] = [
				'error' => __( 'Oops! Security nonce is invalid.', 'modern-cart-woo' ),
			];

			wp_send_json( $response );
		}

		$default_args = [
			'api_key' => '',
		];

		wp_cache_flush();

		$args = Helper::convert_to_array( get_option( 'wc_am_client_' . $this->product_id . '_api_key', $default_args ) );

		$response = $this->deactivate_request( $args );

		update_option( 'wc_am_client_' . $this->product_id . '_activated', 'Deactivated' );

		update_option( 'wc_am_client_' . $this->product_id . '_api_key', $default_args );

		// Store the API key which used for plugin update.
		$new_data = [
			'wc_am_client_' . $this->product_id . '_api_key' => $default_args['api_key'],
		];
		update_option( 'wc_am_client_' . $this->product_id, $new_data );

		wp_send_json_success( $response );
	}

	/**
	 * Sends the request to deactivate to the API Manager.
	 *
	 * @param array<mixed> $args args.
	 *
	 * @return bool|string
	 */
	public function deactivate_request( $args ) {
		$defaults = [
			'request'    => 'deactivate',
			'product_id' => MODERNCART_PRO_PRODUCT_ID,
			'instance'   => $this->wc_am_instance_id,
			'object'     => $this->wc_am_domain,
		];

		$args       = wp_parse_args( $defaults, $args );
		$target_url = add_query_arg( 'wc-api', 'am-software-api', MODERNCART_PRO_SERVER_URL ) . '&' . http_build_query( $args );
		/** $target_url = esc_url_raw( $this->create_software_api_url( $args ) ); */
		$request = wp_safe_remote_post( $target_url, [ 'timeout' => 15 ] ); // phpcs:ignore WordPressVIPMinimum.Performance.RemoteRequestTimeout.timeout_timeout

		if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== 200 ) {
			// Request failed.
			return false;
		}

		return wp_remote_retrieve_body( $request );
	}

	/**
	 * Save All admin settings here
	 *
	 * @hook Modern_Cart_activate_license
	 *
	 * @return void
	 */
	public function activate_license(): void {

		$nonce    = Helper::convert_to_string( filter_input( INPUT_POST, 'security', FILTER_SANITIZE_STRING ) );
		$response = [];

		if ( ! wp_verify_nonce( $nonce, 'modern_cart_license_activation_nonce' ) ) {

			$response['data'] = [
				'error' => __( 'Oops! Security nonce is invalid.', 'modern-cart-woo' ),
			];

			wp_send_json( $response );
		}

		$license_key = isset( $_REQUEST['license_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['license_key'] ) ) : '';

		$args = [
			'api_key' => $license_key,
		];

		wp_cache_flush();

		$response = Helper::convert_to_array( json_decode( Helper::convert_to_string( $this->activation_request( $args ) ), true ) );
		/** $response = $this->request( 'activation', $license_key, $license_email ); */
		if ( true === $response['success'] && true === $response['activated'] ) {

			$data = [
				'api_key' => $license_key,
			];

			// Store the API key.
			update_option( 'wc_am_client_' . $this->product_id . '_api_key', $data );

			// Activate.
			update_option( 'wc_am_client_' . $this->product_id . '_activated', 'Activated' );

			// Store the API key which used for plugin update.
			$new_data = [
				'wc_am_client_' . $this->product_id . '_api_key' => $data['api_key'],
			];
			update_option( 'wc_am_client_' . $this->product_id, $new_data );

			wp_send_json_success( $response );
		}

		wp_send_json_error( $response );
	}

	/**
	 * Sends the request to activate to the API Manager.
	 *
	 * @param array<string> $args args.
	 *
	 * @return bool|string
	 */
	public function activation_request( $args ) {

		// If instance ID is not set, generate it.
		if ( empty( $this->wc_am_instance_id ) ) {

			$this->wc_am_instance_id = wp_generate_password( 12, false );

			update_option( 'wc_am_client_' . $this->product_id . '_instance', $this->wc_am_instance_id );
		}

		$defaults = [
			'request'          => 'activate',
			'product_id'       => MODERNCART_PRO_PRODUCT_ID,
			'instance'         => $this->wc_am_instance_id,
			'object'           => $this->wc_am_domain,
			'software_version' => $this->wc_am_software_version,
		];

		$args = wp_parse_args( $defaults, $args );

		$target_url = add_query_arg( 'wc-api', 'am-software-api', MODERNCART_PRO_SERVER_URL ) . '&' . http_build_query( $args );
		$request    = wp_safe_remote_post( $target_url, [ 'timeout' => 15 ] ); // phpcs:ignore WordPressVIPMinimum.Performance.RemoteRequestTimeout.timeout_timeout

		$is_error = $this->has_activation_api_error( $request );

		if ( $is_error['error'] ) {

			return wp_json_encode(
				[
					'success'    => false,
					'error_code' => $is_error['error_code'],
					'error'      => $is_error['error_message'],
					'data'       => [
						'error_code' => $is_error['error_code'],
						'error'      => $is_error['error_message'],
					],
				],
			);
		}

		return wp_remote_retrieve_body( $request );
	}

	/**
	 * Check is error in the received response.
	 *
	 * @param array<string,mixed>|\WP_Error $response The response from wp_remote_get/post or a WP_Error.
	 * @return array<string,mixed>
	 * @since 1.0.0
	 */
	public function has_activation_api_error( $response ) {

		$result = [
			'error'         => false,
			'error_message' => __( 'No error found.', 'modern-cart-woo' ),
			'error_code'    => 0,
		];

		if ( is_wp_error( $response ) ) {

			$msg        = $response->get_error_message();
			$error_code = $response->get_error_code();

			$result['error']         = true;
			$result['error_message'] = $msg;
			$result['error_code']    = $error_code;

		} elseif ( ! empty( wp_remote_retrieve_response_code( $response ) ) && ! in_array( wp_remote_retrieve_response_code( $response ), [ 200, 201, 204 ], true ) ) {

			$error_message = ! empty( wp_remote_retrieve_response_message( $response ) ) ? wp_remote_retrieve_response_message( $response ) : '';
			$error_body    = ! empty( wp_remote_retrieve_body( $response ) ) ? wp_kses( wp_remote_retrieve_body( $response ), '<p>' ) : '';

			/* Translators: %1$s: HTML, %2$s: HTML, %3$s: HTML */
			$blocked_message = strpos( $error_body, 'MalCare' ) ? sprintf( __( 'Sorry for the inconvenience, but your website seems to be having trouble connecting to our licensing system. %1$s Please open a technical %2$ssupport ticket%3$s and share the server\'s outgoing IP address.', 'modern-cart-woo' ), '<br><br>', '<a href="https://cartflows.com/support" target="_blank">', '</a>' ) : '';

			$result['error']         = true;
			$result['error_message'] = $error_message . '<br>' . $blocked_message;
			$result['error_code']    = wp_remote_retrieve_response_code( $response );
		} else {
			$result['response_code'] = wp_remote_retrieve_response_code( $response );
		}

		return $result;
	}
}

/**
 * Initialize class object with 'get_instance()' method
 */
Modern_Cart_License::get_instance();
