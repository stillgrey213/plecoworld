<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class B2BKing_Purchase_Order_Gateway_Blocks extends AbstractPaymentMethodType {

    private $gateway;
    protected $name = 'B2BKing_Purchase_Order_Gateway';// your payment gateway name

    public function initialize() {
        $this->settings = get_option( 'woocommerce_B2BKing_Purchase_Order_Gateway_settings', [] );
        if ( class_exists( 'B2BKing_Purchase_Order_Gateway' ) ) {
            $this->gateway = new B2BKing_Purchase_Order_Gateway();
            $this->gateway->instructions = ''; // do not show instructions twice

        }
    }

    public function is_active() {
        if ( ! class_exists( 'B2BKing_Purchase_Order_Gateway' ) ) {
            return false;
        }
        return $this->gateway->is_available();
    }

    public function get_payment_method_script_handles() {


        // Add the type="module" attribute
        add_filter('script_loader_tag', function ($tag, $handle, $src) {
            if ($handle === 'b2bking-purchase-order-gateway-integration') {
                $tag = '<script type="module" src="' . esc_url($src) . '"></script>';
            }
            return $tag;
        }, 10, 3);

        wp_register_script(
            'b2bking-purchase-order-gateway-integration',
            plugin_dir_url(__FILE__) . 'purchase-order-checkout.js',
            [   
                'wc-blocks-checkout',
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            null,
            true
        );
        if( function_exists( 'wp_set_script_translations' ) ) {            
            wp_set_script_translations( 'b2bking-purchase-order-gateway-integration');
        }

        $data_to_be_passed = $this->get_payment_method_data();
        wp_localize_script( 'b2bking-purchase-order-gateway-integration', 'b2bking_po_settings', $data_to_be_passed );
        
        return [ 'b2bking-purchase-order-gateway-integration' ];
    }

    public function get_payment_method_data() {

        if ( ! class_exists( 'B2BKing_Purchase_Order_Gateway' ) ) {
            return [];
        }
        $gateway = $this->gateway;
        $values = array(
            'title'                => $this->get_setting( 'title' ),
            'description'          => $this->get_setting( 'description' ),
            'supports'             => $this->get_supported_features(),
            'po_number_required'   => apply_filters( 'b2bking_po_number_optional', $gateway->get_option( 'po_number_required' ) !== 'yes' ) ? false : true,
            'allow_po_document'    => apply_filters( 'b2bking_allow_po_document', $gateway->get_option( 'allow_po_document' ) === 'yes' ),
            'po_document_required' => $gateway->get_option( 'po_document_required' ) === 'yes',
            'security'             => wp_create_nonce( 'b2bking_security_nonce' ),
            'ajaxurl'              => admin_url( 'admin-ajax.php' ),
        );

        return $values;
    }
    public function get_supported_features() {
        $payment_gateways = WC()->payment_gateways->payment_gateways();
        return $payment_gateways[ $this->name ]->supports;
    }

}
?>