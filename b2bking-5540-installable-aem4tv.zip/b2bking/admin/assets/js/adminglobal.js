/**
*
* JavaScript file that has global action in the admin menu
*
*/
(function($){

	"use strict";

	$( document ).ready(function() {

		var buttonclass = 'b2bking-btn-gray';

		var last_reports_loading_time = 0;
		var latest_reports_data = '';
		var reportstable;
		var rules_in_queue = 0;
		var last_toast_success_fired_time = Date.now();
		var page_slug = b2bking.pageslug;
		var old_page_slug = 'none';
		var availablepages = ['groups', 'b2c_users', 'logged_out_users', 'customers', 'dashboard', 'reports', 'group_rules_pro', 'group_rules_pro_log', 'group_rule_pro_editor', 'dynamic_rules_pro', 'dynamic_rule_pro_editor', 'early_access'];
		var availablepagesb2bking = ['b2bking_groups', 'b2bking_b2c_users', 'b2bking_logged_out_users', 'b2bking_customers', 'b2bking_dashboard', 'b2bking_reports','b2bking_group_rules_pro','b2bking_group_rules_log','b2bking_group_rule_pro_editor', 'b2bking_dynamic_rules_pro', 'b2bking_dynamic_rule_pro_editor','b2bking_early_access'];
		var availableposts = ['b2bking_conversation', 'b2bking_offer', 'b2bking_rule', 'b2bking_custom_role', 'b2bking_custom_field','b2bking_group','b2bking_grule'];

		var pages_have_assets = ['group_rules_pro','group_rules_pro_log','group_rule_pro_editor', 'dynamic_rules_pro', 'dynamic_rule_pro_editor','early_access'];
		
		var page_css_assets = {
			'group_rules_pro': 'group-rules-pro.css',
			'group_rule_pro_editor': 'group-rule-pro-editor.css',
			'group_rules_pro_log': 'group-rules-pro-log.css',
			'dynamic_rules_pro': 'dynamic-rules-pro.css',
			'dynamic_rule_pro_editor': 'dynamic-rule-pro-editor.css',
			'early_access': 'access.css',
		};


		// if current menu open is b2bking, hide the update count
		if (jQuery('.toplevel_page_b2bking').hasClass('wp-menu-open')){
			// remove
			jQuery('.toplevel_page_b2bking').find('.wp-menu-name .update-plugins').css('display','none');
		}

		window.page_switch = function(switchto, userid = 0, ruleid = 0){

			// 1. Replace current page content with loader
			// add overlay and loader
			jQuery('#wpbody-content').prepend('<div id="b2bking_admin_overlay"><img class="b2bking_loader_icon_button" src="'+b2bking.loaderurl+'">');

			// 2. Get page content
			var datavar = {
		        action: 'b2bking_get_page_content',
		        security: b2bking.security,
		        page: switchto,
		        userid: userid,
		        rule_id: ruleid
		    };

			// Timeout mechanism for loading issues
			var loadingTimeout = setTimeout(function(){
				if (jQuery('#b2bking_admin_overlay').length > 0) {
					var errorHtml = '<div style="' +
						'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(25, 24, 33, 0.95); ' +
						'display: flex; align-items: center; justify-content: center; z-index: 999999; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;' +
						'">' +
						'<div style="' +
						'background: white; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); ' +
						'padding: 40px; max-width: 480px; width: 90%; text-align: center; position: relative;' +
						'">' +
						'<div style="' +
						'width: 64px; height: 64px; background: linear-gradient(135deg, #906a1d, #b8860b); ' +
						'border-radius: 50%; margin: 0 auto 24px; display: flex; align-items: center; justify-content: center;' +
						'">' +
						'<svg width="32" height="32" viewBox="0 0 512 512" style="color: white;">' +
						'<path d="M104.426,139.813l83.563,83.781c14.344-13.766,26.781-25.703,36.109-34.672l-84.297-84.5l-10.313-45.719 L54.27,12.985L33.629,33.642L12.988,54.282l45.719,75.219L104.426,139.813z" fill="currentColor"/>' +
						'<path d="M358.363,276.298L481.926,399.47c22.781,22.766,22.781,59.688,0,82.469c-22.781,22.766-59.688,22.766-82.469,0 L275.895,358.767L358.363,276.298z" fill="currentColor"/>' +
						'<path d="M459.957,203.407c42.547-38.609,49.656-82.484,40.141-119.484c-0.281-2.938-0.984-5.406-3.547-7.25 l-8.563-7.016c-1.484-1.391-3.484-2.063-5.484-1.875c-2.016,0.203-3.844,1.234-5.031,2.875l-49.25,64.031 c-1.375,1.891-3.594,2.969-5.922,2.891l-17.875,1.313c-1.531-0.047-3.016-0.594-4.219-1.563l-34.531-29.266 c-1.406-1.141-2.328-2.766-2.563-4.563l-2.141-16.188c-0.25-1.781,0.203-3.594,1.266-5.063l46.109-62.641 c2.094-2.875,1.688-6.859-0.906-9.281l-11.188-8.75c-2.188-2.031-4.672-1.75-8.063-1.094 c-31.844,6.281-86.219,37.125-100.016,79.75c-12.156,37.516-7.922,63.969-7.922,63.969c0,21.141-6.953,41.516-15.5,50.063 L24.504,424.923c-0.469,0.422-0.922,0.859-1.375,1.313c-19.844,19.844-19.813,52.047-0.641,71.219s51.859,19.672,71.703-0.172 c0.922-0.922,1.813-1.875,2.641-2.859l231.672-250.438C357.004,218.61,413.426,245.642,459.957,203.407z" fill="currentColor"/>' +
						'</svg>' +
						'</div>' +
						'<h3 style="' +
						'color: #191821; font-size: 20px; font-weight: 600; margin: 0 0 12px; line-height: 1.3;' +
						'">Page Loading Issue Detected</h3>' +
						'<p style="' +
						'color: #666; font-size: 15px; line-height: 1.5; margin: 0 0 24px;' +
						'">The page is taking longer than expected to load. This is typically caused by a JavaScript error or plugin conflict in your WordPress admin.</p>' +
						'<div style="' +
						'background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; padding: 16px; margin: 0 0 24px; text-align: left;' +
						'">' +
						'<p style="' +
						'color: #495057; font-size: 14px; margin: 0; font-weight: 500;' +
						'">💡 <strong>Quick Solution:</strong> Click the button below to disable AJAX loading and use standard page navigation.</p>' +
						'</div>' +
						'<div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">' +
						'<button type="button" id="b2bking_disable_ajax_loading" style="' +
						'background: linear-gradient(135deg, #906a1d, #b8860b); color: white; border: none; ' +
						'padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 600; ' +
						'transition: all 0.2s ease; box-shadow: 0 4px 12px rgba(144, 106, 29, 0.3);' +
						'">Disable AJAX Loading</button>' +
						'<a href="https://woocommerce-b2b-plugin.com/docs/issue-b2bking-pages-do-not-load-infinite-loading-icon/" target="_blank" style="' +
						'background: white; color: #191821; border: 2px solid #e9ecef; ' +
						'padding: 10px 20px; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 500; ' +
						'transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 8px;' +
						'">' +
						'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" style="color: #906a1d;">' +
						'<path d="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z" fill="currentColor"/>' +
						'</svg>' +
						'Learn More' +
						'</a>' +
						'</div>' +
						'</div>' +
						'</div>';
					jQuery('#b2bking_admin_overlay').html(errorHtml);
					
					// Add hover effects
					jQuery('#b2bking_disable_ajax_loading').hover(
						function(){ jQuery(this).css('transform', 'translateY(-2px)').css('box-shadow', '0 6px 16px rgba(144, 106, 29, 0.4)'); },
						function(){ jQuery(this).css('transform', 'translateY(0)').css('box-shadow', '0 4px 12px rgba(144, 106, 29, 0.3)'); }
					);
					
					jQuery('#b2bking_admin_overlay a').hover(
						function(){ jQuery(this).css('border-color', '#906a1d').css('color', '#906a1d'); },
						function(){ jQuery(this).css('border-color', '#e9ecef').css('color', '#191821'); }
					);
					
					jQuery('#b2bking_disable_ajax_loading').on('click', function(){
						jQuery(this).text('Disabling...').prop('disabled', true);
						jQuery.post(ajaxurl, {
							action: 'b2bking_disable_ajax_loading',
							security: b2bking.security
						}, function(){
							location.reload();
						});
					});
				}
			}, 7000);

			jQuery.post(ajaxurl, datavar, function(response){

				// Clear timeout if request completes successfully
				clearTimeout(loadingTimeout);

				// the current one becomes the old one
				old_page_slug = page_slug;

				// Handle dashboard/reports (no asset waiting needed)
				if (switchto === 'dashboard' || switchto === 'reports'){
					let preloaderhtml = '<div class="b2bkingpreloader"><img class="b2bking_loader_icon_button" src="'+b2bking.loaderurl+'"></div>';
					jQuery('#wpbody-content').html(preloaderhtml);
					setTimeout(function(){
						jQuery('.b2bkingpreloader').after(response);
					}, 10);
				} else {
					// if pages have assets, show overlay until assets are loaded
					if (pages_have_assets.includes(switchto)){

						// show content with overlay until assets load
						jQuery('#wpbody-content').html('<div id="b2bking_admin_overlay"><img class="b2bking_loader_icon_button" src="'+b2bking.loaderurl+'"></div><div style="display:none">'+response+'</div>');
						
						// Poll for CSS to load
						var checkCSS = function() {
							var cssFile = page_css_assets[switchto];
							var cssLink = document.querySelector('link[href*="' + cssFile + '"]');
							var cssLoaded = cssLink && cssLink.sheet;
							
							if (cssLoaded) {
								// CSS ready, remove overlay and show content
								jQuery('#b2bking_admin_overlay').remove();
								jQuery('#wpbody-content div[style*="display:none"]').show().removeAttr('style');
								
								// Scroll to top when opening rule editor
								if (switchto === 'dynamic_rule_pro_editor' || switchto === 'group_rule_pro_editor') {
									jQuery('html, body').scrollTop(0);
								}
							} else {
								// CSS not ready, check again in 100ms
								setTimeout(checkCSS, 100);
							}
						};
						checkCSS();
					} else {
						// no assets, show page directly
						jQuery('#wpbody-content').html(response);
					}
				}

				// if pageslug contains user, remove it
				let slugtemp = page_slug.split('&user=')[0];			

				// remove current page slug and set new page slug
				jQuery('body').removeClass('admin_page_'+slugtemp);
				jQuery('body').removeClass('b2bking_page_'+slugtemp);
				jQuery('body').removeClass('toplevel_page_b2bking');

				if (b2bking.whitelabelname !== 'b2bking'){
					jQuery('body').removeClass(b2bking.whitelabelname+'_page_'+slugtemp);
				}

				jQuery('#b2bking_admin_style-css').prop('disabled', true);
				jQuery('#b2bking_style-css').prop('disabled', true);
				jQuery('#semantic-css').prop('disabled', true);


				// remove post php because page switch can never switch to a single post yet
				jQuery('body').removeClass('post-php');

				let new_page_slug = 'b2bking_'+switchto;

				// if post type, remove 'b2bking_edit'
				if (new_page_slug.startsWith('b2bking_edit')){
					new_page_slug = new_page_slug.split('b2bking_edit_')[1];	
				}

				if (userid!== 0){
					new_page_slug = new_page_slug+'&user='+userid;
				}

				// link difference between pages and posts
				let newlocation = window.location.href.replace('='+page_slug,'='+new_page_slug);

				// removed paged
				newlocation = newlocation.split('&paged=')[0];
				newlocation = newlocation.split('&action=edit')[0];
				
				// Clean up rule_id parameters - remove all existing rule_id parameters first
				newlocation = newlocation.replace(/&rule_id=[^&]*/g, '');
				newlocation = newlocation.replace(/\?rule_id=[^&]*&/, '?');
				newlocation = newlocation.replace(/\?rule_id=[^&]*$/, '');
				
				// Add rule_id parameter only if ruleid is not 0
				if (ruleid !== 0) {
					// Add rule_id parameter
					if (newlocation.includes('?')) {
						newlocation += '&rule_id=' + ruleid;
					} else {
						newlocation += '?rule_id=' + ruleid;
					}
				}

				if (newlocation.includes('admin.php?page=') && availableposts.includes(new_page_slug)){
					newlocation = newlocation.replace('admin.php?page=','edit.php?post_type=');
				}

				if (newlocation.includes('edit.php?post_type=') && ( availablepages.includes(new_page_slug) || availablepagesb2bking.includes(new_page_slug)) ){
					newlocation = newlocation.replace('edit.php?post_type=','admin.php?page=');
				}

				if (newlocation.includes('post.php?post=') && ( availablepages.includes(new_page_slug) || availablepagesb2bking.includes(new_page_slug)) ){
					newlocation = newlocation.replace('post.php?post=','admin.php?page=');
				}

				if (newlocation.includes('post.php?post=') && availableposts.includes(new_page_slug)){
					newlocation = newlocation.replace('post.php?post=','edit.php?post_type=');
				}

				// set page url
				window.history.pushState('b2bking_'+switchto, '', newlocation);

				page_slug = new_page_slug;

				// if pageslug contains user, remove it
				slugtemp = page_slug.split('&user=')[0];
				jQuery('body').addClass('b2bking_page_'+slugtemp);

				jQuery('body').removeClass('b2bking_page_initial');
				jQuery('body').addClass('b2bking_page_not_initial');

				if (b2bking.whitelabelname !== 'b2bking'){
					jQuery('body').addClass(b2bking.whitelabelname+'_page_'+slugtemp);
				}

				// expand b2bking menu if not already open (expanded)
				$('.toplevel_page_b2bking').removeClass('wp-not-current-submenu');
				$('.toplevel_page_b2bking').addClass('wp-has-current-submenu wp-menu-open');

				
				// initialize JS
				initialize_elements();

				initialize_on_b2bking_page_load();

				// Scroll to top when opening rule editor
				if (switchto === 'dynamic_rule_pro_editor' || switchto === 'group_rule_pro_editor') {
					jQuery('html, body').scrollTop(0);
				}

				// remove browser 'Leave Page?' warning
				jQuery(window).off('beforeunload');



			});

		}

		if (window.location.href.indexOf("b2bking") > -1) {
			jQuery('body').addClass('b2bking_page_initial');
		}

		initialize_elements();

		$('body').on('click','.b2bking_admin_groups_main_container_main_row_right_box_first', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('b2c_users');
			}
		});

		$('body').on('click','.b2bking_admin_groups_main_container_main_row_right_box_second', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('logged_out_users');
			}
		});

		$('body').on('click','.b2bking_above_top_title_button_right_button, .b2bking_go_groups', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('groups');
			}
		});

		var linkstext = '<a href="'+b2bking.groupspage+'" class="page-title-action b2bking_go_groups">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.edit-php.post-type-b2bking_group .page-title-action').after(linkstext);
		}, 650);

		var linkstext3 = '<a href="'+b2bking.b2bgroups_link+'" class="page-title-action b2bking_go_edit_groups">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_group .page-title-action').after(linkstext3);
		}, 650);

		// GROUP RULES BACK BUTTON
		var linkstext4 = '<a href="'+b2bking.group_rules_link+'" class="page-title-action b2bking_go_edit_grules">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_grule .page-title-action').after(linkstext4);
		}, 650);

		$('body').on('click','.b2bking_go_edit_grules', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_grule');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_grule .page-title-action').after(linkstext4);
				}, 650);
			}
		});

		// whitelabel
		var field = document.querySelector('[name="b2bking_whitelabel_pluginname_setting"]');
		if (field !== null && field !== undefined){
			field.addEventListener('keypress', function ( event ) {  
			   var key = event.keyCode;
			    if (key === 32) {
			      event.preventDefault();
			    }
			});
		}
		

		// CONVERSATION BACK BUTTON
		var linkstext5 = '<a href="'+b2bking.conversations_link+'" class="page-title-action b2bking_go_edit_conversations">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_conversation .page-title-action').after(linkstext5);
		}, 650);

		$('body').on('click','.b2bking_go_edit_conversations', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_conversation');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_conversation .page-title-action').after(linkstext5);
				}, 650);
			}
		});

		// OFFER BACK BUTTON
		var linkstext6 = '<a href="'+b2bking.offers_link+'" class="page-title-action b2bking_go_edit_offers">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_offer .page-title-action').after(linkstext6);
		}, 650);

		$('body').on('click','.b2bking_go_edit_offers', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_offer');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_offer .page-title-action').after(linkstext6);
				}, 650);
			}
		});

		// DYNAMIC RULES BACK BUTTON
		var linkstext7 = '<a href="'+b2bking.dynamic_rules_link+'" class="page-title-action b2bking_go_edit_rules">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_rule .page-title-action').after(linkstext7);
		}, 650);

		$('body').on('click','.b2bking_go_edit_rules', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_rule');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_rule .page-title-action').after(linkstext7);
				}, 650);
			}
		});

		// REGISTRATION ROLES BACK BUTTON
		var linkstext8 = '<a href="'+b2bking.roles_link+'" class="page-title-action b2bking_go_edit_roles">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_custom_role .page-title-action').after(linkstext8);
		}, 650);

		$('body').on('click','.b2bking_go_edit_roles', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_custom_role');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_custom_role .page-title-action').after(linkstext8);
				}, 650);
			}
		});

		// REGISTRATION FIELDS BACK BUTTON
		var linkstext9 = '<a href="'+b2bking.roles_link+'" class="page-title-action b2bking_go_edit_fields">'+b2bking.goback_text+'</a>';
		setTimeout(function(){
				$('.post-php.post-type-b2bking_custom_field .page-title-action').after(linkstext9);
		}, 650);

		$('body').on('click','.b2bking_go_edit_fields', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_custom_field');

				setTimeout(function(){
					$('.post-php.post-type-b2bking_custom_field .page-title-action').after(linkstext9);
				}, 650);
			}
		});

		$('body').on('click','.b2bking_admin_groups_main_container_main_row_left_box, .b2bking_go_edit_groups', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('edit_b2bking_group');
				var linkstext2 = '<a href="'+b2bking.groupspage+'" class="page-title-action b2bking_go_groups">'+b2bking.goback_text+'</a>';

				setTimeout(function(){
					$(".page-title-action").after(linkstext2);
				}, 650);
			}
		});


		
		function initialize_elements(){

			// Move header to top of page
			jQuery('#wpbody-content').prepend(jQuery('#b2bking_admin_header_bar').detach());


			/* Customers */
			//initialize admin customers table if function exists (we are in the Customers panel)
			if (typeof $('#b2bking_admin_customers_table').DataTable === "function") { 
				if (parseInt(b2bking.b2bking_customers_panel_ajax_setting) !== 1){
					$('#b2bking_admin_customers_table').DataTable({
						"retrieve": true,
						"stateSave": true,
						"stateSaveParams": function (settings, data) {
							return {
								time: data.time,
								start: 0,
								length: data.length,
								order: data.order,
								search: data.search,
								columns: data.columns
							};
						},
						"stateLoadParams": function (settings, data) {
							data.start = 0;
							return data;
						},
			            "language": {
			                "url": b2bking.datatables_folder+b2bking.purchase_lists_language_option+'.json'
			            },
			            dom: 'Brtip',
			            buttons: {
			                buttons: [
			                    { extend: 'csvHtml5', className: buttonclass, text: '↓ CSV', exportOptions: { columns: ":visible" } },
			                    {
	                                extend: 'pdfHtml5',
	                                className: buttonclass,
	                                text: '↓ PDF',
	                                exportOptions: { columns: ":visible" },
	                                customize: function(doc) {
	                                    if(b2bking.pdf_download_font !== 'standard'){
	                                        pdfMake.fonts = {
	                                            Customfont: {
	                                                normal: b2bking.pdf_download_font,
	                                                bold: b2bking.pdf_download_font,
	                                                italics: b2bking.pdf_download_font,
	                                                bolditalics: b2bking.pdf_download_font
	                                            }
	                                        };
	                                        doc.defaultStyle = {
	                                            font: 'Customfont'
	                                        };
	                                    }
	                                }
	                            },
	                            { extend: 'print', className: buttonclass, text: b2bking.print, exportOptions: { columns: ":visible" } },
			                    { extend: 'colvis', className: buttonclass, text: b2bking.edit_columns },
			                ]
			            },
			        });

			        
				} else {
		       		$('#b2bking_admin_customers_table').DataTable({
		       			"retrieve": true,
		       			"language": {
		       			    "url": b2bking.datatables_folder+b2bking.purchase_lists_language_option+'.json'
		       			},
		       			"processing": true,
		       			"serverSide": true,
		       			"ordering": false,
		       			"info": true,
		       		    "ajax": {
		       		   		"url": ajaxurl,
		       		   		"type": "POST",
		       		   		"data":{
		       		   			action: 'b2bking_admin_customers_ajax',
		       		   			security: b2bking.security,
		       		   		}
		       		   	},
		       		    "stateSave": true,
		       		    "stateSaveParams": function (settings, data) {
		       		        // Only save column visibility and search state, not pagination
		       		        return {
		       		            time: data.time,
		       		            start: 0, // Always start from first page
		       		            length: data.length,
		       		            order: data.order,
		       		            search: data.search,
		       		            columns: data.columns
		       		        };
		       		    },
		       		    "stateLoadParams": function (settings, data) {
		       		        // Always load from first page but keep other settings
		       		        data.start = 0;
		       		        return data;
		       		    },
			            dom: 'Brtip',
			            buttons: {
			                buttons: [
			                    { extend: 'csvHtml5', className: buttonclass, text: '↓ CSV', exportOptions: { columns: ":visible" } },
    		                    {
                                    extend: 'pdfHtml5',
                                    className: buttonclass,
                                    text: '↓ PDF',
                                    exportOptions: { columns: ":visible" },
                                    customize: function(doc) {
                                        if(b2bking.pdf_download_font !== 'standard'){
                                            pdfMake.fonts = {
                                                Customfont: {
                                                    normal: b2bking.pdf_download_font,
                                                    bold: b2bking.pdf_download_font,
                                                    italics: b2bking.pdf_download_font,
                                                    bolditalics: b2bking.pdf_download_font
                                                }
                                            };
                                            doc.defaultStyle = {
                                                font: 'Customfont'
                                            };
                                        }
                                    }
                                },
                                { extend: 'print', className: buttonclass, text: b2bking.print, exportOptions: { columns: ":visible" } },
			                    { extend: 'colvis', className: buttonclass, text: b2bking.edit_columns },
			                ]
			            },

		            });
				}

				// Custom toolbar bindings for customers table
				if ($('#b2bking_admin_customers_table').length) {
					var customersTable = $('#b2bking_admin_customers_table').DataTable();

					// Clear any saved search state on page load
					customersTable.search('').draw();
					$('#b2bking_dt_search_input').val('');

					// Replace empty-table message with image on each draw;
					// also re-inject the length wrapper inside dataTables_info (DT overwrites it on draw)
					var noProductsImg = $('#b2bking_admin_customers_table').data('noproducts-img');
					customersTable.on('draw', function() {
						var $empty = $('#b2bking_admin_customers_table tbody td.dataTables_empty');
						if ($empty.length) {
							$empty.html('<img src="' + noProductsImg + '" class="b2bking-dt-noresults-img" alt=""><span class="b2bking-dt-noresults-text">' + b2bking.no_customers_found + '</span>');
						}
						// Re-prepend the length wrapper if DT wiped it
						if (!$('#b2bking_dt_length_wrapper').parent().is('#b2bking_admin_customers_table_info')) {
							$('#b2bking_admin_customers_table_info').prepend($lengthWrapper);
						}
					});

					// Clicking a pending approval badge navigates to the registration data section
					$(document).on('click', '#b2bking_admin_customers_table .approval_badge.pending', function(e) {
						if ($(e.target).closest('a').length) { return; } // let the inner <a> handle it naturally
						var href = $(this).find('a').attr('href');
						if (href) { window.location.href = href; }
					});

					// CRM Hub icons — open CRM panel modal via AJAX
					$(document).on('click', '#b2bking_admin_customers_table .b2bking-crm-icon', function(e) {
						e.stopPropagation();
						var tab = $(this).data('tab') || 'overview';
						var userId = $(this).data('user-id');
						Swal.fire({
							width: 700,
							padding: 0,
							backdrop: 'rgba(15,17,23,0.25)',
							showCloseButton: true,
							showConfirmButton: false,
							customClass: { popup: 'b2bking-crm-swal-popup', closeButton: 'b2bking-crm-close-btn' },
							showClass: { popup: 'b2bking-crm-swal-enter', backdrop: 'swal2-backdrop-show' },
							hideClass: { popup: 'b2bking-crm-swal-exit', backdrop: 'swal2-backdrop-hide' },
							didOpen: function() {
								Swal.showLoading();
								$.post(ajaxurl, { action: 'b2bking_crm_panel', security: b2bking.security, user_id: userId, tab: tab }, function(response) {
									Swal.update({ html: response, showCloseButton: true, showConfirmButton: false });
									Swal.hideLoading();
								});
							}
						});
					});


					// Search toggle
					$('#b2bking_dt_search_toggle').on('click', function() {
						$('#b2bking_dt_search_input').toggleClass('b2bking-dt-search-collapsed');
						if (!$('#b2bking_dt_search_input').hasClass('b2bking-dt-search-collapsed')) {
							$('#b2bking_dt_search_input').focus();
						}
					});

					$('#b2bking_dt_search_input').on('keyup', function() {
						customersTable.search(this.value).draw();
					});

					// Length select — injected before the info text once DataTables signals fully ready
					var $lengthSelect = $('<select id="b2bking_dt_length_select" class="b2bking-dt-toolbar-select"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select>');
					// Use delegation — direct binding gets wiped by jQuery cleanData when DT rewrites the info div
					$(document).on('change', '#b2bking_dt_length_select', function() {
						customersTable.page.len($(this).val()).draw();
					});
					var $lengthWrapper = $('<div id="b2bking_dt_length_wrapper" class="b2bking-dt-length-wrapper"></div>')
						.append($('<span class="b2bking-dt-length-label">Rows:</span>'))
						.append($lengthSelect);
					$('#b2bking_admin_customers_table').one('init.dt', function() {
						$lengthSelect.val(customersTable.page.len());
						$('#b2bking_admin_customers_table_info').prepend($lengthWrapper);
					});
					// Export dropdown
					$('#b2bking_dt_export_toggle').on('click', function(e) {
						e.stopPropagation();
						$('#b2bking_dt_export_menu').toggle();
					});
					$('.b2bking-dt-dropdown-item').on('click', function() {
						customersTable.button('.buttons-' + $(this).data('export')).trigger();
						$('#b2bking_dt_export_menu').hide();
					});
					$(document).on('click.bk_export_close', function(e) {
						if (!$(e.target).closest('#b2bking_dt_export_toggle, #b2bking_dt_export_menu').length) {
							$('#b2bking_dt_export_menu').hide();
						}
					});

					// Column visibility — custom dropdown using DataTables column API
					function bkBuildColvisMenu() {
						var $menu = $('#b2bking_dt_colvis_menu').empty();
						customersTable.columns().every(function() {
							var col = this;
							var title = $(col.header()).text().trim();
							$('<button class="b2bking-dt-dropdown-item b2bking-dt-colvis-item">')
								.toggleClass('b2bking-dt-colvis-active', col.visible())
								.text(title)
								.on('click', function(e) {
									e.stopPropagation();
									col.visible(!col.visible());
									$(this).toggleClass('b2bking-dt-colvis-active', col.visible());
								})
								.appendTo($menu);
						});
					}

					$('#b2bking_dt_colvis_btn').on('click', function(e) {
						e.stopPropagation();
						bkBuildColvisMenu();
						$('#b2bking_dt_colvis_menu').toggle();
					});

					$(document).on('click.bk_colvis_close', function(e) {
						if (!$(e.target).closest('#b2bking_dt_colvis_btn, #b2bking_dt_colvis_menu').length) {
							$('#b2bking_dt_colvis_menu').hide();
						}
					});
				}
			}

			// CRM Panel tab switching
			$(document).off('click.bk_crm_tab').on('click.bk_crm_tab', '.b2bking-crm-tab-btn', function() {
				var $btn = $(this);
				var $panel = $(this).closest('.b2bking-crm-panel');
				$panel.find('.b2bking-crm-tab-btn').removeClass('active');
				$btn.addClass('active');
				$panel.find('.b2bking-crm-tab-pane').removeClass('active');
				$panel.find('.b2bking-crm-tab-pane[data-tab="'+$btn.data('tab')+'"]').addClass('active');
			});

			// CRM Notes save
			$(document).off('click.bk_crm_notes').on('click.bk_crm_notes', '.b2bking-crm-save-notes', function() {
				var $btn = $(this);
				var userId = $btn.data('user-id');
				var notes = $btn.closest('.b2bking-crm-notes-wrap').find('.b2bking-crm-notes-textarea').val();
				var $status = $btn.siblings('.b2bking-crm-notes-status');
				$btn.prop('disabled', true);
				$.post(ajaxurl, { action: 'b2bking_crm_save_notes', security: b2bking.security, user_id: userId, notes: notes }, function(response) {
					$btn.prop('disabled', false);
					$status.text(response.success ? b2bking.saved : b2bking.error).fadeIn().delay(2000).fadeOut();
				});
			});

			// CRM Files: download registration file
			$(document).off('click.bk_crm_dl_reg').on('click.bk_crm_dl_reg', '.b2bking-crm-file-dl-reg', function() {
				var att = $(this).data('attachment');
				if (parseInt(b2bking.download_go_to_file) === 1) {
					$.post(ajaxurl, { action: 'b2bkinghandledownloadrequest', security: b2bking.security, attachment: att }, function(url) {
						var a = document.createElement('a'); a.href = url; a.download = url.split('/').pop(); document.body.appendChild(a); a.click(); a.remove();
					});
				} else if (parseInt(b2bking.download_go_to_file) === 2) {
					window.open(b2bking.adminurl + 'upload.php?item=' + att, '_blank');
				} else {
					var a = document.createElement('a'); a.href = b2bking.ajaxurl + '?action=b2bkinghandledownloadrequest&security=' + b2bking.security + '&attachment=' + att; a.download = ''; document.body.appendChild(a); a.click(); a.remove();
				}
			});

			// CRM Files: download uploaded CRM file
			$(document).off('click.bk_crm_dl').on('click.bk_crm_dl', '.b2bking-crm-file-dl', function() {
				var att = $(this).data('attachment');
				var uid = $(this).data('user-id');
				$.post(ajaxurl, { action: 'b2bking_crm_download_file', security: b2bking.security, attachment_id: att, user_id: uid }, function(response) {
					if (response.success && response.data.url) {
						var a = document.createElement('a'); a.href = response.data.url; a.download = response.data.url.split('/').pop(); document.body.appendChild(a); a.click(); a.remove();
					}
				});
			});


			// CRM Files: view file in new tab (no forced download)
			$(document).off('click.bk_crm_view').on('click.bk_crm_view', '.b2bking-crm-file-view', function() {
				var att = $(this).data('attachment');
				var uid = $(this).data('user-id');
				$.post(ajaxurl, { action: 'b2bking_crm_download_file', security: b2bking.security, attachment_id: att, user_id: uid }, function(response) {
					if (response.success && response.data.url) {
						window.open(response.data.url, '_blank');
					}
				});
			});

			// CRM Files: remove file association
			$(document).off('click.bk_crm_del').on('click.bk_crm_del', '.b2bking-crm-file-del', function() {
				var att = $(this).data('attachment');
				var uid = $(this).data('user-id');
				var $row = $(this).closest('.b2bking-crm-file-row');
				$.post(ajaxurl, { action: 'b2bking_crm_remove_file', security: b2bking.security, attachment_id: att, user_id: uid }, function(response) {
					if (response.success) { $row.fadeOut(150, function() { $row.remove(); }); }
				});
			});

			// CRM Files: upload via WP Media Library
			$(document).off('click.bk_crm_upload').on('click.bk_crm_upload', '.b2bking-crm-upload-btn', function(e) {
				e.preventDefault();
				var $btn = $(this);
				var uid = $btn.data('user-id');
				if (typeof wp === 'undefined' || !wp.media) { return; }
				var frame = wp.media({ title: b2bking.select_file, button: { text: b2bking.use_file }, multiple: false });
				frame.on('select', function() {
					var att = frame.state().get('selection').first().toJSON();
					$.post(ajaxurl, { action: 'b2bking_crm_upload_file', security: b2bking.security, attachment_id: att.id, user_id: uid }, function(response) {
						if (response.success) {
							if (typeof Swal !== 'undefined' && Swal.isVisible()) {
								Swal.showLoading();
								$.post(ajaxurl, { action: 'b2bking_crm_panel', security: b2bking.security, user_id: uid, tab: 'files' }, function(html) {
									Swal.update({ html: html, showCloseButton: true, showConfirmButton: false });
									Swal.hideLoading();
								});
							} else {
								window.location.reload();
							}
						}
					});
				});
				frame.open();
			});

			// Dashboard
			if ($(".b2bkingpreloader").val()!== undefined){
				if (jQuery('#b2bking_admin_dashboard-css').val() === undefined){
					// add it to page
					jQuery('#chartist-css').after('<link rel="stylesheet" id="b2bking_admin_dashboard-css" href="'+b2bking.dashboardstyleurl+'" media="all">');
				}
				jQuery('#b2bking_admin_dashboard-css').prop('disabled', false);

				setTimeout(function(){
					// hide preloader and show page
					$(".b2bkingpreloader").fadeOut();
					$(".b2bking_dashboard_page_wrapper").show();

					if (jQuery('body').hasClass('b2bking_page_b2bking_reports')){
						// reports
					} else {
						// dashboard
						// draw chart
						drawDashboardSalesChart();
						$('#b2bking_dashboard_days_select').change(drawDashboardSalesChart);
					}
					
					//failsafe in case the page did not show, try again in 50 ms
					setTimeout(function(){
						dashboard_failsafe();
					}, 60);	
					setTimeout(function(){
						dashboard_failsafe();
					}, 110);
					setTimeout(function(){
						dashboard_failsafe();
					}, 150);
					setTimeout(function(){
						dashboard_failsafe();
					}, 350);		
					
				}, 35);
				
			} else {
				jQuery('#b2bking_admin_dashboard-css').prop('disabled', true);
			}

			// reports
			// load first chart in reports
			setTimeout(function(){
				$('#b2bking_reports_link_thismonth').click();
			}, 150);

			set_registration_fields_opacity();

			// toolbar
			let toolbarhtml = b2bking.toolbarhtml;
			if ( ($('body').hasClass('post-type-b2bking_rule') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_rule') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_grule') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_grule') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_offer') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_offer') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_quote_field') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_quote_field') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			// to add toolbar, activate this code
			/*
			if ( ($('body').hasClass('post-type-b2bking_custom_role') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_custom_role') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_custom_field') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_custom_field') ){
				jQuery(toolbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			*/

			// searchbar
			let searchbarhtml = b2bking.searchbarhtml;
			if ( ($('body').hasClass('post-type-b2bking_offer') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_offer') ){
				jQuery(searchbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_conversation') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_conversation') ){
				jQuery(searchbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}
			if ( ($('body').hasClass('post-type-b2bking_rule') && $('body').hasClass('b2bking_page_initial')) || $('body').hasClass('b2bking_page_b2bking_rule') ){
				jQuery(searchbarhtml).insertBefore('.tablenav.top .tablenav-pages');
			}

			var regformsvg = '<svg fill="#fff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52" enable-background="new 0 0 52 52" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <path d="M31.4,15.3h8.2c0.6,0,1.1-0.5,1.1-1.1l0,0c0-0.3-0.1-0.5-0.3-0.8L30.2,3.3C29.9,3.1,29.7,3,29.4,3l0,0 c-0.6,0-1.1,0.5-1.1,1.1v8.1C28.3,13.9,29.7,15.3,31.4,15.3z"></path> <path d="M49.5,25.7l-0.9-0.9c-0.6-0.6-1.5-0.6-2.2,0L34.5,36.7c-0.1,0.1,0,0.2,0,0.3v2.5c0,0.2,0,0.4,0.2,0.4h2.6 c0.1,0,0.2-0.1,0.3-0.1L49.5,28C50.2,27.2,50.2,26.3,49.5,25.7z"></path> <path d="M39.9,44.4h-1.8h-3.6h-1.7c-1.6,0-2.9-1.3-2.9-2.9v-5.4c0-0.8,0.2-1.6,0.9-2.1l9.5-9.5 c0.3-0.3,0.5-0.7,0.5-1.1v-2c0-0.8-0.7-1.5-1.5-1.5H28.3c-2.6,0-4.6-2.1-4.6-4.6V4.5C23.7,3.7,23,3,22.1,3H6.6C4.1,3,2,5.1,2,7.6 v36.8C2,46.9,4.1,49,6.6,49h29.4c2.2,0,4.2-1.6,4.6-3.7C40.7,44.9,40.3,44.4,39.9,44.4z M8.2,16.8c0-0.8,0.7-1.5,1.5-1.5h6.2 c0.9,0,1.5,0.7,1.5,1.5v1.5c0,0.8-0.7,1.5-1.5,1.5H9.7c-0.9,0-1.5-0.7-1.5-1.5V16.8z M23.7,36.7c0,0.8-0.7,1.5-1.5,1.5H9.7 c-0.9,0-1.5-0.7-1.5-1.5v-1.5c0-0.8,0.7-1.5,1.5-1.5h12.4c0.9,0,1.5,0.7,1.5,1.5V36.7z M26.8,27.5c0,0.8-0.7,1.5-1.5,1.5H9.7 c-0.9,0-1.5-0.7-1.5-1.5V26c0-0.8,0.7-1.5,1.5-1.5h15.5c0.9,0,1.5,0.7,1.5,1.5V27.5z"></path> </g> </g></svg>';

			// add registration form shortcodes button
			if ($('body').hasClass('post-type-b2bking_custom_field') && $('body').hasClass('b2bking_page_initial')){
				jQuery('<button id="b2bking_registration_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span></span> &nbsp;&nbsp;'+b2bking.registration_form_shortcodes_text+'</button>').insertBefore('.tablenav.top .tablenav-pages');
				jQuery('.top .tablenav-pages').css('display','none');
			} else {
				if ($('body').hasClass('b2bking_page_b2bking_custom_field') && $('body').hasClass('b2bking_page_not_initial')){
					jQuery('<button id="b2bking_registration_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span> &nbsp;&nbsp;'+b2bking.registration_form_shortcodes_text+'</button>').insertBefore('.tablenav.top .tablenav-pages');
					jQuery('.top .tablenav-pages').css('display','none');
				}
			}
			if ($('body').hasClass('post-type-b2bking_custom_role') && $('body').hasClass('b2bking_page_initial')){
				jQuery('<button id="b2bking_registration_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span></span> &nbsp;&nbsp;'+b2bking.registration_form_shortcodes_text+'</button>').insertBefore('.tablenav.top .tablenav-pages');
				jQuery('.top .tablenav-pages').css('display','none');
			} else {
				if ($('body').hasClass('b2bking_page_b2bking_custom_role') && $('body').hasClass('b2bking_page_not_initial')){
					jQuery('<button id="b2bking_registration_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span> &nbsp;&nbsp;'+b2bking.registration_form_shortcodes_text+'</button>').insertBefore('.tablenav.top .tablenav-pages');
					jQuery('.top .tablenav-pages').css('display','none');
				}
			}
			jQuery('<button id="b2bking_registration_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span></span> &nbsp;&nbsp;'+b2bking.registration_form_shortcodes_text+'</button>').insertAfter('.b2bking_registrationsettings_tab h2.block.header .content');
			jQuery('<button id="b2bking_bulkorder_form_shortcode_button" type="button"><span class="dashicons">'+regformsvg+'</span></span> &nbsp;&nbsp;'+b2bking.bulkorder_form_shortcodes_text+'</button>').insertAfter('.b2bking_bulkordersettings_tab h2.block.header .content');

			// init group rules pro module
			if (jQuery('#b2bking_group_rules_pro_main_container').length === 1){
				initB2BKingGroupRulesPro();
			}

			// init group rules pro editor module
			if (jQuery('#b2bking_group_rule_pro_editor_main_container').length === 1){
				initB2BKingGroupRuleProEditor();
			}

			// init group rules pro log module
			if (jQuery('#b2bking_group_rules_pro_log_main_container').length === 1){
				initB2BKingGroupRulesProLog();
			}

			// init dynamic rules pro module
			if (jQuery('#b2bking_dynamic_rules_pro_main_container').length === 1){
				initB2BKingDynamicRulesPro();
			}

			// init dynamic rules pro editor module
			if (jQuery('#b2bking_dynamic_rule_pro_editor_main_container').length === 1){
				initB2BKingDynamicRuleProEditor();
			}

			// init early access module
			if (jQuery('.b2bking-early-access-container').length === 1){
				initB2BKingEarlyAccess();
			}

		}

		function initialize_on_b2bking_page_load(){
			// run default WP ADMIN JS FILES
			$.ajax({ url: b2bking.inlineeditpostjsurl, dataType: "script", });
			$.ajax({ url: b2bking.commonjsurl, dataType: "script", });

			/* sort drag drop backend */
	 		if (parseInt(jQuery('.post-type-b2bking_custom_field').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_custom_field').length) !== 0){
	 			enable_sortable_type('b2bking_custom_field');
	 		}

	 		if (parseInt(jQuery('.post-type-b2bking_custom_role').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_custom_role').length) !== 0){
	 			enable_sortable_type('b2bking_custom_role');
	 		}

	 		if (parseInt(jQuery('.post-type-b2bking_quote_field').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_quote_field').length) !== 0){
	 			enable_sortable_type('b2bking_quote_field');
	 		}

		}

		function dashboard_failsafe(){
			if ($(".b2bking_dashboard_page_wrapper").css('display') !== 'block'){

				if (jQuery('body').hasClass('b2bking_page_b2bking_reports')){
					// reports
					setTimeout(function(){
						$(".b2bking_dashboard_page_wrapper").show();

					}, 50);	
				} else {
					// dashboard
					setTimeout(function(){
						$(".b2bking_dashboard_page_wrapper").show();
						drawDashboardSalesChart();
					}, 50);	
				}

			}
		}

		// Rules Pro Functions START
		
		// GROUP RULES: On click 'rules log', switch page
		$('body').on('click','.b2bking_grulespro_rules_log_btn', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('group_rules_pro_log');
			}
		});

		// GROUP RULES: On click 'rule edit button', switch page to editor + rule id
		$('body').on('click','.b2bking_group_rules_pro_rule_edit, .b2bking_group_rules_pro_rule_action_edit', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				
				// Extract rule ID from href URL
				var href = $(this).attr('href');
				var ruleId = 0;
				
				if (href) {
					var urlParams = new URLSearchParams(href.split('?')[1]);
					ruleId = urlParams.get('rule_id') || 0;
				}
				
				page_switch('group_rule_pro_editor', 0, ruleId);
			}
		});

		// GROUP RULES: On click 'add new rule button', switch page to rule editor
		$('body').on('click','.b2bking_grulespro_add_rule_btn, .b2bking_grulespro_empty_action_btn', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('group_rule_pro_editor');
			}
		});

		// GROUP RULES: Rules log and Rule editor, click on 'go back'
		$('body').on('click','.b2bking_group_rules_pro_log_back_btn, .b2bking_group_rule_pro_editor_back_btn', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('group_rules_pro');
			}
		});

		// DYNAMIC RULES: On click 'add new rule button', switch page to dynamic rule editor
		$('body').on('click','.b2bking_rulespro_add_rule_btn, .b2bking_rulespro_empty_action_btn', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('dynamic_rule_pro_editor');
			}
		});

		// DYNAMIC RULES: Rules log and Rule editor, click on 'go back'
		$('body').on('click','.b2bking_dynamic_rule_pro_editor_back_btn', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				page_switch('dynamic_rules_pro');
			}
		});

		// DYNAMIC RULES: On click 'rule edit button', switch page to editor + rule id
		$('body').on('click','.b2bking_dynamic_rules_pro_rule_edit, .b2bking_dynamic_rules_pro_rule_action_edit', function(e){
			if (b2bking.ajax_pages_load === 'enabled'){
				e.preventDefault();
				
				// Extract rule ID from href URL
				var href = $(this).attr('href');
				var ruleId = 0;
				
				if (href) {
					var urlParams = new URLSearchParams(href.split('?')[1]);
					ruleId = urlParams.get('rule_id') || 0;
				}
				
				page_switch('dynamic_rule_pro_editor', 0, ruleId);
			}
		});

		function initB2BKingGroupRulesPro(){
			// Always check if container exists
			if ($('#b2bking_group_rules_pro_main_container').length === 0) {
				return;
			}
			
			// Ensure localized data exists
			if (typeof b2bking_group_rules_pro === 'undefined') {
				window.b2bking_group_rules_pro = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					admin_url: b2bking.admin_url,
					editor_page_url: b2bking.admin_url + 'admin.php?page=b2bking_group_rule_pro_editor',
					log_page_url: b2bking.admin_url + 'admin.php?page=b2bking_group_rules_pro_log',
					strings: b2bking.group_rules_pro_strings || {}
				};
			}
			
			// Check if already loaded
			if (typeof B2BKingGroupRulesPro !== 'undefined') {
				new B2BKingGroupRulesPro();
				return;
			}

			// Load CSS if not present
			if (!document.querySelector('link[href*="group-rules-pro.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/group-rules/admin/assets/css/group-rules-pro.css';
				document.head.appendChild(css);
			}
			
			// Load JS - handle both new load and reload scenarios
			var existingScript = document.querySelector('script[src*="group-rules-pro.js"]');
			if (existingScript) {
				existingScript.remove(); // Force reload if script exists but class missing
			}
			
			$.ajax({
				url: b2bking.plugin_url + '/modules/group-rules/admin/assets/js/group-rules-pro.js',
				dataType: 'script',
				success: function() {
					// Force initialization since document.ready won't fire for AJAX loaded scripts
					if (typeof B2BKingGroupRulesPro !== 'undefined' && $('#b2bking_group_rules_pro_main_container').length > 0) {
						new B2BKingGroupRulesPro();
					}
				}
			});
		}

		function initB2BKingGroupRuleProEditor(){
			// Always check if container exists
			if ($('#b2bking_group_rule_pro_editor_main_container').length === 0) {
				return;
			}
			
			// Extract rule ID from URL
			var ruleId = 0;
			var urlParams = new URLSearchParams(window.location.search);
			ruleId = urlParams.get('rule_id') || 0;
			
			// Add rule ID to form if it exists and form doesn't already have it
			if (ruleId && ruleId !== '0') {
				var existingRuleIdInput = $('input[name="rule_id"]');
				if (existingRuleIdInput.length === 0) {
					// Add hidden input field for rule ID
					$('#b2bking_group_rule_pro_editor_form').append('<input type="hidden" name="rule_id" value="' + ruleId + '">');
				} else {
					// Update existing input value
					existingRuleIdInput.val(ruleId);
				}
			}
			
			// Ensure localized data exists for editor
			if (typeof b2bking_group_rule_pro_editor === 'undefined') {
				window.b2bking_group_rule_pro_editor = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					main_page_url: b2bking.admin_url + 'admin.php?page=b2bking_group_rules_pro',
					strings: b2bking.group_rule_pro_editor_strings || {}
				};
			}
			
			// Check if already loaded
			if (typeof initGruleIndividualEditor !== 'undefined') {
				initGruleIndividualEditor();
				return;
			}
			
			// Load CSS if not present
			if (!document.querySelector('link[href*="group-rule-pro-editor.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/group-rules/admin/assets/css/group-rule-pro-editor.css';
				document.head.appendChild(css);
			}
			
			// Load JS - handle both new load and reload scenarios
			var existingScript = document.querySelector('script[src*="group-rule-pro-editor.js"]');
			if (existingScript) {
				existingScript.remove(); // Force reload if script exists but function missing
			}
			
			$.ajax({
				url: b2bking.plugin_url + '/modules/group-rules/admin/assets/js/group-rule-pro-editor.js',
				dataType: 'script',
				success: function() {
					// Force initialization since document.ready won't fire for AJAX loaded scripts
					if (typeof initGruleIndividualEditor !== 'undefined' && $('#b2bking_group_rule_pro_editor_main_container').length > 0) {
						initGruleIndividualEditor();
					}
				}
			});
		}

		function initB2BKingDynamicRulesPro(){
			// Always check if container exists
			if ($('#b2bking_dynamic_rules_pro_main_container').length === 0) {
				return;
			}
			
			// Ensure localized data exists
			if (typeof b2bking_dynamic_rules_pro === 'undefined') {
				window.b2bking_dynamic_rules_pro = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					admin_url: b2bking.admin_url,
					editor_page_url: b2bking.admin_url + 'admin.php?page=b2bking_dynamic_rule_pro_editor',
					log_page_url: b2bking.admin_url + 'admin.php?page=b2bking_dynamic_rules_pro_log',
					strings: b2bking.dynamic_rules_pro_strings || {}
				};
			}
			
			// Check if already loaded
			if (typeof B2BKingDynamicRulesPro !== 'undefined') {
				new B2BKingDynamicRulesPro();
				return;
			}

			// Load CSS if not present
			if (!document.querySelector('link[href*="dynamic-rules-pro.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/dynamic-rules/admin/assets/css/dynamic-rules-pro.css';
				document.head.appendChild(css);
			}
			
			// Load JS - handle both new load and reload scenarios
			var existingScript = document.querySelector('script[src*="dynamic-rules-pro.js"]');
			if (existingScript) {
				existingScript.remove(); // Force reload if script exists but class missing
			}
			
			$.ajax({
				url: b2bking.plugin_url + '/modules/dynamic-rules/admin/assets/js/dynamic-rules-pro.js',
				dataType: 'script',
				success: function() {
					// Force initialization since document.ready won't fire for AJAX loaded scripts
					if (typeof B2BKingDynamicRulesPro !== 'undefined' && $('#b2bking_dynamic_rules_pro_main_container').length > 0) {
						new B2BKingDynamicRulesPro();
					}
				}
			});
		}

		function initB2BKingDynamicRuleProEditor(){
			// Always check if container exists
			if ($('#b2bking_dynamic_rule_pro_editor_main_container').length === 0) {
				return;
			}
			
			// Extract rule ID from URL
			var ruleId = 0;
			var urlParams = new URLSearchParams(window.location.search);
			ruleId = urlParams.get('rule_id') || 0;
			
			// Add rule ID to form if it exists and form doesn't already have it
			if (ruleId && ruleId !== '0') {
				var existingRuleIdInput = $('input[name="rule_id"]');
				if (existingRuleIdInput.length === 0) {
					// Add hidden input field for rule ID
					$('#b2bking_dynamic_rule_pro_editor_form').append('<input type="hidden" name="rule_id" value="' + ruleId + '">');
				} else {
					// Update existing input value
					existingRuleIdInput.val(ruleId);
				}
			}
			
			// Ensure localized data exists for editor
			if (typeof b2bking_dynamic_rule_pro_editor === 'undefined') {
				window.b2bking_dynamic_rule_pro_editor = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					main_page_url: b2bking.admin_url + 'admin.php?page=b2bking_dynamic_rules_pro',
					strings: b2bking.dynamic_rule_pro_editor_strings || {}
				};
			}
			
			// Check if already loaded
			if (typeof initRuleIndividualEditor !== 'undefined') {
				initRuleIndividualEditor();
				return;
			}
			
			// Load CSS if not present
			if (!document.querySelector('link[href*="dynamic-rule-pro-editor.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/dynamic-rules/admin/assets/css/dynamic-rule-pro-editor.css';
				document.head.appendChild(css);
			}
			
			// Load JS - handle both new load and reload scenarios
			var existingScript = document.querySelector('script[src*="dynamic-rule-pro-editor.js"]');
			if (existingScript) {
				existingScript.remove(); // Force reload if script exists but function missing
			}
			
			$.ajax({
				url: b2bking.plugin_url + '/modules/dynamic-rules/admin/assets/js/dynamic-rule-pro-editor.js',
				dataType: 'script',
				success: function() {
					// Force initialization since document.ready won't fire for AJAX loaded scripts
					if (typeof initRuleIndividualEditor !== 'undefined' && $('#b2bking_dynamic_rule_pro_editor_main_container').length > 0) {
						initRuleIndividualEditor();
					}
				}
			});
		}

		function initB2BKingEarlyAccess(){
			// Always check if container exists
			if ($('.b2bking-early-access-container').length === 0) {
				return;
			}
			
			// Ensure localized data exists
			if (typeof b2bking_early_access === 'undefined') {
				window.b2bking_early_access = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					admin_url: b2bking.admin_url,
					strings: b2bking.early_access_strings || {}
				};
			}
			
			// Check if already loaded and initialized
			if (typeof B2BKingEarlyAccess !== 'undefined' && B2BKingEarlyAccess) {
				// Re-initialize if needed (the instance already exists)
				if (typeof B2BKingEarlyAccess.init === 'function') {
					B2BKingEarlyAccess.init();
				}
				return;
			}

			// Load CSS if not present
			if (!document.querySelector('link[href*="access.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/early-access/access.css';
				document.head.appendChild(css);
			}
			
			// Load JS - handle both new load and reload scenarios
			var existingScript = document.querySelector('script[src*="access.js"]');
			if (existingScript) {
				existingScript.remove(); // Force reload if script exists but instance missing
			}
			
			$.ajax({
				url: b2bking.plugin_url + '/modules/early-access/access.js',
				dataType: 'script',
				success: function() {
					// The script automatically creates window.B2BKingEarlyAccess instance
					// No need to manually instantiate since it's done in the script
					if (typeof B2BKingEarlyAccess !== 'undefined' && B2BKingEarlyAccess) {
						// Re-initialize if needed
						if (typeof B2BKingEarlyAccess.init === 'function') {
							B2BKingEarlyAccess.init();
						}
					}
				}
			});
		}

		function initB2BKingGroupRulesProLog(){
			// Always check if container exists
			if ($('#b2bking_group_rules_pro_log_main_container').length === 0) {
				return;
			}
			
			// Ensure localized data exists (reuse from main group rules pro)
			if (typeof b2bking_group_rules_pro === 'undefined') {
				window.b2bking_group_rules_pro = {
					ajax_url: b2bking.admin_url + 'admin-ajax.php',
					nonce: b2bking.security,
					admin_url: b2bking.admin_url,
					editor_page_url: b2bking.admin_url + 'admin.php?page=b2bking_group_rule_pro_editor',
					log_page_url: b2bking.admin_url + 'admin.php?page=b2bking_group_rules_pro_log',
					strings: b2bking.group_rules_pro_strings || {}
				};
			}
			
			// Load CSS if not present
			if (!document.querySelector('link[href*="group-rules-pro-log.css"]')) {
				var css = document.createElement('link');
				css.rel = 'stylesheet';
				css.href = b2bking.plugin_url + '/modules/group-rules/admin/assets/css/group-rules-pro-log.css';
				document.head.appendChild(css);
			}
			

		}

		//  Rules Pro Functions END

		function reports_set_chart(preload = 'yes'){

			if (preload === 'yes'){
				show_reports_preloader();
			}

			let customers = jQuery('#b2bking_reports_days_select').val();
			let firstday = jQuery('.b2bking_reports_date_input_from').val();
			let lastday = jQuery('.b2bking_reports_date_input_to').val();

			// if dates are set
			if (firstday !== '' && lastday !== ''){

				// get data
				var datavar = {
		            action: 'b2bking_reports_get_data',
		            security: b2bking.security,
		            customers: customers,
		            firstday: firstday,
		            lastday: lastday,
		        };

				$.post(ajaxurl, datavar, function(response){

					let data = response.split('*');

					let labels = JSON.parse(data[0]);
					let grosssalestotal = JSON.parse(data[1]);
					let netsalestotal = JSON.parse(data[2]);
					let ordernumbers = JSON.parse(data[3]);

					let gross_sales_wc = data[4];
					let net_total_wc = data[5];
					let order_number = data[6];
					let items_purchased = data[7];
					let average_order_value = data[8];
					let refund_amount = data[9];
					let coupons_amount = data[10];
					let shipping_charges = data[11];
					

					$('.b2bking_reports_gross_sales, .b2bking_total_b2b_sales_today').html(gross_sales_wc);
					$('.b2bking_reports_net_sales').html(net_total_wc);
					$('.b2bking_reports_number_orders, .b2bking_number_orders_today').html(order_number);
					$('.b2bking_reports_items_purchased').html(items_purchased);

					$('.b2bking_reports_average_order_value').html(average_order_value);
					$('.b2bking_reports_refund_amount').html(refund_amount);
					$('.b2bking_reports_coupons_amount').html(coupons_amount);
					$('.b2bking_reports_shipping_charges').html(shipping_charges);

					drawReportsSalesChart(labels, netsalestotal, ordernumbers, grosssalestotal);

					// save data for CSV export
					latest_reports_data = data;

				});
			}
		}

		$('body').on('click', '#b2bking_export_report_button', function(){

			Swal.fire({
				  title: b2bking.select_export_format,
				  input: 'radio',
				  inputOptions: {
				    csv: 'CSV',
				    pdf: 'PDF',
				  },
				  showCancelButton: true,
				  inputValidator: (value) => {
				  	if (!value) {
			  	      return b2bking.please_select_an_option;
			  	    }
				    if (value === 'csv') {
				      create_download_report('csv');
				    } else {
				      create_download_report('pdf');
				    }
				}
			});
		});

		function create_download_report(format){
			let data = latest_reports_data;

			let labels = JSON.parse(data[0]);
			let grosssalestotal = JSON.parse(data[1]);
			let netsalestotal = JSON.parse(data[2]);
			let ordernumbers = JSON.parse(data[3]);

			let itemnumbers = JSON.parse(data[12]);
			let refunds = JSON.parse(data[13]);
			let coupons = JSON.parse(data[14]);
			let shipping = JSON.parse(data[15]);

			// show table temporarily
			jQuery('#b2bking_admin_reports_export_table').css('display','');

			// clear existing table info 
			jQuery('#b2bking_admin_reports_export_table tbody tr').remove();

			// build html row to add to exports table
			labels.forEach(function(item, index){
				let row = '<tr>';

				row += '<td>' + item + '</td>';
				row += '<td>' + grosssalestotal[index] + '</td>';
				row += '<td>' + netsalestotal[index] + '</td>';
				row += '<td>' + ordernumbers[index] + '</td>';
				row += '<td>' + itemnumbers[index] + '</td>';
				row += '<td>' + refunds[index] + '</td>';
				row += '<td>' + coupons[index] + '</td>';
				row += '<td>' + shipping[index] + '</td>';

				row += '</tr>';

				jQuery('#b2bking_admin_reports_export_table tbody').append(row);
			});

			// make table into datatables
			let filen = 'report-'+jQuery('.b2bking_reports_date_input_from').val()+'-to-'+jQuery('.b2bking_reports_date_input_to').val();
			var reportstable = jQuery('#b2bking_admin_reports_export_table').DataTable({
				dom: 'Bfrtip',
				buttons: {
				    buttons: [
				        { extend: 'csvHtml5',  text: '↓ CSV', exportOptions: { columns: ":visible" }, filename: filen },
				        { extend: 'pdfHtml5',  text: '↓ PDF', exportOptions: { columns: ":visible" }, filename: filen, title: '' },
				    ]
				}
			});

			

			if (format === 'csv'){
				$('.buttons-csv').click();
			}
			if (format === 'pdf'){
				$('.buttons-pdf').click();
			}

			

			reportstable.destroy();

			// hide table again
			jQuery('#b2bking_admin_reports_export_table').css('display','none');

		}

		$('body').on('click', '.b2bking_reports_link' ,function(){
		   	let quicklink = jQuery(this).prop('hreflang');

		   	if (quicklink === 'thismonth'){
		   		var date = new Date(), y = date.getFullYear(), m = date.getMonth();
		   		var firstDay = new Date(y, m, 1);
		   		var lastDay = new Date(y, m + 1, 0);

		   	}

		   	if (quicklink === 'lastmonth'){
		   		var date = new Date(), y = date.getFullYear(), m = date.getMonth()-1;

		   		var firstDay = new Date(y, m, 1);
		   		var lastDay = new Date(y, m + 1, 0);
		   	}

		   	if (quicklink === 'thisyear'){
		   		var date = new Date(), y = date.getFullYear();
		   		var firstDay = new Date(y, 0, 1);
		   		var lastDay = new Date(y, 11, 31);

		   	}
		   	if (quicklink === 'lastyear'){
		   		var date = new Date(), y = date.getFullYear()-1;
		   		var firstDay = new Date(y, 0, 1);
		   		var lastDay = new Date(y, 11, 31);
		   	}

		   	var day = firstDay.getDate();
		   	if (day<10) { day="0"+day;}

		   	var month = firstDay.getMonth()+1;
		   	if (month<10) { month="0"+month;}

		   	jQuery('.b2bking_reports_date_input_from').val(firstDay.getFullYear()+'-'+month+'-'+day);

		   	var day = lastDay.getDate();
		   	if (day<10) { day="0"+day;}

		   	var month = lastDay.getMonth()+1;
		   	if (month<10) { month="0"+month;}

		   	jQuery('.b2bking_reports_date_input_to').val(lastDay.getFullYear()+'-'+month+'-'+day);

		   	reports_set_chart();
		   
		});

		$('body').on('change', '.b2bking_reports_date_input', function(){
			reports_set_chart();
		});
		$('body').on('change', '#b2bking_reports_days_select', function(){
			reports_set_chart();
		});

		function show_reports_preloader(){
			$('.b2bking_reports_icon_loader').show();
			$('.ct-charts, #b2bking_reports_first_row, #b2bking_reports_second_row').css('opacity', 0.12);
			// minimum time between show / hide, otherwise looks wrong
			last_reports_loading_time = Date.now();
		}
		function drawReportsSalesChart(labelsdraw, salestotal, ordernumbers, commissiontotal){

			// hide preloader only if minimum 250 ms for good effect
			if (last_reports_loading_time === 0 || (Date.now()-last_reports_loading_time) > 250 ){

				// First, hide preloader
				$('.b2bking_reports_icon_loader').hide();
				$('.ct-charts, #b2bking_reports_first_row, #b2bking_reports_second_row').css('opacity', 1);

				// Second draw chart
				if ($(".b2bking_reports_page_wrapper").val()!== undefined ){

				    $('#b2bking_dashboard_blue_button').text($('#b2bking_reports_days_select option:selected').text());

				    var chart = new Chartist.Line('.campaign', {
				        labels: labelsdraw,
				        series: [
				            salestotal,commissiontotal
				        ]
				    }, {
				        low: 0,
				        high: Math.max(commissiontotal,salestotal),

				        showArea: true,
				        fullWidth: true,
				        plugins: [
				            Chartist.plugins.tooltip()
				        ],
				        axisY: {
				            onlyInteger: true,
				            scaleMinSpace: 40,
				            offset: 55,
				            labelInterpolationFnc: function(value) {
				                return b2bking_dashboard.currency_symbol + (value / 1);
				            }
				        },
				    });

				    var chart = new Chartist.Line('.campaign2', {
				        labels: labelsdraw,
				        series: [
				            [],ordernumbers
				        ]
				    }, {
				        low: 0,
				        high: Math.max(ordernumbers),

				        showArea: true,
				        fullWidth: true,
				        plugins: [
				            Chartist.plugins.tooltip()
				        ],
				        axisY: {
				            onlyInteger: true,
				            scaleMinSpace: 40,
				            offset: 55,
				        },
				    });

				    // Offset x1 a tiny amount so that the straight stroke gets a bounding box
				    // Straight lines don't get a bounding box 
				    // Last remark on -> http://www.w3.org/TR/SVG11/coords.html#ObjectBoundingBox
				    chart.on('draw', function(ctx) {
				        if (ctx.type === 'area') {
				            ctx.element.attr({
				                x1: ctx.x1 + 0.001
				            });
				        }
				    });

				    // Create the gradient definition on created event (always after chart re-render)
				    chart.on('created', function(ctx) {
				        var defs = ctx.svg.elem('defs');
				        defs.elem('linearGradient', {
				            id: 'gradient',
				            x1: 0,
				            y1: 1,
				            x2: 0,
				            y2: 0
				        }).elem('stop', {
				            offset: 0,
				            'stop-color': 'rgba(255, 255, 255, 1)'
				        }).parent().elem('stop', {
				            offset: 1,
				            'stop-color': 'rgba(64, 196, 255, 1)'
				        });
				    });

				    var chart = [chart];

				}
		   	
		   	} else {

				// try again later
				setTimeout(function(){
					drawReportsSalesChart(labelsdraw, salestotal, ordernumbers, commissiontotal);
				}, 100);
			}

		}

		function drawDashboardSalesChart(){
		    var selectValue = parseInt($('#b2bking_dashboard_days_select').val());
		    $('#b2bking_dashboard_blue_button').text($('#b2bking_dashboard_days_select option:selected').text());

		    if (selectValue === 0){
		        $('.b2bking_total_b2b_sales_seven_days,.b2bking_total_b2b_sales_thirtyone_days, .b2bking_number_orders_seven, .b2bking_number_orders_thirtyone, .b2bking_number_customers_seven, .b2bking_number_customers_thirtyone, .b2bking_net_earnings_seven, .b2bking_net_earnings_thirtyone').css('display', 'none');
		        $('.b2bking_total_b2b_sales_today, .b2bking_number_orders_today, .b2bking_number_customers_today, .b2bking_net_earnings_today').css('display', 'block');
		    } else if (selectValue === 1){
		        $('.b2bking_total_b2b_sales_today,.b2bking_total_b2b_sales_thirtyone_days, .b2bking_number_orders_today, .b2bking_number_orders_thirtyone, .b2bking_number_customers_today, .b2bking_number_customers_thirtyone, .b2bking_net_earnings_today, .b2bking_net_earnings_thirtyone').css('display', 'none');
		        $('.b2bking_total_b2b_sales_seven_days, .b2bking_number_orders_seven, .b2bking_number_customers_seven, .b2bking_net_earnings_seven').css('display', 'block');
		    } else if (selectValue === 2){
		        $('.b2bking_total_b2b_sales_today,.b2bking_total_b2b_sales_seven_days, .b2bking_number_orders_today, .b2bking_number_orders_seven, .b2bking_number_customers_today, .b2bking_number_customers_seven, .b2bking_net_earnings_today, .b2bking_net_earnings_seven').css('display', 'none');
		        $('.b2bking_total_b2b_sales_thirtyone_days, .b2bking_number_orders_thirtyone, .b2bking_number_customers_thirtyone, .b2bking_net_earnings_thirtyone').css('display', 'block');
		    }

		    if (selectValue === 0){
		        // set label
		        var labelsdraw = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'];
		        // set series
		        var seriesdrawb2b = b2bking_dashboard.hours_sales_b2b.concat();
		        var seriesdrawb2c = b2bking_dashboard.hours_sales_b2c.concat();

		    } else if (selectValue === 1){
		        // set label
		        var date = new Date();
		        var d = date.getDate();
		        var labelsdraw = [d-6, d-5, d-4, d-3, d-2, d-1, d];
		        labelsdraw.forEach(myFunction);
		        function myFunction(item, index) {
		          if (parseInt(item)<=0){
		            let last = new Date();
		            let month = last.getMonth();
		            let year = last.getFullYear();
		            let lastMonthDays = new Date(year, month, 0).getDate();
		            console.log(month);
		            labelsdraw[index] = lastMonthDays+item;
		          }
		        }
		        // set series
		        var seriesdrawb2b = b2bking_dashboard.days_sales_b2b.concat();
		        var seriesdrawb2c = b2bking_dashboard.days_sales_b2c.concat();
		        seriesdrawb2b.splice(7,24);
		        seriesdrawb2c.splice(7,24);
		        seriesdrawb2b.reverse();
		        seriesdrawb2c.reverse();
		    } else if (selectValue === 2){
		        // set label
		        var labelsdraw = [];
		        let i = 0;
		        while (i<31){
		            let now = new Date();
		            let pastDate = new Date(now.setDate(now.getDate() - i));
		            let day = pastDate.getDate();
		            labelsdraw.unshift(day);
		            i++;
		        }
		        // set series
		        var seriesdrawb2b = b2bking_dashboard.days_sales_b2b.concat();
		        var seriesdrawb2c = b2bking_dashboard.days_sales_b2c.concat();
		        seriesdrawb2b.reverse();
		        seriesdrawb2c.reverse();
		    }

		    if (parseInt(b2bking_dashboard.b2bking_demo) === 1){
		    	labelsdraw = [1, 2, 3, 4, 5, 6, 7, 8];
		    	seriesdrawb2b = [0, 5, 6, 8, 25, 9, 8, 24];
		    	seriesdrawb2c = [0, 3, 1, 2, 8, 1, 5, 1];
		    }

		    var chart = new Chartist.Line('.campaign', {
		        labels: labelsdraw,
		        series: [
		            seriesdrawb2b,
		            seriesdrawb2c
		        ]
		    }, {
		        low: 0,
		        high: Math.max(seriesdrawb2c, seriesdrawb2b),

		        showArea: true,
		        fullWidth: true,
		        plugins: [
		            Chartist.plugins.tooltip()
		        ],
		        axisY: {
		            onlyInteger: true,
		            scaleMinSpace: 40,
		            offset: 55,
		            labelInterpolationFnc: function(value) {
		                return b2bking_dashboard.currency_symbol + (value / 1);
		            }
		        },
		    });

		    // Offset x1 a tiny amount so that the straight stroke gets a bounding box
		    // Straight lines don't get a bounding box 
		    // Last remark on -> http://www.w3.org/TR/SVG11/coords.html#ObjectBoundingBox
		    chart.on('draw', function(ctx) {
		        if (ctx.type === 'area') {
		            ctx.element.attr({
		                x1: ctx.x1 + 0.001
		            });
		        }
		    });

		    // Create the gradient definition on created event (always after chart re-render)
		    chart.on('created', function(ctx) {
		        var defs = ctx.svg.elem('defs');
		        defs.elem('linearGradient', {
		            id: 'gradient',
		            x1: 0,
		            y1: 1,
		            x2: 0,
		            y2: 0
		        }).elem('stop', {
		            offset: 0,
		            'stop-color': 'rgba(255, 255, 255, 1)'
		        }).parent().elem('stop', {
		            offset: 1,
		            'stop-color': 'rgba(64, 196, 255, 1)'
		        });
		    });

		    var chart = [chart];
		}

		$('#toplevel_page_b2bking a').on('click', function(e){

			// check list of pages with ajax switch. If page is in list, prevent default and load via ajax
			// make sure current page is a b2bking page but not settings

			if (b2bking.ajax_pages_load === 'enabled'){
				let location = $(this).prop('href');
				let page = location.split('page=b2bking_');
				let switchto = page[1];


				if (availablepages.includes(switchto) && (page_slug.startsWith('b2bking') || b2bking.current_post_type.startsWith('b2bking') )){
					// prevent link click
					e.preventDefault();
					page_switch(switchto);

					// change link classes
					$('#adminmenu #toplevel_page_b2bking').find('.current').each(function(i){
						$(this).removeClass('current');
					});
					$(this).addClass('current');
					$(this).parent().addClass('current');
					$(this).blur();
				}

				// edit post type
				page = location.split('post_type=');
				switchto = page[1];

				if (availableposts.includes(switchto) && (page_slug.startsWith('b2bking') || b2bking.current_post_type.startsWith('b2bking') ) ){
					// prevent link click
					e.preventDefault();
					page_switch('edit_'+switchto);

					// change link classes
					$('#adminmenu #toplevel_page_b2bking').find('.current').each(function(i){
						$(this).removeClass('current');
					});
					$(this).addClass('current');
					$(this).parent().addClass('current');
					$(this).blur();
				}
			}
		});

		// separate stock variable
		$('body').on('change', '.b2bking_separate_stock select', quantityseparatestockvariable);

		function quantityseparatestockvariable(){
			
			let val = $(this).val();
			let id = $(this).attr('id');
			let fieldnr = id.split('_')[3];

			if (val === 'yes'){
				$('.variable_stock_b2b_'+fieldnr+'_field').css('display','block');
				$('.variable_stock_b2b_'+fieldnr+'_field').removeClass('b2bking_hidden_wrapper');

			} else if (val === 'no'){
				$('.variable_stock_b2b_'+fieldnr+'_field').css('display','none');
			}

		}

		// separate stock simple
		quantityseparatestocksimple();
		$('#_separate_stock_quantities_b2b').on('change', quantityseparatestocksimple);
		$('.inventory_tab').on('click', quantityseparatestocksimple);

		function quantityseparatestocksimple(){
			
			let val = $('#_separate_stock_quantities_b2b').val();
			if (val === 'yes'){
				$('._stock_b2b_field').css('display','block');
			} else if (val === 'no'){
				$('._stock_b2b_field').css('display','none');
			}

		}


		// activate plugin
		$('#b2bking-activate-license').on('click', function(){
			var datavar = {
	            action: 'b2bkingactivatelicense',
	            email: $('input[name="b2bking_license_email_setting"]').val().trim(),
	            key: $('input[name="b2bking_license_key_setting"]').val().trim(),
	            security: b2bking.security,
	        };
	        
	        const Toast = Swal.mixin({
	          toast: true,
	          position: 'center',
	          showConfirmButton: false,
	          timerProgressBar: true,
	          didOpen: (toast) => {
	            toast.addEventListener('mouseenter', Swal.stopTimer)
	            toast.addEventListener('mouseleave', Swal.resumeTimer)
	          }
	        })

	        Toast.fire({
	          icon: 'info',
	          title: b2bking.sending_request
	        });

			$.post(ajaxurl, datavar, function(response){
				if (response.trim() == 'success'){
					$('#b2bking-admin-submit').click();
				} else {

					Swal.fire(
	    	            b2bking.issue_occurred, 
	    	            response, 
	    	            "warning"
	    	        );
				}
			});
		});

		$('#b2bking_deactivate_license').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.sure_deactivate_license,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#20d580',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
			  		// show alert
		  			var datavar = {
		  	            action: 'b2bkingdeactivatelicense',
		  	            security: b2bking.security,
		  	        };

	    			$.post(ajaxurl, datavar, function(response){
	    				window.location.reload();
	    			});
			  }
			});

		});


		$('#b2bking_clear_caches_button').on('click', function(){
			var datavar = {
	            action: 'b2bkingclearcaches',
	            security: b2bking.security,
	        };

			const Toast = Swal.mixin({
			  toast: true,
			  position: 'center',
			  showConfirmButton: false,
			  timer: 10000,
			  timerProgressBar: true,
			  didOpen: (toast) => {
			    toast.addEventListener('mouseenter', Swal.stopTimer)
			    toast.addEventListener('mouseleave', Swal.resumeTimer)
			  }
			})

			Toast.fire({
			  icon: 'info',
			  title: b2bking.caches_are_clearing
			});
			      
			$.post(ajaxurl, datavar, function(response){
				Swal.fire(
    	            b2bking.caches_have_cleared, 
    	            "", 
    	            "success"
    	        );
			});

		});

		// Quote fields
		$("body.post-type-b2bking_quote_field .wrap a.page-title-action").after('&nbsp;<a href="'+b2bking.quote_fields_link+'" class="page-title-action">'+b2bking.view_quote_fields+'</a>');

		// In admin emails, modify email path for theme folder.
		if (($('#woocommerce_b2bking_new_customer_email_enabled').val() !== undefined)||($('#woocommerce_b2bking_your_account_approved_email_enabled').val() !== undefined)||($('#woocommerce_b2bking_new_customer_requires_approval_email_enabled').val() !== undefined)||($('#woocommerce_b2bking_new_message_email_enabled').val() !== undefined)){
			var text = $('.template_html').html();
			var newtext = text.replace("/woocommerce/", "/");
			$('.template_html').html(newtext);
			$('.template_html p a:nth-child(2)').remove();
			$('.template_html a').remove();
		}

		/* Special Groups: B2C Users and Guests - Payment and Shipping Methods */
		$('body').on('click', '.b2bking_b2c_special_group_container_save_settings_button', function(){
			var datavar = {
	            action: 'b2bking_b2c_special_group_save_settings',
	            security: b2bking.security,
	        };

    		$("input:checkbox").each(function(){
    			let name = $(this).attr('name');
    			if ($(this).is(':checked')){
    				datavar[name] = 1;
    			} else {
    				datavar[name] = 0;
    			}
            });

			const Toast = Swal.mixin({
			  toast: true,
			  position: 'bottom',
			  showConfirmButton: false,
			  timer: 10000,
			  timerProgressBar: true,
			  didOpen: (toast) => {
			    toast.addEventListener('mouseenter', Swal.stopTimer)
			    toast.addEventListener('mouseleave', Swal.resumeTimer)
			  }
			})

			Toast.fire({
			  icon: 'info',
			  title: b2bking.saving
			});

			jQuery('.b2bking_settings_button').removeClass('active');
			jQuery('.b2bking_settings_button').text('Save Settings');
	        
			$.post(ajaxurl, datavar, function(response){
				const Toast = Swal.mixin({
				  toast: true,
				  position: 'bottom',
				  showConfirmButton: false,
				  timer: 1000,
				  timerProgressBar: false,
				  didOpen: (toast) => {
				    toast.addEventListener('mouseenter', Swal.stopTimer)
				    toast.addEventListener('mouseleave', Swal.resumeTimer)
				  }
				})

				Toast.fire({
				  icon: 'success',
				  title: b2bking.settings_saved
				});

			});
		})

		// settings have changed, you should save them
		jQuery('.toplevel_page_b2bking #b2bking_admin_wrapper input[type="checkbox"], .toplevel_page_b2bking #b2bking_admin_wrapper input[type="radio"], .toplevel_page_b2bking #b2bking_admin_wrapper input[type="color"], .toplevel_page_b2bking #b2bking_admin_wrapper input[type="text"], .toplevel_page_b2bking #b2bking_admin_wrapper select').on('change input', function(){
			jQuery('#b2bking-admin-submit').addClass('active');
			jQuery('#b2bking-admin-submit').val(b2bking.click_to_save_settings);
		});

		jQuery('body').on('change', '.b2bking_group_payment_shipping_methods_container_element_method_checkbox', function(){
			jQuery('.b2bking_settings_button').addClass('active');
			jQuery('.b2bking_settings_button').text(b2bking.click_to_save_settings);
		});

		

		// Shared function to generate PDF document definition for offers
		function generateOfferPdfDefinition() {
			var logoimg = b2bking.offers_logo;

			var imgToExport = document.getElementById('b2bking_img_logo');
			var dataURL = '';
			if (imgToExport && imgToExport.width > 0 && imgToExport.height > 0) {
				var canvas = document.createElement('canvas');
				canvas.width = imgToExport.width; 
				canvas.height = imgToExport.height; 
				canvas.getContext('2d').drawImage(imgToExport, 0, 0);
				dataURL = canvas.toDataURL("image/png");
			} 

			// get all thumbnails 
			var thumbnails = [];
			var thumbnr = 0;
			if (parseInt(b2bking.offers_images_setting) === 1){
				let field = $('#b2bking_offers_thumbnails_str').val();
				let itemsArray = field.split('|');
				itemsArray.forEach(function(item){
					if (item !== 'no'){
						var idimg = 'b2bking_img_logo'+thumbnr;
						var imgToExport = document.getElementById(idimg);
						var canvas = document.createElement('canvas');
						canvas.width = imgToExport.width; 
						canvas.height = imgToExport.height; 
						canvas.getContext('2d').drawImage(imgToExport, 0, 0);
						let datau = canvas.toDataURL("image/png"); 
						thumbnr++;
						thumbnails.push(datau);
					} else {
						thumbnails.push('no');
					}
				});
			}

			var names = $('#b2bking_offers_names_str').val();
			let namesArray = names.split('*|||*');
			var namenr=0;

			thumbnr = 0;
			var customtext = jQuery('#b2bking_offer_customtext_textarea').val();
			var customtexttitle = b2bking.offer_custom_text;
			if (customtext.length === 0){
				customtexttitle = '';
			}

			var bodyarray = [];
			bodyarray.push([{ text: b2bking.item_name, style: 'tableHeader', margin: [7, 7, 7, 7] }, { text: b2bking.item_quantity, style: 'tableHeader', margin: [7, 7, 7, 7] }, { text: b2bking.unit_price, style: 'tableHeader', margin: [7, 7, 7, 7] }, { text: b2bking.item_subtotal, style: 'tableHeader', margin: [7, 7, 7, 7] }]);

			jQuery('.b2bking_offer_line_number').each(function(i){
				let tempvalues = [];
				let namevalue = namesArray[namenr];
				namenr++;

				if (parseInt(b2bking.offers_images_setting) === 1){
					if (thumbnails[thumbnr] !== 'no'){
						tempvalues.push([{ text: namevalue, margin: [7, 7, 7, 7] },{
								image: thumbnails[thumbnr],
								width: 40,
								margin: [15, 5, 5, 5]
							}]);
					} else {
						tempvalues.push({ text: namevalue, margin: [7, 7, 7, 7] });
					}
					thumbnr++;
				} else {
					tempvalues.push({ text: namevalue, margin: [7, 7, 7, 7] });
				}

				tempvalues.push({ text: jQuery(this).find('.b2bking_offer_item_quantity').val(), margin: [7, 7, 7, 7] });
				tempvalues.push({ text: jQuery(this).find('.b2bking_offer_item_price').val(), margin: [7, 7, 7, 7] });
				tempvalues.push({ text: jQuery(this).find('.b2bking_item_subtotal').text(), margin: [7, 7, 7, 7] });
				bodyarray.push(tempvalues);
			});

			bodyarray.push(['','',{ text: b2bking.offer_total+': ', margin: [7, 7, 7, 7], bold: true },{ text: jQuery('#b2bking_offer_total_text_number').text(), margin: [7, 7, 7, 7], bold: true }]);

			let imgobj = null;
			if (dataURL && dataURL.length > 0) {
				imgobj = {
					image: dataURL,
					width: parseInt(b2bking.offerlogowidth),
					margin: [0, parseInt(b2bking.offerlogotopmargin), 0, 30]
				};
			}

			var contentarray =[
					{ text: b2bking.offer_details, fontSize: 14, bold: true, margin: [0, 20, 0, 20] },
					{
						style: 'tableExample',
						table: {
							headerRows: 1,
							widths: ['*', '*', '*', '*'],
							body: bodyarray,
						},
						layout: 'lightHorizontalLines'
					},
					{ text: b2bking.offer_go_to, link: b2bking.offers_endpoint_link, decoration: 'underline', fontSize: 13, bold: true, margin: [0, 20, 40, 8], alignment:'right' },
					{ text: customtexttitle, fontSize: 14, bold: true, margin: [0, 50, 0, 8] },
					{ text: customtext, fontSize: 12, bold: false, margin: [0, 8, 0, 8] },
				];

			var mention_offer_requester = b2bking.mention_offer_requester;
			var custom_content_after_logo_left_1 = b2bking.custom_content_after_logo_left_1;
			var custom_content_after_logo_left_2 = b2bking.custom_content_after_logo_left_2;
			var custom_content_after_logo_center_1 = b2bking.custom_content_after_logo_center_1;
			var custom_content_after_logo_center_2 = b2bking.custom_content_after_logo_center_2;
			if (custom_content_after_logo_left_1.length !== 0){
				let custom_content = { text: custom_content_after_logo_left_1, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'left' };
				contentarray.unshift(custom_content);
			}
			if (mention_offer_requester.length !== 0){
				let custom_content = { text: mention_offer_requester, fontSize: 14, bold: true, margin: [0, 12, 0, 12], alignment:'left' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_after_logo_left_2.length !== 0){
				let custom_content = { text: custom_content_after_logo_left_2, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'left' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_after_logo_center_1.length !== 0){
				let custom_content = { text: custom_content_after_logo_center_1, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'center' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_after_logo_center_2.length !== 0){
				let custom_content = { text: custom_content_after_logo_center_2, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'center' };
				contentarray.unshift(custom_content);
			}
			if (logoimg.length !== 0 && imgobj !== null){
				contentarray.unshift(imgobj);
			}

			var custom_content_center_1 = b2bking.custom_content_center_1;
			var custom_content_center_2 = b2bking.custom_content_center_2;
			var custom_content_left_1 = b2bking.custom_content_left_1;
			var custom_content_left_2 = b2bking.custom_content_left_2;
			if (custom_content_center_1.length !== 0){
				let custom_content = { text: custom_content_center_1, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'center' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_center_2.length !== 0){
				let custom_content = { text: custom_content_center_2, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'center' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_left_1.length !== 0){
				let custom_content = { text: custom_content_left_1, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'left' };
				contentarray.unshift(custom_content);
			}
			if (custom_content_left_2.length !== 0){
				let custom_content = { text: custom_content_left_2, fontSize: 12, bold: true, margin: [0, 12, 0, 12], alignment:'left' };
				contentarray.unshift(custom_content);
			}

			var docDefinition = {
				content: contentarray
			};

			if(b2bking.pdf_download_lang === 'thai'){
				pdfMake.fonts = {
				  THSarabunNew: {
				    normal: 'THSarabunNew.ttf',
				    bold: 'THSarabunNew-Bold.ttf',
				    italics: 'THSarabunNew-Italic.ttf',
				    bolditalics: 'THSarabunNew-BoldItalic.ttf'
				  }
				};
				docDefinition = {
				  content: contentarray,
				  defaultStyle: {
				    font: 'THSarabunNew'
				  }
				}
			}

			if(b2bking.pdf_download_font !== 'standard'){
				pdfMake.fonts = {
				  Customfont: {
				    normal: b2bking.pdf_download_font,
				    bold: b2bking.pdf_download_font,
				    italics: b2bking.pdf_download_font,
				    bolditalics: b2bking.pdf_download_font
				  }
				};
				docDefinition = {
				  content: contentarray,
				  defaultStyle: {
				    font: 'Customfont'
				  }
				}
			}

			return docDefinition;
		}

		$('.b2bking_email_offer_button').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.email_offer_confirm,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#20d580',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
					var attachPdf = $('#b2bking_email_offer_attach_pdf').is(':checked');
					var datavar = {
			            action: 'b2bkingemailoffer',
			            security: b2bking.security,
			            offerid: $('#post_ID').val(),
			            offerlink: b2bking.offers_endpoint_link,
			            attach_pdf: attachPdf ? '1' : '0'
			        };

					if (attachPdf) {
						// Generate PDF and attach
						var docDefinition = generateOfferPdfDefinition();
						pdfMake.createPdf(docDefinition).getBase64(function(base64) {
							datavar.pdfdata = base64;
							$.post(ajaxurl, datavar, function(response){
								Swal.fire(
				        	            b2bking.email_has_been_sent, 
				        	            "", 
				        	            "success"
				        	        );
							});
						});
					} else {
						// Send email without PDF
						$.post(ajaxurl, datavar, function(response){
							Swal.fire(
			        	            b2bking.email_has_been_sent, 
			        	            "", 
			        	            "success"
			        	        );
						});
					}
			  }
			});
			
		});

		$('.b2bking_make_offer').on('click', function(){
			
			window.location = b2bking.new_offer_link+'&quote='+$('#post_ID').val();

		});
		

		// download offer
		$('.b2bking_download_offer_button').on('click', function(){
			var docDefinition = generateOfferPdfDefinition();
			pdfMake.createPdf(docDefinition).download(b2bking.offer_file_name + '.pdf');
		});

		function ajax_page_reload(){
			// 1. Replace current page content with loader
			// add overlay and loader
			jQuery('#wpbody-content').prepend('<div id="b2bking_admin_overlay"><img class="b2bking_loader_icon_button" src="'+b2bking.loaderurl+'">');

			// if pageslug contains user, remove it
			let slugsplit = window.location.href.split('&user=');
			let switchto = slugsplit[0].split('b2bking_')[1];
			let userid = 0;
			if (slugsplit[1] !== undefined){
				userid = slugsplit[1];
			}

			// 2. Get page content
			var datavar = {
	            action: 'b2bking_get_page_content',
	            security: b2bking.security,
	            page: switchto,
	            userid: userid
	        };

			jQuery.post(ajaxurl, datavar, function(response){

				// response is the HTML content of the page
				jQuery('#wpbody-content').html(response);

				// initialize JS
				initialize_elements();

				initialize_on_b2bking_page_load();
			});
		}
	
		$('body').on('click', '.b2bking_logged_out_special_group_container_save_settings_button', function(){
			var datavar = {
	            action: 'b2bking_logged_out_special_group_save_settings',
	            security: b2bking.security,
	        };

    		$("input:checkbox").each(function(){
    			let name = $(this).attr('name');
    			if ($(this).is(':checked')){
    				datavar[name] = 1;
    			} else {
    				datavar[name] = 0;
    			}
            });

           const Toast = Swal.mixin({
             toast: true,
             position: 'bottom',
             showConfirmButton: false,
             timer: 10000,
             timerProgressBar: true,
             didOpen: (toast) => {
               toast.addEventListener('mouseenter', Swal.stopTimer)
               toast.addEventListener('mouseleave', Swal.resumeTimer)
             }
           })

           jQuery('.b2bking_settings_button').removeClass('active');
           jQuery('.b2bking_settings_button').text('Save Settings');

           Toast.fire({
             icon: 'info',
             title: b2bking.saving
           });
                 
           $.post(ajaxurl, datavar, function(response){
	           	const Toast = Swal.mixin({
	           	  toast: true,
	           	  position: 'bottom',
	           	  showConfirmButton: false,
	           	  timer: 1000,
	           	  timerProgressBar: false,
	           	  didOpen: (toast) => {
	           	    toast.addEventListener('mouseenter', Swal.stopTimer)
	           	    toast.addEventListener('mouseleave', Swal.resumeTimer)
	           	  }
	           	})

	           	Toast.fire({
	           	  icon: 'success',
	           	  title: b2bking.settings_saved
	           	});
	           	
           });

		});

		/* Conversations */
		// On load conversation, scroll to conversation end
		// if conversation exists
		if ($('#b2bking_conversation_messages_container').length){
			$("#b2bking_conversation_messages_container").scrollTop($("#b2bking_conversation_messages_container")[0].scrollHeight);
		}

		/* Product Category Visibility */
		// Initialize Select2 for all user search dropdowns (AJAX search)
		function initializeUserSearchDropdown($select, placeholder) {
			if ($select.length && !$select.hasClass('select2-hidden-accessible')) {
				$select.select2({
					ajax: {
						url: ajaxurl,
						dataType: 'json',
						delay: 300,
						data: function (params) {
							return {
								action: 'b2bking_admin_user_search',
								security: b2bking.security,
								search: params.term
							};
						},
						processResults: function (data) {
							if (data.success) {
								// Store user_login mapping for later use
								var results = data.data.map(function(item) {
									return {
										id: item.id,
										text: item.text,
										user_login: item.user_login || ''
									};
								});
								return {
									results: results
								};
							}
							return { results: [] };
						},
						cache: true
					},
					minimumInputLength: 3,
					placeholder: placeholder || b2bking.type_to_search_users,
					allowClear: true,
					width: '100%'
				});
				
				// Store user_login when a user is selected
				$select.on('select2:select', function (e) {
					var data = e.params.data;
					if (data && data.user_login) {
						$select.data('selected-user-login', data.user_login);
					}
				});
				
				// Clear stored user_login when selection is cleared
				$select.on('select2:clear', function () {
					$select.removeData('selected-user-login');
				});
			}
		}
		
		// Initialize Select2 for all instances of b2bking_all_users_dropdown
		$('#b2bking_all_users_dropdown').each(function() {
			initializeUserSearchDropdown($(this));
		});
		initializeUserSearchDropdown($('#b2bking_transfer_subaccounts_from'), b2bking.transfer_subaccounts_from_placeholder);
		initializeUserSearchDropdown($('#b2bking_transfer_subaccounts_to'), b2bking.transfer_subaccounts_to_placeholder);

		// On clicking the "Add user button in the Product Category User Visibility table"
		$("#b2bking_category_add_user").on("click",function(){
			// Find the closest dropdown relative to this button
			var $button = $(this);
			var $container = $button.closest('.b2bking_category_users_textarea_buttons_container');
			var $select = $container.find('#b2bking_all_users_dropdown');
			
			// Get username
			let username = "";
			
			// Check if Select2 is initialized (all instances now use Select2)
			if ($select.length && $select.hasClass('select2-hidden-accessible')) {
				// Use Select2 - get user_login from stored data attribute
				username = $select.data('selected-user-login');
				if (!username) {
					// Fallback: try to get from Select2 data
					var selectedData = $select.select2('data');
					if (selectedData && selectedData.length > 0 && selectedData[0].user_login) {
						username = selectedData[0].user_login;
					}
				}
			} else {
				// Fallback for non-Select2 selects (shouldn't happen now, but keeping for safety)
				if (parseInt(jQuery('#b2bking_offer_access_metabox').length) === 1){
					// we are on offers page - use value
					username = $select.val();
				} else {
					// Other pages - use text
					username = $select.children("option:selected").text();
				}
			}

			if (!username || username === '') {
				return;
			}

			// Get content and check if username already exists
			let content = $("#b2bking_category_users_textarea").val();
			let usersarray = content.split(',');
			let exists = 0;

			$.each( usersarray, function( i, val ) {
				if (val.trim() === username){
					exists = 1;
				}
			});

			if (exists === 1){
				// Show "Username already in the list" for 3 seconds
				$("#b2bking_category_add_user").text(b2bking.username_already_list);
				setTimeout(function(){
					$("#b2bking_category_add_user").text(b2bking.add_user);
				}, 2000);

			} else {
				// remove last comma and whitespace after
				content = content.replace(/,\s*$/, "");
				// if list is not empty, add comma
				if (content.length > 0){
					content = content + ', ';
				}
				// add username
				content = content + username;
				$("#b2bking_category_users_textarea").val(content);
				// Clear the select after adding (for all Select2 instances)
				if ($select.length && $select.hasClass('select2-hidden-accessible')) {
					$select.val(null).trigger('change');
					$select.removeData('selected-user-login');
				}
			}
		});

		/* Product Visibility */
		// On page load, update product visibility options
		updateProductVisibilityOptions();

		// On Product Visibility option change, update product visibility options 
		$('#b2bking_product_visibility_override').change(function() {
			updateProductVisibilityOptions();
		});

		// Checks the selected Product Visibility option and hides or shows Automatic / Manual visibility options
		function updateProductVisibilityOptions(){
			let selectedValue = $("#b2bking_product_visibility_override").children("option:selected").val();
			if(selectedValue === "manual") {
		      	$("#b2bking_metabox_product_categories_wrapper").css("display","none");
		      	$("#b2bking_product_visibility_override_options_wrapper").css("display","block");
		   	} else if (selectedValue === "default"){
				$("#b2bking_product_visibility_override_options_wrapper").css("display","none");
				$("#b2bking_metabox_product_categories_wrapper").css("display","block");
			}
		}


		/* Dynamic Rules */
		// On page load, before everything, set up conditions from hidden field to selectors
		setUpConditionsFromHidden();
		// update dynamic pricing rules
		updateDynamicRulesOptionsConditions();

		// Initialize Select2s
		$('.post-type-b2bking_rule #b2bking_rule_select_who').select2();
		$('.post-type-b2bking_rule #b2bking_rule_select_applies').select2();
		jQuery('#salesking_additional_agents').select2();

		showHideMultipleAgentsSelector();
		$('#b2bking_rule_select_agents_who').change(showHideMultipleAgentsSelector);
		function showHideMultipleAgentsSelector(){
			let selectedValue = $('#b2bking_rule_select_agents_who').val();
			if (selectedValue === 'multiple_options'){
				$('#b2bking_select_multiple_agents_selector').css('display','block');
			} else {
				$('#b2bking_select_multiple_agents_selector').css('display','none');
			}
		}

		// Value Condition Error - show discount everywhere
		jQuery('#publish').on('click', function(e){

			if (jQuery('#b2bking_rule_select_what').val() === 'discount_amount' || jQuery('#b2bking_rule_select_what').val() === 'discount_percentage'){

				if (jQuery('#b2bking_dynamic_rule_discount_show_everywhere_checkbox_input').is(':checked')){
				// check for value conditions

					let have_value_conditions = 'no';
					jQuery('.b2bking_rule_condition_container').each(function(){
						let value = jQuery(this).find('.b2bking_dynamic_rule_condition_number').val();
						if(value !== ''){
							// check if condition is value condition
							let cond = jQuery(this).find('.b2bking_dynamic_rule_condition_name').val();
							if (cond === 'cart_total_value'){
								have_value_conditions = 'yes';
							} 
							if (cond === 'category_product_value'){
								have_value_conditions = 'yes';
							} 
							if (cond === 'product_value'){
								have_value_conditions = 'yes';
							} 
						}
					});
					if (have_value_conditions === 'yes'){
						e.preventDefault();

		    				Swal.fire(
		        	            b2bking.issue_occurred, 
		        	            b2bking.value_conditions_error, 
		        	            "warning"
		        	        );
					}
					// if any value conditions, show error
				}
			}
		});
		

		// initialize multiple products / categories selector as Select2
		$('.b2bking_select_multiple_product_categories_selector_select, .b2bking_select_multiple_users_selector_select').select2({'width':'100%', 'theme':'classic'});
		// show hide multiple products categories selector
		showHideMultipleProductsCategoriesSelector();
		$('#b2bking_rule_select_what').change(showHideMultipleProductsCategoriesSelector);
		$('#b2bking_rule_select_applies').change(showHideMultipleProductsCategoriesSelector);
		function showHideMultipleProductsCategoriesSelector(){
			let selectedValue = $('#b2bking_rule_select_applies').val();
			let hiddenwhat = ['replace_prices_quote','set_currency_symbol','payment_method_minmax_order','payment_method_discount','rename_purchase_order'];
			let selectedWhat = $('#b2bking_rule_select_what').val();
			if ( (selectedValue === 'multiple_options' && selectedWhat !== 'tax_exemption_user') || (selectedValue === 'excluding_multiple_options' && selectedWhat !== 'tax_exemption_user')){
				$('#b2bking_select_multiple_product_categories_selector').css('display','block');
			} else {
				$('#b2bking_select_multiple_product_categories_selector').css('display','none');
			}

			if (hiddenwhat.includes(selectedWhat)){
				$('#b2bking_select_multiple_product_categories_selector').css('display','none');
			}
		}

		showHideMultipleUsersSelector();
		$('#b2bking_rule_select_who').change(showHideMultipleUsersSelector);
		function showHideMultipleUsersSelector(){
			let selectedValue = $('#b2bking_rule_select_who').val();
			if (selectedValue === 'multiple_options'){
				$('#b2bking_select_multiple_users_selector').css('display','block');
			} else {
				$('#b2bking_select_multiple_users_selector').css('display','none');
			}
		}

		function setUpConditionsFromHidden(){
			// get all conditions
			let conditions = $('#b2bking_rule_select_conditions').val();
			if (conditions === undefined) {
				conditions = '';
			}

			if(conditions.trim() !== ''){  
				let conditionsArray = conditions.split('|');
				let i=1;
				// foreach condition, create selectors
				conditionsArray.forEach(function(item){
					let conditionDetails = item.split(';');
					// if condition not empty
					if (conditionDetails[0] !== ''){
						$('.b2bking_dynamic_rule_condition_name.b2bking_condition_identifier_'+i).val(conditionDetails[0]);
						$('.b2bking_dynamic_rule_condition_operator.b2bking_condition_identifier_'+i).val(conditionDetails[1]);
						$('.b2bking_dynamic_rule_condition_number.b2bking_condition_identifier_'+i).val(conditionDetails[2]);
						addNewCondition(i, 'programatically');
						i++;
					}
				});
			}
		}

		// On clicking "add condition" in Dynamic rule
		$('body').on('click', '.b2bking_dynamic_rule_condition_add_button', function(event) {
		    addNewCondition(1,'user');
		});

		function addNewCondition(buttonNumber = 1, type = 'user'){
			let currentNumber;
			let nextNumber;

			// If condition was added by user
			if (type === 'user'){
				// get its current number
				let classList = $('.b2bking_dynamic_rule_condition_add_button').attr('class').split(/\s+/);
				$.each(classList, function(index, item) {
				    if (item.includes('identifier')) {
				    	var itemArray = item.split("_");
				    	currentNumber = parseInt(itemArray[3]);
				    }
				});
				// set next number
				nextNumber = (currentNumber+1);
			} else {
				// If condition was added at page load automatically
				currentNumber = buttonNumber;
				nextNumber = currentNumber+1;
			}

			// add delete button same condition
			$('.b2bking_dynamic_rule_condition_add_button.b2bking_condition_identifier_'+currentNumber).after('<button type="button" class="b2bking_dynamic_rule_condition_delete_button b2bking_condition_identifier_'+currentNumber+'">'+b2bking.delete+'</button>');
			// add next condition
			$('#b2bking_condition_number_'+currentNumber).after('<div id="b2bking_condition_number_'+nextNumber+'" class="b2bking_rule_condition_container">'+
				'<select class="b2bking_dynamic_rule_condition_name b2bking_condition_identifier_'+nextNumber+'">'+
					'<option value="cart_total_quantity" selected="selected">'+b2bking.cart_total_quantity+'</option>'+
					'<option value="cart_total_value">'+b2bking.cart_total_value+'</option>'+
					'<option value="category_product_quantity">'+b2bking.category_product_quantity+'</option>'+
					'<option value="category_product_value">'+b2bking.category_product_value+'</option>'+
					'<option value="product_quantity">'+b2bking.product_quantity+'</option>'+
					'<option value="product_value">'+b2bking.product_value+'</option>'+
				'</select>'+
				'<select class="b2bking_dynamic_rule_condition_operator b2bking_condition_identifier_'+nextNumber+'">'+
					'<option value="greater">'+b2bking.greater+'</option>'+
					'<option value="equal">'+b2bking.equal+'</option>'+
					'<option value="smaller">'+b2bking.smaller+'</option>'+
				'</select>'+
				'<input type="number" step="0.00001" class="b2bking_dynamic_rule_condition_number b2bking_condition_identifier_'+nextNumber+'" placeholder="'+b2bking.enter_quantity_value+'">'+
				'<button type="button" class="b2bking_dynamic_rule_condition_add_button b2bking_condition_identifier_'+nextNumber+'">'+b2bking.add_condition+'</button>'+
			'</div>');

			// remove self 
			$('.b2bking_dynamic_rule_condition_add_button.b2bking_condition_identifier_'+currentNumber).remove();

			// update available options
			updateDynamicRulesOptionsConditions();
		}

		// On clicking "delete condition" in Dynamic rule
		$('body').on('click', '.b2bking_dynamic_rule_condition_delete_button', function () {
			// get its current number
			let currentNumber;
			let classList = $(this).attr('class').split(/\s+/);
			$.each(classList, function(index, item) {
			    if (item.includes('identifier')) {
			    	var itemArray = item.split("_");
			    	currentNumber = parseInt(itemArray[3]);
			    }
			});
			// remove current element
			$('#b2bking_condition_number_'+currentNumber).remove();

			// update conditions hidden field
			updateConditionsHiddenField();
		});

		// On Rule selector change, update dynamic rule conditions
		$('#b2bking_rule_select_what, #b2bking_rule_select_who, #b2bking_rule_select_applies, #b2bking_rule_select, #b2bking_rule_select_showtax, #b2bking_container_tax_shipping').change(function() {
			updateDynamicRulesOptionsConditions();
		});

		// Handle One Time Fee / Tax option visibility based on "what" selection
		$('#b2bking_rule_select_what').change(function() {
			updateOneTimeFeeVisibility();
			updateAllProductsExceptVisibility();
		});

		// Initialize One Time Fee visibility on page load
		updateOneTimeFeeVisibility();
		
		// Initialize All Products Except visibility on page load
		updateAllProductsExceptVisibility();

		function updateOneTimeFeeVisibility() {
			var selectedWhat = $('#b2bking_rule_select_what').val();
			var oneTimeOption = $('#b2bking_one_time');
			var taxOptgroup = $('#b2bking_tax_options_optgroup');
			var appliesSelect = $('#b2bking_rule_select_applies');
			var cartOptgroup = $('#b2bking_cart_total_optgroup');
			
			// Check if it's a tax rule
			if (selectedWhat === 'add_tax_percentage' || selectedWhat === 'add_tax_amount') {
				// Show the option if it doesn't exist
				if (oneTimeOption.length === 0) {
					// Add the optgroup with option right after the Cart optgroup
					var taxOptgroupHtml = '<optgroup label="Tax Options" id="b2bking_tax_options_optgroup"><option id="b2bking_one_time" value="one_time">One Time Fee / Tax</option></optgroup>';
					cartOptgroup.after(taxOptgroupHtml);
				}
			} else {
				// Hide the optgroup if it exists
				if (taxOptgroup.length > 0) {
					taxOptgroup.remove();
				}
			}
		}

		function updateAllProductsExceptVisibility() {
			var selectedWhat = $('#b2bking_rule_select_what').val();
			var appliesSelect = $('#b2bking_rule_select_applies');
			var allProductsExceptOption = $('#b2bking_excluding_multiple_options');
			
			// Rule types that should hide the "All products except..." option
			var hideForRuleTypes = [
				'minimum_order',      // Minimum Order
				'maximum_order',      // Maximum Order
				'free_shipping',      // Free Shipping
				'required_multiple',  // Required Multiple (Quantity Step)
				'tax_exemption'       // Zero Tax Product
			];
			
			// Check if the current rule type should hide the "All products except..." option
			if (hideForRuleTypes.indexOf(selectedWhat) !== -1) {
				// If currently selected option is 'all products except', force switch to cart_total
				if (appliesSelect.val() === 'excluding_multiple_options') {
					appliesSelect.val('cart_total').trigger('change');
				}
				
				// Hide the option in the original select
				allProductsExceptOption.hide();
				
				// Add CSS class to hide the option when Select2 renders it
				allProductsExceptOption.addClass('b2bking-hide-except-option');
				
			} else {
				// Show the option in the original select
				allProductsExceptOption.show();
				
				// Remove CSS class to show the option when Select2 renders it
				allProductsExceptOption.removeClass('b2bking-hide-except-option');
			}
		}

		// Add Select2 event handler to filter out the "All products except..." option
		$('#b2bking_rule_select_applies').on('select2:open', function() {
			var selectedWhat = $('#b2bking_rule_select_what').val();
			var hideForRuleTypes = [
				'minimum_order', 'maximum_order', 'free_shipping', 
				'required_multiple', 'tax_exemption'
			];
			
			if (hideForRuleTypes.indexOf(selectedWhat) !== -1) {
				// Hide the Select2 option after a short delay to ensure it's rendered
				setTimeout(function() {
					$('.select2-results__option[data-select2-id*="excluding_multiple_options"]').hide();
				}, 10);
			}
		});

		function updateDynamicRulesOptionsConditions(){
			$('#b2bking_rule_select_applies_replaced_container, #b2bking_rule_select_who_replaced_container').css('display','none');
			// Hide all condition options
			$('.b2bking_dynamic_rule_condition_name option').css('display','none');
			// Hide quantity/value
			$('#b2bking_container_quantity_value').css('display','none');
			// Hide currency
			$('#b2bking_container_currency').css('display','none');
			// Hide payment methods
			$('#b2bking_container_shippingmethods, #b2bking_container_paymentmethods, #b2bking_container_paymentmethods_minmax, #b2bking_container_paymentmethods_percentamount').css('display','none');
			// Hide countries and requires
			$('#b2bking_container_countries, #b2bking_container_requires, #b2bking_container_showtax').css('display','none');
			// Hide tax name
			$('#b2bking_container_taxname, #b2bking_container_tax_taxable, #b2bking_container_tax_shipping, #b2bking_container_tax_shipping_rate, #b2bking_container_tiered_price, #b2bking_container_info_table, #b2bking_container_rulepriority').css('display','none');
			// Hide discount checkbox
			$('.b2bking_dynamic_rule_minimum_all_checkbox_container, .b2bking_dynamic_rule_discount_show_everywhere_checkbox_container, .b2bking_dynamic_rule_quotes_checkbox_container, .b2bking_discount_options_information_box, .b2bking_minimum_options_information_box').css('display','none');
			$('#b2bking_container_discountname').css('display','none');
			$('.b2bking_rule_label_discount, .b2bking_rule_label_minimum, .b2bking_rule_label_quotes').css('display','none');

			// conditions box text
			$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_apply_cumulatively);

			// Show all options
			$("#b2bking_container_howmuch").css('display','inline-block');
			$('#b2bking_container_applies').css('display','inline-block');
			// Show conditions + conditions info box
			$('#b2bking_rule_select_conditions_container').css('display','inline-block');
			$('.b2bking_rule_conditions_information_box').css('display','flex');

			let selectedWhat = $("#b2bking_rule_select_what").val();
			let selectedWho = $("#b2bking_rule_select_who").val();
			let selectedApplies = $("#b2bking_rule_select_applies").val();
			// Select Discount Amount or Percentage
			if (selectedWhat === 'discount_amount' || selectedWhat === 'discount_percentage'){
				// if select Cart: cart_total_quantity and cart_total_value
				if (selectedApplies === 'cart_total' || selectedApplies.startsWith("tag")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value]').css('display','block');
				} else if (selectedApplies.startsWith("category")){
				// if select Category also have: category_product_quantity and category_product_value
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_value]').css('display','block');
				} else if (selectedApplies.startsWith("product")){
				// if select Product also have: product_quantity and product_value  
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_value]').css('display','block');
				} else if (selectedApplies === 'multiple_options' || selectedApplies === 'excluding_multiple_options' || selectedApplies === 'replace_ids'){
					$('.b2bking_dynamic_rule_condition_name option').css('display','block');
					// conditions box text
					$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_multiselect);
				}
				// Show discount everywhere checkbox
				$('.b2bking_dynamic_rule_discount_show_everywhere_checkbox_container, .b2bking_discount_options_information_box').css('display','flex');
				$('.b2bking_rule_label_discount').css('display','block');
				$('#b2bking_container_discountname').css('display','inline-block');

				$('#b2bking_container_rulepriority').css('display','block');

			} else if (selectedWhat === 'fixed_price'){
				if (selectedApplies === 'cart_total' || selectedApplies.startsWith("tag")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value]').css('display','block');
				} else if (selectedApplies.startsWith("category")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity]').css('display','block');
				} else if (selectedApplies.startsWith("product")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=product_quantity]').css('display','block');
				} else if (selectedApplies === 'multiple_options' || selectedApplies === 'replace_ids'){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_quantity]').css('display','block');
					$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_multiselect);
				}

				$('#b2bking_container_rulepriority').css('display','block');

			} else if (selectedWhat === 'free_shipping'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// if select Cart: cart_total_quantity and cart_total_value
				if (selectedApplies === 'cart_total' || selectedApplies.startsWith("tag")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value]').css('display','block');
				} else if (selectedApplies.startsWith("category")){
				// if select Category also have: category_product_quantity and category_product_value
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_value]').css('display','block');
				} else if (selectedApplies.startsWith("product")){
				// if select Product also have: product_quantity and product_value 
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_value]').css('display','block'); 
				} else if (selectedApplies === 'multiple_options' || selectedApplies === 'replace_ids'){
					$('.b2bking_dynamic_rule_condition_name option').css('display','block');
					$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_multiselect);
				}
			} else if (selectedWhat === 'tiered_price'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				$('#b2bking_container_tiered_price').css('display','block');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');


			} else if (selectedWhat === 'info_table'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				$('#b2bking_container_info_table').css('display','block');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');


			} else if (selectedWhat === 'hidden_price'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');

			} else if (selectedWhat === 'quotes_products'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');

				$('.b2bking_dynamic_rule_quotes_checkbox_container, .b2bking_quotes_options_information_box').css('display','flex');
				$('.b2bking_rule_label_quotes').css('display','block');

			} else if (selectedWhat === 'unpurchasable'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');

			} else if (selectedWhat === 'required_multiple'){

				// Show discount everywhere checkbox
				$('.b2bking_dynamic_rule_minimum_all_checkbox_container, .b2bking_minimum_options_information_box').css('display','flex');
				$('.b2bking_rule_label_minimum').css('display','block');

				// if select Cart: cart_total_quantity and cart_total_value
				if (selectedApplies === 'cart_total' || selectedApplies.startsWith("tag")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value]').css('display','block');
				} else if (selectedApplies.startsWith("category")){
				// if select Category also have: category_product_quantity and category_product_value
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_value]').css('display','block');
				} else if (selectedApplies.startsWith("product")){
				// if select Product also have: product_quantity and product_value  
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_value]').css('display','block');
				} else if (selectedApplies === 'multiple_options' || selectedApplies === 'replace_ids'){
					$('.b2bking_dynamic_rule_condition_name option').css('display','block');
					$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_multiselect);
				}

				$('#b2bking_container_rulepriority').css('display','block');


			} else if (selectedWhat === 'minimum_order' || selectedWhat === 'maximum_order' ) {
				// show Quantity/value
				$('#b2bking_container_quantity_value').css('display','inline-block');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');

				// Show discount everywhere checkbox
				$('.b2bking_dynamic_rule_minimum_all_checkbox_container, .b2bking_minimum_options_information_box').css('display','flex');
				$('.b2bking_rule_label_minimum').css('display','block');

				$('#b2bking_container_rulepriority').css('display','block');

			} else if (selectedWhat === 'tax_exemption' ) {
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// show countries and requires
				$('#b2bking_container_countries, #b2bking_container_requires').css('display','inline-block');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
			} else if (selectedWhat === 'tax_exemption_user' ) {
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				// Applies does not apply - hide
				$('#b2bking_container_applies').css('display','none');
				// show countries and requires
				$('#b2bking_container_countries, #b2bking_container_requires, #b2bking_container_showtax').css('display','inline-block');
				if ($('#b2bking_rule_select_showtax').val() === 'display_only'){
					$('#b2bking_container_tax_shipping').css('display','inline-block');
					if ($('#b2bking_rule_select_tax_shipping').val() === 'yes'){
						$('#b2bking_container_tax_shipping_rate').css('display', 'inline-block');
					}
				}
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
			} else if (selectedWhat === 'add_tax_amount' || selectedWhat === 'add_tax_percentage' ) {
				// show one time
				$('#b2bking_one_time').css('display','inline-block');
				// show tax name
				$('#b2bking_container_taxname').css('display','inline-block');
				$('#b2bking_container_tax_taxable').css('display','inline-block');

				if (selectedApplies === 'one_time' && selectedWhat === 'add_tax_percentage'){
					$('#b2bking_container_tax_shipping').css('display','inline-block');
				}
				// if select Cart: cart_total_quantity and cart_total_value
				if (selectedApplies === 'cart_total' || selectedApplies === 'one_time' || selectedApplies.startsWith("tag")){
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value]').css('display','block');
				} else if (selectedApplies.startsWith("category")){
				// if select Category also have: category_product_quantity and category_product_value
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_value]').css('display','block');
				} else if (selectedApplies.startsWith("product")){
				// if select Product also have: product_quantity and product_value  
					$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_value]').css('display','block');
				} else if (selectedApplies === 'multiple_options' || selectedApplies === 'replace_ids'){
					$('.b2bking_dynamic_rule_condition_name option').css('display','block');
					$('#b2bking_rule_conditions_information_box_text').text(b2bking.conditions_multiselect);
				}

				$('#b2bking_container_rulepriority').css('display','block');

			} else if (selectedWhat === 'replace_prices_quote'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch, #b2bking_container_applies').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
			} else if (selectedWhat === 'rename_purchase_order'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch, #b2bking_container_applies').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_taxname').css('display','inline-block');

				$('#b2bking_container_paymentmethods').css('display','inline-block');

			} else if (selectedWhat === 'set_currency_symbol'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch, #b2bking_container_applies').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_currency').css('display','inline-block');
			} else if (selectedWhat === 'payment_method_minmax_order'){
				// How much does not apply - hide
				$('#b2bking_container_applies').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_paymentmethods, #b2bking_container_paymentmethods_minmax').css('display','inline-block');
			} else if (selectedWhat === 'payment_method_restriction'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_paymentmethods').css('display','inline-block');

			} else if (selectedWhat === 'shipping_method_restriction'){
				// How much does not apply - hide
				$('#b2bking_container_howmuch').css('display','none');
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_shippingmethods').css('display','inline-block');

			} else if (selectedWhat === 'payment_method_discount'){
				// How much does not apply - hide
				$('#b2bking_container_applies').css('display','none');
				// hide Conditions input and available conditions text
				$('#b2bking_rule_select_conditions_container').css('display','none');
				$('.b2bking_rule_conditions_information_box').css('display','none');
				$('#b2bking_container_paymentmethods, #b2bking_container_paymentmethods_percentamount').css('display','inline-block');
			}  else if (selectedWhat === 'bogo_discount'){
				$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=cart_total_value], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_value]').css('display','block');
				$('.b2bking_dynamic_rule_condition_name option[value=product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_value]').css('display','block');
				$('#b2bking_container_rulepriority').css('display','block');
			} else if (selectedWhat === 'raise_price'){
				$('.b2bking_dynamic_rule_condition_name option[value=cart_total_quantity], .b2bking_dynamic_rule_condition_name option[value=category_product_quantity], .b2bking_dynamic_rule_condition_name option[value=product_quantity]').css('display','block');

				$('#b2bking_container_rulepriority').css('display','block');
			}

			if (selectedApplies === 'replace_ids' && selectedWhat !== 'tax_exemption_user'){
				$('#b2bking_rule_select_applies_replaced_container').css('display','block');
			}

			if (selectedWho === 'replace_ids'){
				$('#b2bking_rule_select_who_replaced_container').css('display','block');
			}

			// Check all conditions. If selected condition what is display none, change to Cart Total Quantity (available for all)
			$(".b2bking_dynamic_rule_condition_name").each(function (i) {
				let selected = $(this).val();
				let selectedOption = $(this).find("option[value="+selected+"]");
				if (selectedOption.css('display')==='none'){
					$(this).val('cart_total_quantity');
				}
			});

			// Update Conditions
			updateConditionsHiddenField();
		}

		// On condition text change, update conditions hidden field
		$('body').on('input', '.b2bking_dynamic_rule_condition_number, .b2bking_dynamic_rule_condition_operator, .b2bking_dynamic_rule_condition_name', function () {
			updateConditionsHiddenField();
		});

		function updateConditionsHiddenField(){
			// Clear condtions field
			$('#b2bking_rule_select_conditions').val('');
			// For each condition, if not empty, add to field
			let conditions = '';

			$(".b2bking_dynamic_rule_condition_name").each(function (i) {
				// get its current number
				let currentNumber;
				let classList = $(this).attr('class').split(/\s+/);
				$.each(classList, function(index, item) {
				    if (item.includes('identifier')) {
				    	var itemArray = item.split("_");
				    	currentNumber = parseInt(itemArray[3]);
				    }
				});

				let numberField = $(".b2bking_dynamic_rule_condition_number.b2bking_condition_identifier_"+currentNumber).val();
				if (numberField === undefined){
					numberField = '';
				}

				if (numberField.trim() !== ''){
					conditions+=$(this).val()+';';
					conditions+=$(".b2bking_dynamic_rule_condition_operator.b2bking_condition_identifier_"+currentNumber).val()+';';
					conditions+=$(".b2bking_dynamic_rule_condition_number.b2bking_condition_identifier_"+currentNumber).val()+'|';
				}
			});
			// remove last character
			conditions = conditions.substring(0, conditions.length - 1);
			$('#b2bking_rule_select_conditions').val(conditions);
		}

		/* Offers */

		if (b2bking.current_post_type === 'b2bking_offer' || $('#b2bking_offer_access_metabox').length){
			// On load, retrieve offers
			var offerItemsCounter = 1;
			offerRetrieveHiddenField();
			offerCalculateTotals();
			
			// Initialize modern product selectors after offer data is loaded
			setTimeout(function() {
				initializeOfferProductSelectors();
			}, 50);
		}

		// When click "add item" add new offer item
		$('body').on('click', '.b2bking_offer_add_item_button', addNewOfferItem);
		
		// initialize offer select2
		$('.b2bking_offer_product_selector').select2();

		function addNewOfferItem(){
			// destroy select2
			$('.b2bking_offer_product_selector').select2();
			$('.b2bking_offer_product_selector').select2('destroy');

			let currentItem = offerItemsCounter;
			let nextItem = currentItem+1;
			offerItemsCounter++;
			
			// Clone the first row but remove the modern product selector
			let $clonedRow = $('#b2bking_offer_number_1').clone().attr('id', 'b2bking_offer_number_'+nextItem);
			
			// Remove the modern product selector from the cloned row
			$clonedRow.find('.b2bking_offer_product_selector_modern').remove();
			$clonedRow.find('.b2bking_offer_product_selector_container').remove();
			
			// Insert the cloned row
			$clonedRow.insertBefore('#b2bking_addbefore_offer_spacer');
			
			// Clear values from clone
			$('#b2bking_offer_number_'+nextItem+' .b2bking_offer_text_input').val('');
			$('#b2bking_offer_number_'+nextItem+' .b2bking_offer_product_selector').val('').trigger('change');
			
			if (parseInt(b2bking.offers_disable_ajax) === 0){
				// Add a fresh, empty modern product selector
				let $textInput = $('#b2bking_offer_number_'+nextItem+' .b2bking_offer_item_name');
				let $modernSelectorHtml = '<div class="b2bking_offer_product_selector_container"><select class="b2bking_offer_product_selector_modern" multiple="multiple" style="width: 100%;display:none"></select></div>';
				$textInput.after($modernSelectorHtml);
				
				// Add toggle button for new row
				let $container = $('#b2bking_offer_number_'+nextItem+' .b2bking_offer_product_selector_container');
				let $inputContainer = $container.closest('.b2bking_offer_input_container');
				let $toggleButton = $('<button type="button" class="b2bking-toggle-input" title="'+b2bking.switch_to_text+'" style="position: absolute; left: 210px; top: 9px; transform: translateY(-50%); background: none; border: none; color: #666; font-size: 12px; cursor: pointer; z-index: 10; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M18 10L21 7M21 7L18 4M21 7H7M6 14L3 17M3 17L6 20M3 17H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg></button>');
				$inputContainer.append($toggleButton);
				
				// Toggle functionality for new row
				let isTextMode = false;
				$toggleButton.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					
					if (isTextMode) {
						// Switch to dropdown mode
						$textInput.hide();
						$container.find('.b2bking_offer_product_selector_modern').show();
						$container.find('.select2-container').show();
						isTextMode = false;
					} else {
						// Switch to text mode
						$container.find('.b2bking_offer_product_selector_modern').hide();
						$container.find('.select2-container').hide();
						$textInput.show();
						isTextMode = true;
					}
				});
			}

			$('#b2bking_offer_number_'+nextItem+' .b2bking_item_subtotal').text(b2bking.currency_symbol+'0');
			// add delete button to new item
			$('<button type="button" class="secondary-button button b2bking_offer_delete_item_button">'+b2bking.delete+'</button>').insertAfter('#b2bking_offer_number_'+nextItem+' .b2bking_offer_add_item_button');
			
			//reinitialize select2
			$('.b2bking_offer_product_selector').select2();
			
			if (parseInt(b2bking.offers_disable_ajax) === 0){
				// Initialize the new modern product selector
				setTimeout(function() {
					initializeOfferProductSelectors();
				}, 50);
			}
		}

		// on change item, set price per unit

		jQuery('body').on('change', '.b2bking_offer_product_selector', function($ab){
			let price = jQuery(this).find('option:selected').data('price');
			if (price !== '' && price !== undefined){
				$(this).parent().parent().find('.b2bking_offer_item_price').val(price);
				$(this).parent().parent().find('.b2bking_offer_item_quantity').val(1); // set qty to 1 by default
				offerCalculateTotals();
			}
		});



		// On click "delete"
		$('body').on('click', '.b2bking_offer_delete_item_button', function(){
			$(this).parent().parent().remove();
			offerCalculateTotals();
			offerSetHiddenField();
		});

		// On quantity or price change, calculate totals
		$('body').on('input', '.b2bking_offer_item_quantity, .b2bking_offer_item_name, .b2bking_offer_item_price', function(){
			offerCalculateTotals();
			offerSetHiddenField();
		});
		
		function offerCalculateTotals(){
			var currency_symbol_used = b2bking.currency_symbol;
			if (currency_symbol_used === 'ر.س'){
				currency_symbol_used = b2bking.modified_currency_symbol;
			}
			let total = 0;
			// foreach item calculate subtotal
			$('.b2bking_offer_item_quantity').each(function(){
				let quantity = $(this).val();
				let price = $(this).parent().parent().find('.b2bking_offer_item_price').val();
				if (quantity !== undefined && price !== undefined){
					// set subtotal
					total+=price*quantity;
					$(this).parent().parent().find('.b2bking_item_subtotal').text(currency_symbol_used+Number((price*quantity).toFixed(4)));
				}
			});

			// finished, add up subtotals to get total
			$('#b2bking_offer_total_text_number').text(currency_symbol_used+Number((total).toFixed(4)));
		}

		function offerSetHiddenField(){
			let field = '';
			// clear textarea
			$('#b2bking_admin_offer_textarea').val('');
			// go through all items and list them IF they have PRICE AND QUANTITY
			$('.b2bking_offer_item_quantity').each(function(){
				let quantity = $(this).val();
				let price = $(this).parent().parent().find('.b2bking_offer_item_price').val();
				if (quantity !== undefined && price !== undefined && quantity !== null && price !== null && quantity !== '' && price !== ''){
					// Add it to string
					let name = $(this).parent().parent().find('.b2bking_offer_item_name').val();
					if (name === undefined || name === ''){
						name = '(no title)';
					}
					field+= name+';'+quantity+';'+price+'|';
				}
			});

			// at the end, remove last character
			field = field.substring(0, field.length - 1);
			$('#b2bking_admin_offer_textarea').val(field);
		}

		function offerRetrieveHiddenField(){
			// get field;
			let field = $('#b2bking_admin_offer_textarea').val();
			let itemsArray = field.split('|');
			// foreach condition, add condition, add new item
			itemsArray.forEach(function(item){
				let itemDetails = item.split(';');
				if (itemDetails[0] !== undefined && itemDetails[0] !== ''){
					$('#b2bking_offer_number_'+offerItemsCounter+' .b2bking_offer_item_name').val(itemDetails[0]);
					$('#b2bking_offer_number_'+offerItemsCounter+' .b2bking_offer_item_quantity').val(itemDetails[1]);
					$('#b2bking_offer_number_'+offerItemsCounter+' .b2bking_offer_item_price').val(itemDetails[2]);

					// fire: custom event 
					$('#b2bking_offer_number_'+offerItemsCounter+' .b2bking_offer_product_selector').trigger('b2bking_offer_item_initiated');
					addNewOfferItem();
				}
			});
			// at the end, remove the last Item added
			if (offerItemsCounter > 1){
				$('#b2bking_offer_number_'+offerItemsCounter).remove();
			}

		}

		/* USER SHIPPING AND PAYMENT METHODS PANEL */

		// On load, update 
		updateUserShippingPayment();
		// On change, update
		$('.b2bking_user_shipping_payment_methods_container_content_override_select').change(updateUserShippingPayment);

		function updateUserShippingPayment(){
			let selectedValue = $('.b2bking_user_shipping_payment_methods_container_content_override_select').val();
			if (selectedValue === 'default'){
				// hide shipping and payment methods
				$('.b2bking_user_payment_shipping_methods_container').css('display','none');
			} else if (selectedValue === 'manual'){
				// show shipping and payment methods
				$('.b2bking_user_payment_shipping_methods_container').css('display','flex');
			}
		}

		/* REGISTRATION FIELD */

		// On load, show hide user choices 
		showHideUserChoices();

		$('.b2bking_custom_field_settings_metabox_bottom_field_type_select').change(showHideUserChoices);

		function showHideUserChoices(){
			let selectedValue = $('.b2bking_custom_field_settings_metabox_bottom_field_type_select').val();
			if (selectedValue === 'select' || selectedValue === 'checkbox' || selectedValue === 'radio'){
				$('.b2bking_custom_field_settings_metabox_bottom_user_choices').css('display','block');
			} else {
				$('.b2bking_custom_field_settings_metabox_bottom_user_choices').css('display','none');
			}
		}

		/* USER REGISTRATION DATA - APPROVE REJECT */
		$('.b2bking_user_registration_user_data_container_element_approval_button_approve').on('click', function(){

			if ($('.b2bking_user_registration_user_data_container_element_select_group').val() === ''){

				$('.b2bking_user_registration_user_data_container_element_select_group')[0].reportValidity();

			} else {

				Swal.fire({
				  title: b2bking.are_you_sure,
				  text: b2bking.are_you_sure_approve,
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonColor: '#20d580',
				  cancelButtonColor: '#e85347',
				  confirmButtonText: b2bking.yes_confirm
				}).then((result) => {
				  if (result.isConfirmed) {
			  		var datavar = {
			            action: 'b2bkingapproveuser',
			            security: b2bking.security,
			            chosen_group: $('.b2bking_user_registration_user_data_container_element_select_group').val(),
			            credit: $('#b2bking_approval_credit_user').val(),
			            salesagent: $('#salesking_assign_sales_agent').val(),
			            user: $('#b2bking_user_registration_data_id').val(),
			        };

					$.post(ajaxurl, datavar, function(response){
						window.location.reload();
					});
				  }
				});
			}
		});

		$('.b2bking_user_registration_user_data_container_element_approval_button_reject').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.are_you_sure_reject,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
  				var datavar = {
  		            action: 'b2bkingrejectuser',
  		            security: b2bking.security,
  		            user: $('#b2bking_user_registration_data_id').val(),
  		        };

  				$.post(ajaxurl, datavar, function(response){
  					window.location = b2bking.reject_redirection_url;
  				});
			  }
			});

		});

		$('.b2bking_user_registration_user_data_container_element_approval_button_deactivate').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.are_you_sure_deactivate,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
					var datavar = {
			            action: 'b2bkingdeactivateuser',
			            security: b2bking.security,
			            user: $('#b2bking_user_registration_data_id').val(),
			        };

					$.post(ajaxurl, datavar, function(response){
						window.location.reload();
					});
			  }
			});

		});

		// Download registration files
		$('.b2bking_user_registration_user_data_container_element_download').on('click', function(){
			let attachment = $(this).val();
			if (parseInt(b2bking.download_go_to_file) === 1){
				var datavar = {
		            action: 'b2bkinghandledownloadrequest',
		            security: b2bking.security,
		            attachment: attachment,
		        };

				$.post(ajaxurl, datavar, function(response){

					let url = response;
					var a = document.createElement("a");
					a.href = url;
					let fileName = url.split("/").pop();
					a.download = fileName;
					document.body.appendChild(a);
					a.click();
					window.URL.revokeObjectURL(url);
					a.remove();

				});
			} else if (parseInt(b2bking.download_go_to_file) === 2){
				window.location = b2bking.adminurl+'upload.php?item='+attachment;
			} else {
				window.location = ajaxurl + '?action=b2bkinghandledownloadrequest&attachment='+attachment+'&security=' + b2bking.security;
			}


			
		});
		
		updateAddToBilling();
		$('#b2bking_custom_field_billing_connection_metabox_select').change(updateAddToBilling);
		// Billing field connection, show add to billing only if default connection is none
		function updateAddToBilling(){
			let billingConnectionSelected = $('#b2bking_custom_field_billing_connection_metabox_select').val();
			if (billingConnectionSelected === 'none' || billingConnectionSelected === 'billing_vat'){
				$('.b2bking_add_to_billing_container').css('display', '');
			} else {
				$('.b2bking_add_to_billing_container').css('display', 'none');
			}

			// Show VAT container only if selected billing connection is VAT
			if (billingConnectionSelected === 'billing_vat'){
				$('.b2bking_VAT_container').css('display', 'flex');
			} else {
				$('.b2bking_VAT_container').css('display', 'none');
			}

			if (billingConnectionSelected === 'custom_mapping'){
				$('.b2bking_custom_mapping_container').css('display', 'flex');
			}  else {
				$('.b2bking_custom_mapping_container').css('display', 'none');
			}
		}

		// show hide Registration Role Automatic Approval - show only if automatic approval is selected
		showHideAutomaticApprovalGroup();
		$('.b2bking_custom_role_settings_metabox_container_element_select').change(showHideAutomaticApprovalGroup);
		function showHideAutomaticApprovalGroup(){
			let selectedValue = $('.b2bking_custom_role_settings_metabox_container_element_select').val();
			if (selectedValue === 'automatic'){
				$('.b2bking_automatic_approval_customer_group_container').css('display','block');
			} else {
				$('.b2bking_automatic_approval_customer_group_container').css('display','none');
			}
		}

		// show hide multiple roles selector
		showHideMultipleRolesSelector();
		$('.b2bking_custom_field_settings_metabox_top_column_registration_role_select').change(showHideMultipleRolesSelector);
		function showHideMultipleRolesSelector(){
			let selectedValue = $('.b2bking_custom_field_settings_metabox_top_column_registration_role_select').val();
			if (selectedValue === 'multipleroles'){
				$('#b2bking_select_multiple_roles_selector').css('display','block');
			} else {
				$('#b2bking_select_multiple_roles_selector').css('display','none');
			}
		}

		// Tools
		// On clicking download price list
		$('#b2bking_download_products_button').on('click', function() {
		    window.location = ajaxurl + '?action=b2bkingdownloadpricelist&security=' + b2bking.security;
	    });

	    // Download troubleshooting file
	    $('#b2bking_download_troubleshooting_button').on('click', function() {
		    window.location = ajaxurl + '?action=b2bkingdownloadtroubleshooting&security=' + b2bking.security;
	    });

	    // On clicking set all users to group
	    $('#b2bking_set_users_in_group').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.are_you_sure_set_users,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#20d580',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {

		  			var datavar = {
		  	            action: 'b2bkingbulksetusers',
		  	            security: b2bking.security,
		  	            chosen_group: $('#b2bking_customergroup').val(),
		  	        };

		  			$.post(ajaxurl, datavar, function(response){
						Swal.fire(
		    	            b2bking.users_have_been_moved, 
		    	            "", 
		    	            "success"
		    	        );
		  			});
			  }
			});

	    });

        // On clicking set category in bulk
        $('#b2bking_set_category_in_bulk').on('click', function(){
        
    		Swal.fire({
    		  title: b2bking.are_you_sure,
    		  text: b2bking.are_you_sure_set_categories,
    		  icon: 'warning',
    		  showCancelButton: true,
    		  confirmButtonColor: '#20d580',
    		  cancelButtonColor: '#e85347',
    		  confirmButtonText: b2bking.yes_confirm
    		}).then((result) => {
    		  if (result.isConfirmed) {

  	    			var datavar = {
  	    	            action: 'b2bkingbulksetcategory',
  	    	            security: b2bking.security,
  	    	            chosen_option: $('#b2bking_categorybulk').val(),
  	    	        };

  	    			$.post(ajaxurl, datavar, function(response){

						Swal.fire(
		    	            b2bking.categories_have_been_set, 
		    	            "", 
		    	            "success"
		    	        );
  		        	});
    		  }
    		});
        });

        // On clicking set accounts as subaccounts
        $('#b2bking_set_accounts_as_subaccounts').on('click', function(){

    		Swal.fire({
    		  title: b2bking.are_you_sure,
    		  text: b2bking.are_you_sure_set_subaccounts,
    		  icon: 'warning',
    		  showCancelButton: true,
    		  confirmButtonColor: '#20d580',
    		  cancelButtonColor: '#e85347',
    		  confirmButtonText: b2bking.yes_confirm
    		}).then((result) => {
    		  if (result.isConfirmed) {

		  			var datavar = {
		  	            action: 'b2bkingbulksetsubaccounts',
		  	            security: b2bking.security,
		  	            option_first: $('#b2bking_set_user_subaccounts_first').val(),
		  	            option_second: $('#b2bking_set_user_subaccounts_second').val(),
		  	        };

		  			$.post(ajaxurl, datavar, function(response){
						Swal.fire(
		    	            b2bking.subaccounts_have_been_set, 
		    	            "", 
		    	            "success"
		    	        );
		  			});
    		  }
    		});
        });

        // On clicking set accounts as regular accounts
        $('#b2bking_set_subaccounts_regular_button').on('click', function(){


    		Swal.fire({
    		  title: b2bking.are_you_sure,
    		  text: b2bking.are_you_sure_set_subaccounts_regular,
    		  icon: 'warning',
    		  showCancelButton: true,
    		  confirmButtonColor: '#20d580',
    		  cancelButtonColor: '#e85347',
    		  confirmButtonText: b2bking.yes_confirm
    		}).then((result) => {
    		  if (result.isConfirmed) {

		  			var datavar = {
		  	            action: 'b2bkingbulksetsubaccountsregular',
		  	            security: b2bking.security,
		  	            option_first: $('#b2bking_set_subaccounts_regular_input').val(),
		  	        };

		  			$.post(ajaxurl, datavar, function(response){
							Swal.fire(
			    	            b2bking.subaccounts_have_been_set, 
			    	            "", 
			    	            "success"
			    	        );
		  			});
    		  }
    		});
        });

        // On clicking transfer subaccounts
        $('#b2bking_transfer_subaccounts_button').on('click', function(){

    		Swal.fire({
    		  title: b2bking.are_you_sure,
    		  text: b2bking.are_you_sure_transfer_subaccounts,
    		  icon: 'warning',
    		  showCancelButton: true,
    		  confirmButtonColor: '#20d580',
    		  cancelButtonColor: '#e85347',
    		  confirmButtonText: b2bking.yes_confirm
    		}).then((result) => {
    		  if (result.isConfirmed) {

		  			var datavar = {
		  	            action: 'b2bkingtransfersubaccounts',
		  	            security: b2bking.security,
		  	            option_first: $('#b2bking_transfer_subaccounts_from').val(),
		  	            option_second: $('#b2bking_transfer_subaccounts_to').val(),
		  	        };

		  			$.post(ajaxurl, datavar, function(response){
						Swal.fire(
				            b2bking.subaccounts_have_been_transferred,
				            "",
				            "success"
				        );
		  			});
    		  }
    		});
        });

        // On clicking update b2bking user data (registration data)
        $('#b2bking_update_registration_data_button').on('click', function(){

			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.are_you_sure_update_user,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#20d580',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
			  		var fields = $('#b2bking_admin_user_fields_string').val();
		    		var fieldsArray = fields.split(',');

					var datavar = {
			            action: 'b2bkingupdateuserdata',
			            security: b2bking.security,
			            userid: $('#b2bking_admin_user_id').val(),
			            field_strings: fields,
			            group: $('#b2bking_customergroup').val()
			        };

			        fieldsArray.forEach(myFunction);

			        function myFunction(item, index) {
			        	if (parseInt(item.length) !== 0){
			        		if (parseInt($('input[name=b2bking_custom_field_'+item+']').length) !== 0){
			        			var value = $('input[name=b2bking_custom_field_'+item+']').val();
			        		} else if (parseInt($('textarea[name=b2bking_custom_field_'+item+']').length) !== 0){
			        			var value = $('textarea[name=b2bking_custom_field_'+item+']').val();
			        		}
			        		if (value !== null){
			        			let key = 'field_'+item;
			        			datavar[key] = value;
			        		}
			        	}
			        }

			        console.log(datavar);

					$.post(ajaxurl, datavar, function(response){
						if (response.startsWith('vatfailed')){
							if (response.length > 9){
								var errordetails = response.slice(9);
								var errordetails = errordetails.slice(0, -7);
							} else {
								var errordetails = '';
							}

							if (errordetails.trim().length>1){
								errordetails = 'Validation error: ' + errordetails;
							}

							Swal.fire(
			    	            b2bking.issue_occurred, 
			    	            b2bking.user_has_been_updated_vat_failed + ' ' + errordetails, 
			    	            "warning"
			    	        );

						} else {

							Swal.fire(
			    	            b2bking.success, 
			    	            b2bking.user_has_been_updated, 
			    	            "success"
			    	        );
						}

						
					});
			  }
			});
        });

        // on clicking "add tier" in the product page
        $('.b2bking_product_add_tier').on('click', function(){
        	var groupid = $(this).parent().find('.b2bking_groupid').val();
        	$('<span class="wrap b2bking_product_wrap"><input name="b2bking_group_'+groupid+'_pricetiers_quantity[]" placeholder="'+b2bking.min_quantity_text+'" class="b2bking_tiered_pricing_element" type="number" step="any" min="0" /><input name="b2bking_group_'+groupid+'_pricetiers_price[]" placeholder="'+b2bking.final_price_text+'" class="b2bking_tiered_pricing_element short wc_input_price" type="text"  /></span>').insertBefore($(this).parent());
        });

        // on clicking "add row" in the product page
        $('.b2bking_product_add_row').on('click', function(){
        	var groupid = $(this).parent().find('.b2bking_groupid').val();
        	$('<span class="wrap b2bking_customrows_wrap"><input name="b2bking_group_'+groupid+'_customrows_label[]" placeholder="'+b2bking.label_text+'" class="b2bking_customrow_element" type="text" /><input name="b2bking_group_'+groupid+'_customrows_text[]" placeholder="'+b2bking.text_text+'" class="b2bking_customrow_element" type="text" /></span>').insertBefore($(this).parent());
        });

        // on clicking "add tier" in the product variation page
        $('body').on('click', '.b2bking_product_add_tier_variation', function(event) {
        	var groupid = $(this).parent().find('.b2bking_groupid').val();
        	var variationid = $(this).parent().find('.b2bking_variationid').val();
            $('<span class="wrap b2bking_product_wrap_variation"><input name="b2bking_group_'+groupid+'_'+variationid+'_pricetiers_quantity[]" placeholder="'+b2bking.min_quantity_text+'" class="b2bking_tiered_pricing_element_variation" type="number" step="any" min="0" /><input name="b2bking_group_'+groupid+'_'+variationid+'_pricetiers_price[]" placeholder="'+b2bking.final_price_text+'" class="b2bking_tiered_pricing_element_variation short wc_input_price" type="text" /></span>').insertBefore($(this).parent());
        });

        $('#b2bking_b2b_pricing_variations').detach().insertAfter('option[value=delete_all]');
        // bulk edit variations
        $( '.wc-metaboxes-wrapper' ).on('change', '#field_to_edit', function(){
        	var do_variation_action = $( 'select.variation_actions' ).val();
        	if (do_variation_action.startsWith('b2bking')){
        		var value = prompt(woocommerce_admin_meta_boxes_variations.i18n_enter_a_value);
        		var values = do_variation_action.split('_');

        		var regularsale = values[1];
        		var productid = values[4];
        		var groupid = values[6];

				var datavar = {
		            action: 'b2bkingbulksetvariationprices',
		            security: b2bking.security,
		            price: value,
		            regular_sale: regularsale,
		            product_id: productid,
		            group_id: groupid,
		        };

				$.post(ajaxurl, datavar, function(response){
					window.location.reload();
				});
        	}
        });

        // print user registration data
        $('#b2bking_print_user_data').on('click', function(){
        	var printContents = document.getElementById('b2bking_registration_data_container').innerHTML;
			var originalContents = document.body.innerHTML;

			document.body.innerHTML = printContents;

			window.print();

			document.body.innerHTML = originalContents;
        });

 	
 		// on click Select all
 		$('.b2bking_select_all_products_backend').on('click', function(){
 		    $('select[name="b2bking_select_multiple_product_categories_selector_select[]"]').select2('destroy').find('optgroup:nth-child(3) option').prop('selected', 'selected').end().select2();
 		});

 		// all simple products
 		$('.b2bking_select_simple_products_backend').on('click', function(){
 		    $('.b2bking_select_multiple_product_categories_selector_select').select2('destroy').find('optgroup:nth-child(3) option[data-type="simple"]').prop('selected', 'selected').end().select2();
 		});

 		$('.b2bking_select_all_variations_backend').on('click', function(){
 		    $('.b2bking_select_multiple_product_categories_selector_select').select2('destroy').find('optgroup:nth-child(4) option').prop('selected', 'selected').end().select2();
 		});
 		$('.b2bking_select_all_categories_backend').on('click', function(){
 		    $('select[name="b2bking_select_multiple_product_categories_selector_select[]"]').select2('destroy').find('optgroup:nth-child(2) option').prop('selected', 'selected').end().select2();
 		});
 		$('.b2bking_unselect_all_products_backend').on('click', function(){
 		    $('select[name="b2bking_select_multiple_product_categories_selector_select[]"]').val(null).trigger("change");
 		});

 		// product and variation ID(s)
 		$('.b2bking_select_all_products_variations_backend').on('click', function(){
 		    $('#b2bking_rule_select_applies_replaced').val($('#b2bking_all_products_variations').val());
 		});
 		$('.b2bking_select_all_simple_products_variations_backend').on('click', function(){
 		    $('#b2bking_rule_select_applies_replaced').val($('#b2bking_all_simple_products_variations').val());
 		});
 		$('.b2bking_select_all_variations_variations_backend').on('click', function(){
 		    $('#b2bking_rule_select_applies_replaced').val($('#b2bking_all_variations_variations').val());
 		});
 		$('.b2bking_unselect_all_products_variations_backend').on('click', function(){
 		    $("#b2bking_rule_select_applies_replaced").val(null).trigger("change");
 		});

 		/* sort drag drop backend */

 		function enable_sortable_type(type){
 			jQuery('.post-type-b2bking_custom_field .wp-list-table tbody, .b2bking_page_b2bking_custom_field .wp-list-table tbody, .post-type-b2bking_quote_field .wp-list-table tbody,  .b2bking_page_b2bking_quote_field .wp-list-table tbody, .post-type-b2bking_custom_role .wp-list-table tbody,  .b2bking_page_b2bking_custom_role .wp-list-table tbody').sortable({
 			    placeholder: {
 			        element: function(currentItem) {
 			            var cols    =   jQuery(currentItem).children('td:visible').length + 1;
 			            return jQuery('<tr class="ui-sortable-placeholder"><td colspan="' + cols + '">&nbsp;</td></tr>')[0];
 			        },
 			        update: function(container, p) {
 			            return;
 			        }
 			    },

 			    'items': 'tr',
 			    'handle': ".b2bking_sort",
 			    'axis': 'y',
 			    'update' : function(e, ui) {
 			       
 			        var post_type           =   type;
 			        var order               =   jQuery('#the-list').sortable('serialize');
 			        var queryString = { "action": "b2bking_update_sort_menu_order", "post_type" : post_type, "order" : order};
 			        //send the data through ajax
 			        jQuery.ajax({
 			          type: 'POST',
 			          url: ajaxurl,
 			          data: queryString,
 			          cache: false,
 			          dataType: "html",
 			          success: function(data){
 						const Toast = Swal.mixin({
		        		  toast: true,
		        		  position: 'bottom-end',
		        		  showConfirmButton: false,
		        		  timer: 1000,
		        		  timerProgressBar: false,
		        		  didOpen: (toast) => {
		        		    toast.addEventListener('mouseenter', Swal.stopTimer)
		        		    toast.addEventListener('mouseleave', Swal.resumeTimer)
		        		  }
		        		});
 						Toast.fire({
	        			  icon: 'success',
	        			  title: b2bking.settings_saved
	        			});
 			          },
 			          error: function(html){

 			              }
 			        });
 			    }
 			});

 			if (typeof tippy === 'function') {

	 			tippy('.sort_order_tip', {
			       animation: 'shift-away',
			       theme: 'material',
			       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.sort_order_help_tip+'</span>',
			       allowHTML: true,
			    });

	 			tippy('.form_preview_help_tip', {
			       animation: 'shift-away',
			       theme: 'material',
			       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.form_preview_help_tip+'</span>',
			       allowHTML: true,
			    });
			    

	 			tippy('.b2bking_edit_icon_hover_placeholder, .b2bking_edit_icon_hover_label, .b2bking_edit_icon_hover_role', {
			       animation: 'shift-away',
			       theme: 'material',
			       content: '<span style="text-align:center;line-height:15px;padding:0px;display:block;font-size:11px">'+b2bking.quick_edit+'</span>',
			       allowHTML: true,
			    });

	 			tippy('.b2bking_duplicate_icon_hover_label', {
			       animation: 'shift-away',
			       theme: 'material',
			       content: '<span style="text-align:center;line-height:15px;padding:0px;display:block;font-size:11px">'+b2bking.duplicate+'</span>',
			       allowHTML: true,
			    });

	 		}

 		}
 		if (parseInt(jQuery('.post-type-b2bking_custom_field').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_custom_field').length) !== 0){
 			enable_sortable_type('b2bking_custom_field');
 		}
 		if (parseInt(jQuery('.post-type-b2bking_quote_field').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_quote_field').length) !== 0){
 			enable_sortable_type('b2bking_quote_field');
 		}
 		if (parseInt(jQuery('.post-type-b2bking_custom_role').length) !== 0 || parseInt(jQuery('.b2bking_page_b2bking_custom_role').length) !== 0){
 			enable_sortable_type('b2bking_custom_role');
 		}

 		if (typeof tippy === 'function') {

			tippy('.b2bking_icons_container', {
		       animation: 'shift-away',
		       theme: 'material',
		       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.icons_text_message+'</span>',
		       allowHTML: true,
		    });
	 		// settings icons tippy
			tippy('.b2bking_lock_icon', {
		       animation: 'shift-away',
		       theme: 'material',
		       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">[lock]</span>',
		       allowHTML: true,
		    });
	    	tippy('.b2bking_login_icon', {
	           animation: 'shift-away',
	           theme: 'material',
	           content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">[login]</span>',
	           allowHTML: true,
	        });
			tippy('.b2bking_wholesale_icon', {
		       animation: 'shift-away',
		       theme: 'material',
		       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">[wholesale]</span>',
		       allowHTML: true,
		    });
	    	tippy('.b2bking_business_icon', {
	           animation: 'shift-away',
	           theme: 'material',
	           content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">[business]</span>',
	           allowHTML: true,
	        });

	    }

	 	/* registration fields opacity */
	 	function set_registration_fields_opacity(){
 		 	jQuery('tr.type-b2bking_custom_field, tr.type-b2bking_custom_role, tr.type-b2bking_offer, tr.type-b2bking_grule, tr.type-b2bking_rule, tr.type-b2bking_quote_field').each(function(){
 		 		let row = $(this);
 				let checkbox = $(this).find('.b2bking_status .b2bking_switch_input');
 				if (checkbox.is(':checked')){
 					row.css('opacity','1');
 				} else {
 					row.css('opacity','0.45');
 				}
 			});
	 	}
	 	
		jQuery('body').on('change', '.b2bking_switch_input', function(){
			set_registration_fields_opacity();

			// call ajax
			var datavar = {
	            action: 'b2bkingchangefield',
	            enabled: $(this).is(':checked'),
	            security: b2bking.security,
	            fieldid: $(this).attr('id').split('_')[3]
	        };

	        var checkbox = $(this);

	        // for dynamic rules, show/hide "disabled / draft" status.
	        let poststate = $(this).parent().parent().parent().find('.type-b2bking_rule .post-state');
	        if (datavar.enabled){
	        	$(poststate).text(b2bking.enabled);
	        } else {
	        	$(poststate).text(b2bking.disabled);
	        }

	        	        
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){

					// if rules, delay further to also clear rule caches, clear cache only once
					if (jQuery('.type-b2bking_rule').length > 0){

						// rules page, must clear cache
						rules_in_queue--; // one less rule in queue

						// clear caches only if there are no more rules in queue
						if (rules_in_queue <= 0){
							rules_in_queue = 0;
							// call ajax
							var datavar = {
					            action: 'b2bking_clear_rules_caches',
					            security: b2bking.security,
					        };

					        $.post(ajaxurl, datavar, function(response){
					        	if (response === 'success'){

					        		// fire success
					        		const Toast = Swal.mixin({
					        		  toast: true,
					        		  position: 'bottom-end',
					        		  showConfirmButton: false,
					        		  timer: 1000,
					        		  timerProgressBar: false,
					        		  didOpen: (toast) => {
					        		    toast.addEventListener('mouseenter', Swal.stopTimer)
					        		    toast.addEventListener('mouseleave', Swal.resumeTimer)
					        		  }
					        		});

					        		// set delay so that if select all / enable disable is clicked, there's not a rapid fire of 20 toasts
					        		let current_time = Date.now(); // milliseconds
					        		// if 1000ms passed, you can fire it again
					        		if ((current_time - last_toast_success_fired_time) > 250) {
					        			Toast.fire({
					        			  icon: 'success',
					        			  title: b2bking.settings_saved
					        			});
					        			last_toast_success_fired_time = Date.now();
					        		}
					        	}
					        });
						}

					} else {
						// fire success
						const Toast = Swal.mixin({
						  toast: true,
						  position: 'bottom-end',
						  showConfirmButton: false,
						  timer: 1000,
						  timerProgressBar: false,
						  didOpen: (toast) => {
						    toast.addEventListener('mouseenter', Swal.stopTimer)
						    toast.addEventListener('mouseleave', Swal.resumeTimer)
						  }
						})

						// set delay so that if select all / enable disable is clicked, there's not a rapid fire of 20 toasts
						let current_time = Date.now(); // milliseconds
						// if 1000ms passed, you can fire it again
						if ((current_time - last_toast_success_fired_time) > 250) {
							Toast.fire({
							  icon: 'success',
							  title: b2bking.settings_saved
							});
							last_toast_success_fired_time = Date.now();
						}
					}

					
					
				}
			});
		});

		jQuery('body').on('change', '.b2bking_switch_input_required', function(){

			// add or remove *
			// call ajax
			var datavar = {
	            action: 'b2bkingchangefieldrequired',
	            enabled: $(this).is(':checked'),
	            security: b2bking.security,
	            fieldid: $(this).attr('id').split('_')[4]
	        };

	        if (datavar.enabled){
	        	$(this).parent().parent().find('.b2bking_preview .required').css('display','inline-block');
	        } else {
	        	$(this).parent().parent().find('.b2bking_preview .required').css('display','none');
	        }

	        var checkbox = $(this);
	        	        
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){

					const Toast = Swal.mixin({
					  toast: true,
					  position: 'bottom-end',
					  showConfirmButton: false,
					  timer: 1000,
					  timerProgressBar: false,
					  didOpen: (toast) => {
					    toast.addEventListener('mouseenter', Swal.stopTimer)
					    toast.addEventListener('mouseleave', Swal.resumeTimer)
					  }
					})

					Toast.fire({
					  icon: 'success',
					  title: b2bking.settings_saved
					});
				}
			});
		});

		// on clicking Registration Form Shortcodes button
		$('body').on('click','#b2bking_registration_form_shortcode_button', function(){
			Swal.fire({
			  title: '<strong>Registration Form Shortcodes List</strong>',
			  width: 1000,
			  icon: 'question',
			  html: b2bking.registration_form_shortcodes_html,			    
			  showCloseButton: true,
			  showCancelButton: false,
			  showConfirmButton: false,
			  customClass: {
			    icon: 'b2bking_registration_shortcodes_icon',
			    title: 'b2bking_registration_shortcodes_title',
			    container: 'b2bking_registration_shortcodes_container',
			  }
			});

 			if (typeof tippy === 'function') {
 			    tippy('.b2bking_rshortcode_icon', {
 			        animation: 'shift-away',
 			        theme: 'material',
 			        content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">' + b2bking.click_to_copy + '</span>',
 			        allowHTML: true,
 			    });

 			    tippy('#b2bking_copied_rform', {
 			      // default
 			      trigger: 'click',
 			      content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.copied+'</span>',
 			      allowHTML: true,
 			      arrow: false,
 			      placement:'right',
 			    });
 			}

		    

		    $('.b2bking_rshortcode_icon').on('click', function(){

		    	// get current id
		    	let roleid = $(this).parent().parent().find('.roleid').val();
		    	let buildid = 'b2bking_rshortcode_form_'+roleid;

		    	var copyText = document.getElementById(buildid);
		    	copyText.select();
		    	copyText.setSelectionRange(0, 99999); /* For mobile devices */

		    	/* Copy the text inside the text field */
		    	document.execCommand("copy");
		    	$('#b2bking_copied_rform').click();

		    });
		    $('.b2bking_rinclude_login_form').on('change', function(){
		    	let shortcodeinput = $(this).parent().parent().find('.b2bking_rshortcode_form');
		    	let shortcode = shortcodeinput.val();

		    	if ($(this).is(':checked')){
		    		shortcode = shortcode.replace('b2bking_b2b_registration_only','b2bking_b2b_registration');
		    	} else {
		    		shortcode = shortcode.replace('b2bking_b2b_registration_only','b2bking_b2b_registration');
		    		shortcode = shortcode.replace('b2bking_b2b_registration','b2bking_b2b_registration_only');
		    	}

		    	shortcodeinput.val(shortcode);
		    });
		});

		// on clicking BULK ORDER Form Shortcodes button
		$('body').on('click','#b2bking_bulkorder_form_shortcode_button', function(){
			Swal.fire({
			  title: '<strong>Order Form Shortcodes List</strong>',
			  width: 1000,
			  icon: 'question',
			  html: b2bking.bulkorder_form_shortcodes_html,			    
			  showCloseButton: true,
			  showCancelButton: false,
			  showConfirmButton: false,
			  customClass: {
			    icon: 'b2bking_registration_shortcodes_icon',
			    title: 'b2bking_registration_shortcodes_title',
			    container: 'b2bking_registration_shortcodes_container b2bking_bulkorder_shortcodes_container',
			  }
			});

			if (typeof tippy === 'function') {

	 			tippy('.b2bking_rshortcode_icon', {
			       animation: 'shift-away',
			       theme: 'material',
			       content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.click_to_copy+'</span>',
			       allowHTML: true,
			    });
			    tippy('#b2bking_copied_rform', {
			      // default
			      trigger: 'click',
			      content: '<span style="text-align:center;line-height:25px;padding:5px;display:block">'+b2bking.copied+'</span>',
			      allowHTML: true,
			      arrow: false,
			      placement:'right',
			    });

			}

		    $('.b2bking_rshortcode_icon').on('click', function(){

		    	// get current id
		    	let roleid = $(this).parent().parent().find('.roleid').val();
		    	let buildid = 'b2bking_rshortcode_form_'+roleid;

		    	var copyText = document.getElementById(buildid);
		    	copyText.select();
		    	copyText.setSelectionRange(0, 99999); /* For mobile devices */

		    	/* Copy the text inside the text field */
		    	document.execCommand("copy");
		    	$('#b2bking_copied_rform').click();

		    });
		});

		/* registration fields on click quick edit PLACEHOLDER */
		$('body').on('click', '.b2bking_edit_icon_hover_placeholder', function(){
			let row = $(this).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_placeholder_input');
			let startingtext = startingtextfield.text();

			// hide field, show input edit
			startingtextfield.css('display','none');
			edittextinput.css('display','block');

			// copy text from starting to input 
			edittextinput.val(startingtext).focus().val(startingtext); // double needed for focus

			// hide edit icon, show confirm icon
			$(this).css('display','none');
			row.find('.b2bking_confirm_icon_hover').css('display','flex');
		});

		// save placeholder text on focusout, eand on enter
		$('body').on('focusout', '.b2bking_edit_placeholder_input', function(){
			save_placeholder_text($(this));
		});

		$('body').on('keypress', '.b2bking_edit_placeholder_input', function(e) {
		    var code = e.keyCode || e.which;
		    if(code==13){
		        $(this).blur();
		        e.preventDefault();
		        e.stopPropagation();
		    }
		});

		$('body').on('input', '.b2bking_edit_placeholder_input', function(){
			let row = $(this).parent().parent();
			let newtext = $(this).val();
			let previewinput = row.find('.b2bking_field_preview input');
			previewinput.attr('placeholder',newtext);

		});

		function save_placeholder_text(element){
			let row = $(element).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_placeholder_input');
			let startingtext = startingtextfield.text();
			let editedtext = edittextinput.val();

			// hide field, show input edit
			startingtextfield.css('display','block');
			edittextinput.css('display','none');

			// copy text from input to starting
			startingtextfield.text(editedtext);

			// hide edit icon, show confirm icon
			$(element).css('display','none');
			row.find('.b2bking_edit_icon_hover_placeholder').css('display','');

			// save and show "saved successfully"
			var datavar = {
	            action: 'b2bkingsavefieldplaceholder',
	            security: b2bking.security,
	            fieldid: $(element).parent().parent().attr('id').split('-')[1],
	            text: editedtext,
	        };
	       	
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){

					show_success_toast();
				}
			});
		}

		/* registration fields on click quick edit ROLE */
		$('body').on('click', '.b2bking_edit_icon_hover_role', function(){
			let row = $(this).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_role_input');

			// hide field, show input edit
			startingtextfield.css('display','none');
			edittextinput.css('display','block');
			edittextinput.focus(); // double needed for focus

			// hide edit icon, show confirm icon
			$(this).css('display','none');
		});
		// save label text on focusout, eand on enter
		$('body').on('focusout', '.b2bking_edit_role_input', function(){
			// go back to standard
			let row = $(this).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_role_input');

			// hide field, show input edit
			startingtextfield.css('display','block');
			edittextinput.css('display','none');
			row.find('.b2bking_edit_icon_hover_role').css('display','');

			show_success_toast();
		});
		
		$('body').on('keypress', '.b2bking_edit_role_input', function(e) {
		    var code = e.keyCode || e.which;
		    if(code==13){
		        $(this).blur();
		        e.preventDefault();
		        e.stopPropagation();

		        show_success_toast();
		    }
		});
		
		$('body').on('change', '.b2bking_edit_role_input', function(){
			// save
			let newrole = $(this).val();
			let newtext = $(this).find('option:selected').text();
			
			$(this).parent().find('.b2bking_text').text(newtext).css('display','block');
			$(this).css('display','none');

			// save and show "saved successfully"
			var datavar = {
		        action: 'b2bkingsavefieldrole',
		        security: b2bking.security,
		        fieldid: $(this).parent().parent().attr('id').split('-')[1],
		        role: newrole,
		    };

			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){

					show_success_toast();
				}
			});
			

		});

		/* registration fields on click quick edit LABEL */
		$('body').on('click', '.b2bking_edit_icon_hover_label', function(){
			let row = $(this).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_label_input');
			let startingtext = startingtextfield.text();

			// hide field, show input edit
			startingtextfield.css('display','none');
			edittextinput.css('display','block');

			// copy text from starting to input 
			edittextinput.val(startingtext).focus().val(startingtext); // double needed for focus

			// hide edit icon, show confirm icon
			$(this).css('display','none');
			$(this).parent().find('.b2bking_duplicate_icon_hover_label').css('display','none');
			row.find('.b2bking_confirm_icon_hover').css('display','flex');
		});


		// save label text on focusout, eand on enter
		$('body').on('focusout', '.b2bking_edit_label_input', function(){
			save_label_text($(this));
		});

		$('body').on('keypress', '.b2bking_edit_label_input', function(e) {
		    var code = e.keyCode || e.which;
		    if(code==13){
		        $(this).blur();
		        e.preventDefault();
		        e.stopPropagation();
		    }
		});

		$('body').on('input', '.b2bking_edit_label_input', function(){
			let row = $(this).parent().parent();
			let newtext = $(this).val();
			let previewinput = row.find('.b2bking_field_preview .b2bking_label_text_preview');
			previewinput.text(newtext);

		});

		// on click duplicate
		$('body').on('click', '.b2bking_duplicate_icon_hover_label', function(){
			Swal.fire({
			  title: b2bking.are_you_sure,
			  text: b2bking.confirm_duplicate,
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#20d580',
			  cancelButtonColor: '#e85347',
			  confirmButtonText: b2bking.yes_confirm
			}).then((result) => {
			  if (result.isConfirmed) {
			  	
		  		// show alert
				var datavar = {
			        action: 'b2bkingduplicatefield',
			        security: b2bking.security,
			        fieldid: $(this).parent().parent().attr('id').split('-')[1],
			    };

    			$.post(ajaxurl, datavar, function(response){

    				show_success_toast(b2bking.duplicated_finish);

        	        window.location.reload();

    			});
	    			
			  }
			});
		});

		function save_label_text(element){
			let row = $(element).parent();
			let startingtextfield = row.find('.b2bking_text');
			let edittextinput = row.find('.b2bking_edit_label_input');
			let startingtext = startingtextfield.text();
			let editedtext = edittextinput.val();

			// hide field, show input edit
			startingtextfield.css('display','block');
			edittextinput.css('display','none');

			// copy text from input to starting
			startingtextfield.text(editedtext);

			// hide edit icon, show confirm icon
			$(element).css('display','none');
			row.find('.b2bking_edit_icon_hover_label').css('display','');
			row.find('.b2bking_duplicate_icon_hover_label').css('display','');

			// save and show "saved successfully"
			var datavar = {
		        action: 'b2bkingsavefieldlabel',
		        security: b2bking.security,
		        fieldid: $(element).parent().parent().attr('id').split('-')[1],
		        text: editedtext,
		    };
		   	
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){

					show_success_toast();
				}
			});
		}

		function show_success_toast(text){
			if (text === '' || text === undefined){
				text = b2bking.settings_saved;
			}

			const Toast = Swal.mixin({
			  toast: true,
			  position: 'bottom-end',
			  showConfirmButton: false,
			  timer: 1000,
			  timerProgressBar: false,
			  didOpen: (toast) => {
			    toast.addEventListener('mouseenter', Swal.stopTimer)
			    toast.addEventListener('mouseleave', Swal.resumeTimer)
			  }
			})

			Toast.fire({
			  icon: 'success',
			  title: text
			});
		}

		// Toolbar actions
		$('body').on('click','.b2bking_toolbar_select.b2bking_select', function(){
			//$('.wp-list-table thead .check-column input').click();
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				$(this).prop('checked', true);
				$(this).change();
			});
			set_button_unselect();
		});
		$('body').on('click','.b2bking_toolbar_select.b2bking_unselect', function(){
			//$('.wp-list-table thead .check-column input').click();
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				$(this).prop('checked', false);
				$(this).change();
			});
			set_button_select();
		});


		$('body').on('change','.wp-list-table thead .check-column input, .wp-list-table tfoot .check-column input', function(){
			if ($(this).is(':checked')){
				set_button_unselect();
			} else {
				set_button_select();
			}
			// force change event on child checkboxes
			$(this).parent().parent().parent().parent().find('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				$(this).change();
			});
		});

		// change row color when checkboxes are activated
		$('body').on('change','.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input', function(){
			if ($(this).is(':checked')){
				$(this).parent().parent().addClass('b2bking_row_selected')
			} else {
				$(this).parent().parent().removeClass('b2bking_row_selected')
			}

			let selectedcount = get_selected_count();
			if (selectedcount > 0) {
				// show X selected message
				$('.b2bking_toolbar_selected_count').removeClass('b2bking_toolbar_selected_inactive');
				// enable action buttons
				$('.b2bking_toolbar_enable_disable').removeClass('b2bking_toolbar_inactive');

				set_button_unselect();
			} else {
				// hide X selected message
				$('.b2bking_toolbar_selected_count').addClass('b2bking_toolbar_selected_inactive');
				// disable action buttons
				$('.b2bking_toolbar_enable_disable').addClass('b2bking_toolbar_inactive');
				set_button_select();
			}
			$('.b2bking_toolbar_selected_count_number').text(selectedcount);


		});

		$('body').on('click','.b2bking_toolbar_enable', function(){
			
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				if ($(this).is(':checked')){
					let status = $(this).parent().parent().find('.b2bking_status .b2bking_switch_input');
					if (!$(status).is(':checked')){
						// add rules in queue 
						if (jQuery('.type-b2bking_rule').length > 0){
							rules_in_queue++; // one less rule in queue
						}

						// check it
						$(status).click();
					}
				} 
			});
			clear_all_checkboxes();

		});
		$('body').on('click','.b2bking_toolbar_disable', function(){
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				if ($(this).is(':checked')){
					let status = $(this).parent().parent().find('.b2bking_status .b2bking_switch_input');
					if ($(status).is(':checked')){
						// add rules in queue 
						if (jQuery('.type-b2bking_rule').length > 0){
							rules_in_queue++; // one less rule in queue
						}
						// check it
						$(status).click();
					}
				} 
			});
			clear_all_checkboxes();
		});
		function clear_all_checkboxes(){
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				$(this).prop('checked', false);
				$(this).change();
			});
			set_button_select();

		}
		function get_selected_count(){
			let selected = 0;
			$('.type-b2bking_rule .check-column input, .type-b2bking_grule .check-column input, .type-b2bking_offer .check-column input, .type-b2bking_custom_role .check-column input, .type-b2bking_custom_field .check-column input, .type-b2bking_quote_field .check-column input').each(function(i){
				if ($(this).is(':checked')){
					selected++;
				} 
			});
			return selected;
		}
		function set_button_unselect(){
			$('.b2bking_toolbar_select .b2bking_toolbar_select_text').text(b2bking.unselect);
			$('.b2bking_toolbar_select').removeClass('b2bking_select').addClass('b2bking_unselect');
		}
		function set_button_select(){
			$('.b2bking_toolbar_select .b2bking_toolbar_select_text').text(b2bking.select_all);
			$('.b2bking_toolbar_select').addClass('b2bking_select').removeClass('b2bking_unselect');
		}

		// search bar searches real post
		$('body').on('input','.b2bking_searchbar_input', function(){
			let text = $(this).val();
			$('#post-search-input').val(text);
		});

		// toolbar settings open tab
		$('body').on('click', '#b2bking_toolbar_settings', function(){
			// show settings tab if hidden
			if ($('#b2bking_toolbar_settings_tab').hasClass('b2bking_toolbar_settings_tab_inactive')){
				$('#b2bking_toolbar_settings').addClass('b2bking_toolbar_settings_button_active');
				$('#b2bking_toolbar_settings_tab').removeClass('b2bking_toolbar_settings_tab_inactive');
			} else {
				// hide it if visible
				$('#b2bking_toolbar_settings').removeClass('b2bking_toolbar_settings_button_active');
				$('#b2bking_toolbar_settings_tab').addClass('b2bking_toolbar_settings_tab_inactive');
			}
			
		});
		// hide toolbar settings on click outside
		$(document).on('click', function(e) {
			if( e.target.id != 'b2bking_toolbar_settings_tab' && e.target.id != 'b2bking_toolbar_settings') {
				$("#b2bking_toolbar_settings_tab").addClass('b2bking_toolbar_settings_tab_inactive');
				$('#b2bking_toolbar_settings').removeClass('b2bking_toolbar_settings_button_active');
			}
		});
		// on click on number of posts per page
		$('body').on('click', '.b2bking_show_per_page_number', function(){
			let value = parseInt($(this).text());
			// save and show "saved successfully"
			var datavar = {
		        action: 'b2bking_save_posts_per_page',
		        security: b2bking.security,
		        value: value,
		    };
		   	
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){
					window.location.reload();
				}
			});
		});
		// clear search button 
		$('body').on('click', '.b2bking_post_searchbar_clear', function(){
			$('#post-search-input').val('');
			$('#search-submit').click();
		});

		// refresh dashboard data
		$('body').on('click', '#b2bking_refresh_data_container', function(){
			var datavar = {
		        action: 'b2bking_refresh_dashboard_data',
		        security: b2bking.security,
		    };
		   	
			$.post(ajaxurl, datavar, function(response){
				if (response === 'success'){
					window.location.reload();
				}
			});
		});

		// backend pricing save customer when searching in backend orders
		$('#customer_user.wc-customer-search').on('change', function(){
			let customer = $(this).val();
			var datavar = {
	            action: 'b2bkingsaveordercustomer',
	            security: b2bking.security,
	            customer: customer
	        };
			$.post(ajaxurl, datavar, function(response){
				console.log('customer '+customer);
				console.log('success');
			});
		});
		// on document load, also get and set the current customer (useful for editing existing orders)
		var customeruser = jQuery('#customer_user.wc-customer-search').val();
		if (customeruser !== undefined){
			var datavar = {
	            action: 'b2bkingsaveordercustomer',
	            security: b2bking.security,
	            customer: customeruser
	        };
			$.post(ajaxurl, datavar, function(response){
				
			});
		}
		
		// Initialize user selector with AJAX search
		if ($('#b2bking_user_selector').length) {
			// Hide the old "User ID(s) (comma-separated):" label and input
			$('#b2bking_rule_select_who_replaced_container .b2bking_rule_label:first-child').hide();
			$('#b2bking_rule_select_who_replaced').hide();
			
			$('#b2bking_user_selector').select2({
				ajax: {
					url: ajaxurl,
					dataType: 'json',
					delay: 300,
					data: function (params) {
						return {
							action: 'b2bking_admin_user_search',
							security: b2bking.security,
							search: params.term
						};
					},
					processResults: function (data) {
						if (data.success) {
							return {
								results: data.data
							};
						}
						return { results: [] };
					},
					cache: true
				},
				minimumInputLength: 3,
				placeholder: 'Search for users...',
				allowClear: true,
				width: '100%'
			});

			// Update hidden input when selection changes
			$('#b2bking_user_selector').on('change', function() {
				var selectedIds = $(this).val();
				if (selectedIds && selectedIds.length > 0) {
					$('#b2bking_rule_select_who_replaced').val(selectedIds.join(','));
				} else {
					$('#b2bking_rule_select_who_replaced').val('');
				}
			});
		}
		
		// Initialize content selector with AJAX search (ajax backend rule search cs)
		if ($('#b2bking_content_selector').length) {
			// Hide the old content input initially
			$('#b2bking_rule_select_applies_replaced').hide();
			
			// Hide the old label text initially
			$('.b2bking_product_variation_ids_title').hide();
			
			// Add toggle button for switching between search selector and text input
			var $rulesContainer = $('#b2bking_rule_select_applies_replaced_container');
			var $toggleButton = $('<button type="button" class="b2bking-toggle-input b2bking-rules-toggle" title="'+b2bking.switch_to_text+'" style="position: absolute; right: 6px; top: 2px; background: none; border: none; color: #666; font-size: 12px; cursor: pointer; z-index: 10; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M18 10L21 7M21 7L18 4M21 7H7M6 14L3 17M3 17L6 20M3 17H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg></button>');
			$rulesContainer.css('position', 'relative').prepend($toggleButton);
			
			// Toggle functionality for rules
			var isTextMode = false;
			$toggleButton.on('click', function(e) {
				e.preventDefault();
				e.stopPropagation();
				
				if (isTextMode) {
					// Switch to search selector mode
					$('#b2bking_rule_select_applies_replaced').hide();
					$('.b2bking_text_input_label').hide(); // Hide text input label
					$('#b2bking_content_selector_container').show();
					$('.b2bking_content_search_types').show();
					$('.b2bking_search_selector_label').show(); // Show "Search for products..." label
					$(this).attr('title', b2bking.switch_to_text || 'Switch to text input');
					isTextMode = false;
				} else {
					// Switch to text input mode
					$('#b2bking_content_selector_container').hide();
					$('.b2bking_content_search_types').hide();
					$('.b2bking_search_selector_label').hide(); // Hide "Search for products..." label
					$('#b2bking_rule_select_applies_replaced').show();
					$('.b2bking_text_input_label').show(); // Show text input label
					$(this).attr('title', b2bking.switch_to_search || 'Switch to search selector');
					isTextMode = true;
				}
			});
			
			$('#b2bking_content_selector').select2({
				ajax: {
					url: ajaxurl,
					dataType: 'json',
					delay: 300,
					data: function (params) {
						// Get selected search types
						var searchTypes = [];
						if ($('#search_products').is(':checked')) searchTypes.push('products');
						if ($('#search_categories').is(':checked')) searchTypes.push('categories');
						if ($('#search_tags').is(':checked')) searchTypes.push('tags');
						if ($('#search_brands').is(':checked')) searchTypes.push('brands');
						
						return {
							action: 'b2bking_admin_content_search',
							security: b2bking.security,
							search: params.term,
							types: searchTypes
						};
					},
					processResults: function (data) {
						if (data.success) {
							return {
								results: data.data
							};
						}
						return { results: [] };
					},
					cache: true
				},
				minimumInputLength: 3,
				placeholder: 'Search for products, categories, or tags...',
				allowClear: true,
				width: '100%'
			});

			// Update hidden input when selection changes
			$('#b2bking_content_selector').on('change', function() {
				var selectedIds = $(this).val();
				if (selectedIds && selectedIds.length > 0) {
					$('#b2bking_rule_select_applies_replaced').val(selectedIds.join(','));
				} else {
					$('#b2bking_rule_select_applies_replaced').val('');
				}
			});
			
			// Handle mutual exclusivity between tags and brands
			$('#search_tags, #search_brands').on('change', function() {
				var $this = $(this);
				var $other = $this.attr('id') === 'search_tags' ? $('#search_brands') : $('#search_tags');
				
				if ($this.is(':checked')) {
					// If the other one is checked, we're switching - show warning
					if ($other.is(':checked')) {
						var message = $this.attr('id') === 'search_brands' 
							? 'Switch to Brands? All existing dynamic rules will be converted from Tags to Brands. This change affects your entire workspace.'
							: 'Switch to Tags? All existing dynamic rules will be converted from Brands to Tags. This change affects your entire workspace.';
						
						if (!confirm(message)) {
							$this.prop('checked', false);
							return false;
						}
						
						$other.prop('checked', false);
						$.post(ajaxurl, {
							action: 'b2bking_save_brands_setting',
							security: b2bking.security,
							use_brands: $this.attr('id') === 'search_brands' ? 1 : 0
						});
					} else {
						// Just ensuring the other is off and saving state
						$other.prop('checked', false);
						$.post(ajaxurl, {
							action: 'b2bking_save_brands_setting',
							security: b2bking.security,
							use_brands: $this.attr('id') === 'search_brands' ? 1 : 0
						});
					}
				}
			});
			
			// Refresh search when checkboxes change
			$('.b2bking_content_search_types input[type="checkbox"]').on('change', function() {
				// Trigger a new search if there's a search term
				var searchInput = $('.select2-search__field');
				if (searchInput.length && searchInput.val().length >= 3) {
					$('#b2bking_content_selector').trigger('select2:open');
					searchInput.trigger('input');
				}
			});
		}
		
		// Function to initialize offer product selectors
		function initializeOfferProductSelectors() {
			$('.b2bking_offer_product_selector_modern').each(function() {
				var $selector = $(this);
				var $container = $selector.closest('.b2bking_offer_product_selector_container');
				var $textInput = $container.siblings('.b2bking_offer_item_name');
				var existingValue = $textInput.val();
				
				// Skip if already initialized
				if ($selector.hasClass('select2-hidden-accessible')) {
					return;
				}
				
				// Hide the text input initially
				$textInput.hide();
				
				// Add toggle button for switching between dropdown and text input
				var $inputContainer = $container.closest('.b2bking_offer_input_container');
				var $toggleButton = $('<button type="button" class="b2bking-toggle-input" title="'+b2bking.switch_to_text+'" style="position: absolute; left: 210px; top: 9px; transform: translateY(-50%); background: none; border: none; color: #666; font-size: 12px; cursor: pointer; z-index: 10; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M18 10L21 7M21 7L18 4M21 7H7M6 14L3 17M3 17L6 20M3 17H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg></button>');
				$inputContainer.append($toggleButton);
				
				// Toggle functionality
				var isTextMode = false;
				$toggleButton.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					
					if (isTextMode) {
						// Switch to dropdown mode
						$textInput.hide();
						$container.find('.b2bking_offer_product_selector_modern').show();
						$container.find('.select2-container').show();
						isTextMode = false;
					} else {
						// Switch to text mode
						$container.find('.b2bking_offer_product_selector_modern').hide();
						$container.find('.select2-container').hide();
						$textInput.show();
						isTextMode = true;
					}
				});
				
				// Initialize Select2
				$selector.select2({
					ajax: {
						url: ajaxurl,
						dataType: 'json',
						delay: 300,
						data: function (params) {
							return {
								action: 'b2bking_admin_content_search',
								security: b2bking.security,
								search: params.term,
								types: ['products'] // Only search for products in offers
							};
						},
						processResults: function (data) {
							if (data.success) {
								// Add price data to each result
								var results = data.data.map(function(item) {
									return {
										id: item.id,
										text: item.text,
										price: item.price || ''
									};
								});
								return {
									results: results
								};
							}
							return { results: [] };
						},
						cache: true
					},
					minimumInputLength: 3,
					placeholder: b2bking.search_for_products,
					allowClear: true,
					width: '100%',
					maximumSelectionLength: 1 // Only allow one product selection
				});
				
				// Handle when options are selected from AJAX results
				$selector.on('select2:select', function(e) {
					var data = e.params.data;
					if (data.price) {
						// Store price data on the option element
						var $option = $selector.find('option[value="' + data.id + '"]');
						$option.data('price', data.price);
						
						// Populate the price field
						var $priceInput = $selector.closest('.b2bking_offer_line_number').find('.b2bking_offer_item_price');
						$priceInput.val(data.price);
						// set qty to 1
						var $qtyInput = $selector.closest('.b2bking_offer_line_number').find('.b2bking_offer_item_quantity');
						$qtyInput.val(1);
						offerCalculateTotals();
					}
				});
				
				// Update text input when selection changes
				$selector.on('change', function() {
					var selectedIds = $(this).val();
					if (selectedIds && selectedIds.length > 0) {
						$textInput.val(selectedIds[0]); // Take first (and only) selection
						
						// Get the selected option and populate price
						var $selectedOption = $(this).find('option:selected');
						if ($selectedOption.length > 0) {
							var price = $selectedOption.data('price');
							if (price) {
								var $priceInput = $selector.closest('.b2bking_offer_line_number').find('.b2bking_offer_item_price');
								$priceInput.val(price);
							}
						}
						
						// Hide the search input when product is selected
						$selector.next('.select2-container').find('.select2-search--inline').hide();
					} else {
						$textInput.val('');
						
						// Show the search input when selection is cleared
						$selector.next('.select2-container').find('.select2-search--inline').show();
					}
				});
				
				// Pre-populate if text input has a value
				if (existingValue) {
					if (existingValue.startsWith('product_')) {
						// It's a product ID, try to pre-populate the dropdown
						var productId = existingValue.replace('product_', '');

						// Use exact search with the "exact" prefix
						$.post(ajaxurl, {
							action: 'b2bking_admin_content_search',
							security: b2bking.security,
							search: 'exact' + productId, // Use exact search prefix
							types: ['products']
						}, function(response) {
							if (response.success && response.data.length > 0) {
								// Find the exact match for our product ID
								var matchingProduct = null;
								for (var i = 0; i < response.data.length; i++) {
									if (response.data[i].id === existingValue) {
										matchingProduct = response.data[i];
										break;
									}
								}

								if (matchingProduct) {
									var newOption = new Option(matchingProduct.text, matchingProduct.id, true, true);
									// Add price data to the option
									if (matchingProduct.price) {
										// do not set price when preopulating offer, because we already have customer's price at the time of quote request
									//	$(newOption).data('price', matchingProduct.price);
									}
									$selector.append(newOption).trigger('change');

									// Hide the search input for pre-populated products
									$selector.next('.select2-container').find('.select2-search--inline').hide();
								}
							}
						});
					} else {
						// It's custom text, show the text input and hide the dropdown
						$container.find('.b2bking_offer_product_selector_modern').hide();
						$container.find('.select2-container').hide();
						$textInput.show();
						
						// Update toggle button state
						var $toggleButton = $inputContainer.find('.b2bking-toggle-input');
						if ($toggleButton.length) {
							$toggleButton.attr('title', b2bking.switch_to_text);
						}
					}
				}
			});
		}
		
		// Re-initialize selectors when new rows are added (for duplication)
		$(document).on('DOMNodeInserted', function(e) {
			if ($(e.target).hasClass('b2bking_offer_line_number') || 
				$(e.target).find('.b2bking_offer_line_number').length > 0) {
				setTimeout(function() {
					initializeOfferProductSelectors();
				}, 100);
			}
		});

		// Group price collapse show/hide toggles
		$(document).on('click', '.b2bking-group-header, .b2bking-group-toggle', function(e) {
		    e.stopPropagation();
		    var $container = $(this).closest('.b2bking-group-pricing-container');
		    $container.toggleClass('collapsed').find('.b2bking-group-content').slideToggle(300);
		    localStorage.setItem('b2bking_group_' + $container.data('group-id'), $container.hasClass('collapsed') ? 'collapsed' : 'expanded');
		});

		// Expand / Collapse all groups within the nearest scope
		function b2bkingGetScope($el) {
		    return $el.closest('.b2bking-groups-toolbar-variation').length
		        ? $el.closest('.woocommerce_variation')
		        : $el.closest('.options_group');
		}
		$(document).on('click', '.b2bking-expand-all', function(e) {
		    e.preventDefault();
		    var $containers = b2bkingGetScope($(this)).find('.b2bking-group-pricing-container');
		    $containers.removeClass('collapsed').find('.b2bking-group-content').show();
		});
		$(document).on('click', '.b2bking-collapse-all', function(e) {
		    e.preventDefault();
		    var $containers = b2bkingGetScope($(this)).find('.b2bking-group-pricing-container');
		    $containers.addClass('collapsed').find('.b2bking-group-content').hide();
		});

		// Restore saved states on load AND after WooCommerce loads variation panels
		function b2bkingRestoreGroupStates() {
		    $('.b2bking-group-pricing-container').each(function() {
		        if (localStorage.getItem('b2bking_group_' + $(this).data('group-id')) === 'collapsed') {
		            $(this).addClass('collapsed').find('.b2bking-group-content').hide();
		        }
		    });
		}

		b2bkingRestoreGroupStates();
		$(document).on('woocommerce_variations_loaded', b2bkingRestoreGroupStates);






	});

})(jQuery);