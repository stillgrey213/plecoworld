=== Video Gallery for WooCommerce - Add Product Video & Featured Video ===
Contributors: nitramix, martinvalchev
Donate link: https://nitramix.com/donate/
Tags: video gallery, featured video, product video, woocommerce, product gallery
Requires at least: 5.3
Tested up to: 6.9.4
Requires PHP: 7.4
Stable tag: 2.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Video Gallery for WooCommerce - add product video & featured video to the WooCommerce product gallery. Customize, boost sales. WooCommerce required.

== Description ==

**Video Gallery for WooCommerce** is a simple video gallery plugin for WooCommerce stores. It lets you add a product video or featured video to any WooCommerce product gallery in seconds. No code, no shortcodes, no theme edits.

Pick any clip from the WordPress media library. The video shows up right next to your product images, inside the WooCommerce product gallery. Set autoplay, sound, and loop. Show or hide the video controls. WooCommerce must be active for the plugin to work.

Upgrade your product pages today with Video Gallery for WooCommerce!

**🚀 Looking for more features?** Check out our PRO version with YouTube integration, unlimited videos, custom SVG icons, SEO optimization, video analytics, and priority support!

= Product Video Gallery Features =

Turn every WooCommerce product gallery into a product video gallery. Add an MP4 or MOV product video from the WordPress media library. Drag and drop to reorder your clips. Shoppers see the item in motion, right next to the product images.

= Featured Video for WooCommerce Products =

Use any uploaded clip as a featured video for your WooCommerce products. The featured video plays inside the product gallery through the built-in VideoJS player. It works smoothly on desktop and mobile. You control autoplay, mute, and loop for each product.

= WooCommerce Product Gallery Integration =

Video Gallery for WooCommerce plugs into the native WooCommerce product gallery. It also supports the new WooCommerce Product Gallery Block. No gallery rebuild. No shortcodes. Install the plugin, add a product video, and you are live.

= Key Features =

*   Add video files from the WP library to your product pages
*   Move videos around on the product page to your desired position
*   Customize the video file icon and color
*   Choose autoplay, sound, and loop options for video clips
*   Show or hide video control options for a more personalized playback experience
*   Enhance user engagement on your product pages with visually engaging video content
*   Customize your video gallery to match your brand's aesthetic
*   Manage your media library with ease
*   Increase conversions by showcasing your products with multimedia content
*   Compatible with WooCommerce for seamless integration with your online store

**FREE Version Limitations:**
*   Limited to 20 products with video
*   Limited to 2 videos per product
*   WordPress Media Library videos only (no YouTube support)
*   Basic video icons only
*   Basic thumbnail generation
*   Basic SEO video
*   No analytics

**🚀 Upgrade to PRO Version:**
Get access to advanced features including up to 6 videos per product, YouTube integration, custom SVG icons, optimized thumbnails, SEO settings, video analytics, and premium support!

**PRO Version Features:**
*   **Unlimited products with video**
*   **Up to 6 videos per product** - Showcase products from multiple angles
*   **YouTube video integration** - Embed videos directly from YouTube
*   **Custom SVG icons** - Use your own brand icons
*   **Optimized thumbnails** - Automatic thumbnail generation
*   **SEO settings** - Custom titles and descriptions per video
*   **Video Analytics (Basic)** - Track video views and watch time per product *(Single Site plan)*
*   **Video Analytics (Advanced)** - Device charts, engagement metrics, location analytics, browser/OS tracking, heatmap visualization, and CSV export *(Multiple & Unlimited plans, or Advanced Analytics Add-on)*
*   **Premium support** - Priority email support

**[Purchase PRO Version](https://nitramix.com/projects/video-gallery-for-woocommerce/)**

The helper libraries plugin uses the following:

*   [FontAwesome v6.6.0](https://fontawesome.com/)
*   [SweetAlert2 v11.4.8](https://sweetalert2.github.io/)
*   [VideoJS v7.15.4](https://videojs.com/)

= Requirements =

*   WooCommerce must be installed and activated. Install it first if you do not have it.
*   Video files must be in a WordPress-supported format. MP4 and MOV work best.
*   The plugin works with the default WooCommerce templates. We add extra support for known themes. If your theme breaks, contact support and we will check if we can make it compatible.

== Installation ==

To install this plugin:

1. Install the plugin through the WordPress admin interface, or upload the plugin folder to /wp-content/plugins/ using ftp.
2. Activate the plugin through the 'Plugins' screen in WordPress. On a Multisite you can either network activate it or let users activate it individually.
3. Go to the "Video Gallery" admin menu in your WordPress dashboard

How to add a video to a product

1. Go to Products in WooCommerce.
2. Click Edit on the product you want to add a video to.
3. Scroll down to the Product Data section.
4. Open the tab "Video Gallery for WooCommerce".
5. You will see the option to add a video from your media library.
6. After adding a video, make sure to click Update to save the changes.



== Frequently Asked Questions ==

= What is Video Gallery for WooCommerce? =
Video Gallery for WooCommerce is a plugin that allows you to add video files from your WordPress (WP) library to your product pages on your website. It comes with a range of customization options to enhance your video display and improve user engagement.

= How do I add a product video to a WooCommerce product? =
Open the product in WooCommerce. Go to the "Video Gallery for WooCommerce" tab in the Product Data box. Pick a video from the WP media library and click Update. The product video shows up inside the WooCommerce product gallery on the front end. No shortcodes, no theme edits.

= Does the plugin work with the native WooCommerce product gallery? =
Yes. Video Gallery for WooCommerce works with the default WooCommerce product gallery. It also supports the new WooCommerce Product Gallery Block. Your product video sits next to your product images, without breaking your theme's layout.

= What types of video files can I use with Video Gallery for WooCommerce? =
You can use any video format supported by WordPress. The most common ones are MP4 and MOV.

= Can I customize the display of my video files? =
Yes. You can change the video icon and color. You can also move each video to any position on the product page.

= Can I control how my video clips play? =
Yes. Each clip has its own settings for autoplay, sound, and loop. You can also show or hide the video controls.

= Is Video Gallery for WooCommerce compatible with other WordPress themes and plugins? =
Yes. Video Gallery for WooCommerce works with most WordPress themes and plugins. Some themes may need small tweaks. The plugin is built to integrate smoothly with WooCommerce.

= Can I set a featured video for each product? =
Yes. Any uploaded clip can be used as a featured video for a WooCommerce product. The featured video loads inside the product gallery. It plays through the built-in VideoJS player, with full control over autoplay, mute, and loop.

= Is there a PRO version with more features? =
Yes. The PRO version unlocks unlimited products with video and up to 6 videos per product. It also adds YouTube integration, custom SVG icons, optimized thumbnails, SEO settings, and video analytics. PRO users get priority support. Visit [Video Gallery for WooCommerce PRO](https://nitramix.com/projects/video-gallery-for-woocommerce/) to learn more.

= What's the difference between FREE and PRO versions? =
The FREE version is limited to 20 products with video and 2 videos per product. The PRO version is unlimited. PRO also adds YouTube support, custom icons, advanced SEO, video analytics, and premium support.

= What is Video Analytics and how does it work? =
The PRO version includes a Video Analytics dashboard. It tracks how visitors interact with your product videos. Enable it from Video Gallery > Settings. All PRO plans include basic analytics (views and watch time). Advanced analytics (device charts, engagement, location data, heatmaps, CSV export) are part of the Multiple Sites and Unlimited Sites plans. Single Site holders can unlock them with the one-time Advanced Analytics Add-on.

= Can I get advanced analytics on a Single Site license? =
Yes. Buy the Advanced Analytics Add-on as a one-time payment from the Video Analytics dashboard. It unlocks device charts, engagement metrics, location analytics, heatmaps, and CSV export. No need to upgrade your full license.

== Videos ==

Watch Video Gallery for WooCommerce in action and see how to add a product video to your WooCommerce product gallery:

[youtube https://youtu.be/9PNbRUShcRs]

== Screenshots ==

1. Settings
2. Product settings
3. All Products
4. Product pages
5. PRO - Embed videos directly from YouTube
6. PRO - Video Analytics dashboard 1
7. PRO - Video Analytics dashboard 2
8. PRO - Video Analytics dashboard 3
9. PRO - Video Analytics dashboard 4
10. PRO - Video SEO settings
11. PRO - Thumbnails optimization settings
12. PRO - Custom SVG icon

== Changelog ==

= 2.6 =
* **Fix:** Video playback stopping on desktop when mouse is idle or hovering over the video in Flatsome theme
* **Added:** Added basic support for Astra theme
* Tested with WordPress 6.9.4
**Release date: April 21, 2026**

= 2.5 =
* **Added:** Product Gallery Block Support
* **Improvement:** By visualization and code
* Tested with WordPress 6.9.1
**Release date: February 27, 2026**

= 2.4 =
* **Improvement:** By visualization and code
**Release date: January 5, 2026**

= 2.3 =
* **Fix:** Function to pause a video if we move to another slide in the gallery - optimized
**Release date: December 18, 2025**

= 2.2 =
* **Added:** Added basic support for Blocksy theme
**Release date: December 12, 2025**

= 2.1 =
* **Added:** Function to pause a video if we move to another slide in the gallery 
* **Added:** Product list column indicator for videos
* **Added:** Show counter above products table for products with video
* **Added:** Delete videos from product by ID
* **Added:** Products with video 20 limit
* **Improvement:** Code cleanup and improvements
**Release date: December 10, 2025**

= 2.0 =
* **Added:** Admin menu and redesign 
* **Fix:** When the browser is Safari and the settings are to repeat the video and the controls are disabled
* **Fix:** crossorigin errors
* **Improvement:** Redesign admin products Video Gallery tab
* **Improvement:** Code cleanup and improvements
* Tested with WordPress 6.9
**Release date: December 3, 2025**

= 1.41 =
* **Updated:** Outdated templates
**Release date: June 30, 2025**

= 1.40 =
* **Fixed:** Bugs fixes
**Release date: May 27, 2025**

= 1.39 =
* **Improved:** Optimized handling of variable products with images
* **Fixed:** Issues with FlexSlider when displaying video in the first slide
* **Optimized:** Reworked functionality when changing variations that correctly preserves video attributes
**Release date: May 24, 2025**

= 1.38 =
 * **Improved:** Enhanced CSS styling for video thumbnails to ensure consistent sizing for Flatsome theme
 * **Fixed:** Vertical gallery layout for Flatsome theme
 * **Added:** Better support for video thumbnails in product galleries for Flatsome theme
 * **Improved:** Code optimization for better performance
 **Release date: March 12, 2025**

= 1.37 =
 * **Fix:** Fatal error when product object is not properly initialized by page builders or themes
 * **Added:** Validation checks for product object to ensure compatibility with various page builders
 **Release date: March 10, 2025**

= 1.36 =
* **Fix:** Issue with Default Form Values in variable products
* **Added:** Better support for Flatsome theme for variable products
* **Improved:** Code optimization and improvements
**Release date: February 17, 2025**

= 1.35 =
* **Added:** Explanatory information for two settings: "Show video first" and "Adjust video size"
* **Updated:** WooCommerce template files to ensure compatibility
* Tested with WordPress 6.7.2
**Release date: February 12, 2025**

= 1.34 =
* **Added:** New donate link
* **Removed:** Unused file from FontAwesome v6.6.0
* Tested with WordPress 6.7
**Release date: November 19, 2024**

= 1.33 =
* **Fix:** Issue with "srcset" attribute
**Release date: November 8, 2024**

= 1.32 =
* **Fix:** Security issue
* **Update:** FontAwesome v5 to FontAwesome v6.6.0
**Release date: November 5, 2024**

= 1.31 =
* **Fix:** Fatal Error with admin notices
* Tested with WordPress 6.6.1
**Release date: July 26, 2024**

= 1.30 =
* **Added:** Admin menu for Video Gallery for WooCommerce
* **Added:** Required plugins the new option of WordPress 6.5
* Tested with WordPress 6.5
**Release date: April 3, 2024**

= 1.29 =
* Fix: If have problem with first loading classes

= 1.28 =
* Fix: Small Bugs
* Added: VideoObject schema all required properties

= 1.27 =
* Fix: When use option show first - and product is variable with set default variable value
* Added: VideoObject schema add "uploadDate"

= 1.26 =
* Fix: When use option show first - fix issue with variable product with image (basic support for Flatsome theme)

= 1.25 =
* Fix: When use option show first - fix issue with variable product with image

= 1.24 =
* Added: New function in settings "Adjust the video size according to the theme settings"
* Fix: Security fixes

= 1.23 =
* Fix: Visual fix

= 1.22 =
* Added: VideoObject schema for better SEO
* Fix: Video container on product page

= 1.21 =
* Fix: Height inheritance script

= 1.20 =
* Added: Image resizer for video thumbnails. Resize to sizes WooCommerce: "woocommerce_gallery_thumbnail_url" and "woocommerce_thumbnail"
* Added: In the function for deleting unused thumbnails - add delete additional generated sizes
* Added: Confirmation popup when deleting unused thumbnails
* Fix: Uniformity of video thumbnails (this fixes design issues for different themes)
* Tested: New functionality for Flatsome theme

= 1.19 =
* Fix: If the initialize event of all galleries on the page is missing

= 1.18 =
* Added basic support for Flatsome theme
* Stop function for Feedback when deactivate plugin

= 1.17 =
* Fixed: Clicking on the video icon for mobile devices

= 1.16 =
* Optimization of video preload
* Optimization of video events for Safari browser

= 1.15 =
* Fix: PhotoSwipe option if theme not support product gallery zoom

= 1.14 =
* Added new setting to show videos first
* Fix: Images and Videos click event
* Security fixes

= 1.13 =
* Fix: Autoplay function for Safari browser
* Added Function if mute is off automatically turn off auto play
* Fix: When have video element disabled click event to prevent open in popup

= 1.12 =
* Fix video loading for Safari browser
* Fix problematic loading of hidden items
* Changed the way of visualizing video in the front page of the product, it is now visualized with VideoJS, which will improve the user experience
* Stop support AVI video formats

= 1.11 =
* Fix: Multiple generated sections from WP Bakery with gallery elements

= 1.10 =
* Fix: Many elements coming from using different page builders - optimized loop

= 1.9 =
* Fix: Many elements coming from using different page builders

= 1.8 =
* Fix: If not use default uploads folder

= 1.7 =
* Optimization function add icons on product page

= 1.6 =
* Changed version SweetAlert2 to v11.4.8

= 1.5 =
* Return function check if theme contains any mediaelement-migrate-js and deregister script. Prevent broke design and conflict with some plugins
* Changed version SweetAlert to v11.7.10

= 1.4 =
* Fixed generate thumbnails
* Fixed edit product with Beaver Builder – WordPress Page Builder
* Remove check if theme contains any mediaelementJS import

= 1.3 =
* Change thumbnails not use e base64-encoded image, thumbnails saved in uploads folder
* Added a function in the settings that finds generated thumbnails that are not used and can be deleted so they don't take up space

= 1.2 =
* Added check if your theme contains any mediaelementJS import will be disabled to prevent conflicts and use default library which is in WordPress core
* Fixes in product page if style is vertical media gallery

= 1.1 =
* Visual fixes.
* Feedback fix.

= 1.0 =
* First release of the plugin.

== Upgrade Notice ==

= 2.0 =
* Added an admin menu with a full redesign, fixed Safari playback issues when repeat is enabled and controls are disabled, resolved crossorigin errors, improved the Video Gallery tab design, cleaned up the code, and confirmed compatibility with WordPress 6.9.

= 1.20 =
* To generate new thumbnail sizes you will need to in the product edit delete the video and add it again add the video to generate new thumbnails and save

= 1.14 =
* Added new setting to show videos first
* Fix: Images and Videos click event
* Security fixes

= 1.13 =
* Fix: Autoplay function for Safari browser
* Added Function if mute is off automatically turn off auto play
* Fix: When have video element disabled click event to prevent open in popup

= 1.12 =
* Fix video loading for Safari browser
* Fix problematic loading of hidden items
* Changed the way of visualizing video in the front page of the product, it is now visualized with VideoJS, which will improve the user experience
* Stop support AVI video formats

= 1.3 =
* Change thumbnails not use e base64-encoded image, thumbnails saved in uploads folder
* Added a function in the settings that finds generated thumbnails that are not used and can be deleted so they don't take up space

= 1.0 =
* First release of the plugin.

