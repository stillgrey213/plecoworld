<?php
/**
 * Modern Cart Pro Uninstall
 *
 * Cleans up Pro-specific options, analytics flags, and transients
 * when the Pro plugin is deleted via the WordPress admin.
 *
 * Free plugin options are NOT removed here — they are handled
 * by the free plugin's own uninstall.php.
 *
 * @package ModernCart_Pro
 * @since 1.2.7
 */

// Exit if not called by WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Only delete data if the user has opted in via the free plugin's settings toggle.
$moderncart_settings = get_option( 'moderncart_setting', array() );
if ( empty( $moderncart_settings['delete_data_on_uninstall'] ) ) {
	return;
}

// Pro version tracking.
delete_option( 'moderncart_pro_version' );
delete_option( 'mcw_pro_tracked_version' );

// Pro analytics event flags.
delete_option( 'mcw_first_popup_cart_configured' );
delete_option( 'mcw_first_recommendations_configured' );
delete_option( 'mcw_first_recommendations_type' );
delete_option( 'mcw_first_empty_cart_rec_configured' );
delete_option( 'mcw_first_empty_cart_rec_type' );
delete_option( 'mcw_first_custom_icon_configured' );
delete_option( 'mcw_first_header_style_configured' );
delete_option( 'mcw_first_header_style_type' );
delete_option( 'mcw_first_order_summary_style_configured' );
delete_option( 'mcw_first_order_summary_style_type' );
delete_option( 'mcw_first_auto_open_configured' );
delete_option( 'mcw_first_auto_open_type' );

// Pro analytics transient.
delete_transient( 'mcw_pro_state_events_checked' );

// NPS survey data.
delete_option( 'nps-survey-modern-cart-for-woocommerce' );

// License data (WC API Manager).
$product_id = '121256';
delete_option( 'wc_am_client_' . $product_id . '_activated' );
delete_option( 'wc_am_client_' . $product_id . '_deactivate_checkbox' );
delete_option( 'wc_am_client_' . $product_id . '_instance' );
