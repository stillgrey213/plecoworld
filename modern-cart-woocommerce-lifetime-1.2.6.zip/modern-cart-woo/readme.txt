=== Modern Cart for WooCommerce ===
Contributors: brainstormforce
Tags: woocommerce cart, woocommerce checkout, woocommerce coupon, product
Requires at least: 5.4
Tested up to: 6.8
Stable tag: 1.2.6
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Modern Cart for WooCommerce is the easiest to use WooCommerce cart with best Experience.

== Description ==

**Modern Cart for WooCommerce that helps every shop owner improve their user experience, increase conversions & maximize profits.**

This plugin allows you to show an elegant slide out cart each time a new product is added to the cart.

Here are some of our products:

* **Astra Theme**
Currently used by nearly 2 million websites, Astra Theme is the most popular WordPress theme and is also the most popular WooCommerce theme. Modern Cart for WooCommerce was made to work perfectly with Astra Theme. [Visit Astra Theme](https://wpastra.com)

* **CartFlows**
Currently used by nearly 300,000 store owners to get more orders and increase the order value through our conversion optimized checkout replacement for WooCommerce, checkout order bumps, one-click post purchase upsells, and A/B split testing engine. [Visit CartFlows](https://cartflows.com)

* **Cart Abandonment Recovery**
Currently used by nearly 400,000 store owners to capture lost revenue caused by buyers that don’t complete their checkout. Cart Abandonment Recovery captures these lost orders and automatically contacts the lost buyers to get them to complete their order. [Visit Cart Abandonment Recovery](https://wordpress.org/plugins/woo-cart-abandonment-recovery/)

* **Stripe for WooCommerce**
Stripe for WooCommerce delivers a simple, secure way to accept credit card payments, Apple Pay, and Google Pay on your WooCommerce store. Reduce payment friction and boost conversions using this free plugin! [Visit Stripe for WooCommerce](https://wordpress.org/plugins/checkout-plugins-stripe-woo/)

* **Starter Templates**
Currently used by nearly 2 million websites, Starter Templates offers hundreds of complete website templates, including over 50 website designs for WooCommerce stores. [Visit Starter Templates](https://wordpress.org/plugins/astra-sites/)

As you can see, we know WooCommerce inside and out and help thousands of store owners build highly profitable stores everyday.


== Global Features: ==
1. Slide out open after product add to cart
2. Easy to manage cart items
3. Single screen able to see upsells and cross sells product
4. Powerfull coupon form
6. Compatible with most plugins and themes
7. Compatible with checckout plugin express checkout button
8. Plenty of features for developers

**You can customize**

- Buttons
- Background colors
- Text localizations
- ... and much more

-----

### Slide Out, Popup and Floating Cart Icon

Slide out or pupup open after any product add to cart. Add a floating cart icon to your page that allows customers to access their cart quickly. You can even hide it until something is added to the cart.

-----

### Powerful Coupon Form

A cart isn’t complete without the ability to use coupons. Customers can easily add and remove (multiple) coupons using the AJAX coupon form. The coupon form is also compatible with most WooCommerce coupon plugins.

-----

### Product Recommendation Engine

Squeeze more revenue out of your customers by recommending products directly in the popup. Choose from upsells and cross-sells. Or, if you have a license, you can select custom products.


== Installation ==

1. Install the `Modern Cart for WooCommerce` either via the WordPress plugin directory or by uploading `modern-cart-woo.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make sure to disable caching on your checkout and thank you steps

== Frequently Asked Questions ==
= How can I report a security bug? =

We take plugin security extremely seriously. If you discover a security vulnerability, please report it in a safe and responsible manner.

You can report the issue through our [Bug Bounty Program](https://brainstormforce.com/bug-bounty-program/).

== Upgrade Notice ==

== Screenshots ==

== Changelog ==

= Version 1.2.6 - Friday, 17th April 2026 =
* New: Added an option to delete plugin data on uninstall.
* Improvement: Improved overall plugin stability and performance.

= Version 1.2.5 - Monday, 23rd March 2026 =
* Fix: Improved the plugin activation process for better reliability and control.

= Version 1.2.4 - Tuesday, 13th January 2026 =
* Fix: Fixed an issue with the order summary style functionality in the Slide Out component.

= Version 1.2.3 - Monday, 24th November 2025 =
* Fix: Fixed a compatibility issue between Free and Pro settings by enabling dynamic toggling of options based on configuration settings.

= Version 1.2.2 - Thursday, 20th November 2025 =
* New: Added a new feature to display the cart on selected pages, giving more control over the cart and improving customization options. 
* New: Added an option to choose between displaying total product quantities or unique item counts in the Modern Cart, providing more flexibility in cart display preferences.

= Version 1.2.1 - Monday, 29th September 2025 =
* Fix: Fixed issue with tax HTML renderer not displaying correctly in the cart.
* Fix: Fixed a critical error that could occur when running in legacy mode.

= Version 1.2.0 - Monday, 15th September 2025 =
* Improvement: Added compatibility support for Modern Cart Starter For WooCommerce with legacy versions of Modern Cart (v1.1.0 and earlier).
* Fix: Fixed issue where WooCommerce Product Add-On prices were not displaying in the Modern Cart mini cart.

= Version 1.1.0 - Monday, 11th August 2025 =
* New: Introduced a popup cart display option alongside the existing slideout cart, providing greater flexibility in how the cart is shown.
* New: Introduced floating cart icon styling options with live preview — customize icon color, background color, text color, count badge, size, and border radius.
* New: Added an option "Cart Opening Direction" to configure the slide-in direction of the cart for enhanced layout flexibility.
* New: Added a “Recommendation List Style” option to customize how product recommendations are displayed.
* New: Added a “Show Product Image in Mobile View” option to show or hide product images in the mobile cart view.
* Improvement: Added customization options for cart item images and padding, giving users more control over the visual layout of cart items.
* Improvement: Moved product recommendation settings to a new “Products” tab for better organization and easier access.
* Fix: Fixed an issue where the floating cart icon was not hiding when the cart was empty.
* Fix: Fixed an issue where personalization fields were not being passed to the cart.
* Fix: Fixed a layout shift on mobile where product images would reappear when increasing item quantity in the cart.

= Version 1.0.7 - Wednesday, 10th July 2025 =
* New: Added a configuration option "Cart Auto-Open Behavior" to control cart behavior after adding items, allowing for a more tailored user experience.
* New: Introduced the ability to upload a custom icon for the floating cart button, improving alignment with your site's branding.
* New: Added support for setting custom product recommendations, offering more flexibility to highlight specific or related product strategies.
* New: Added a “Use Custom Trigger” setting to support opening the cart via custom buttons or elements on the site.
* Fix: Fixed an issue with product bundles where incorrect product IDs or quantities were applied, particularly for variable products.

= Version 1.0.6 - Wednesday, 11th June 2025 =
* New: Introduced color customization options for the header and quantity badge to enhance visual flexibility.
* New: Added new layout styles for cart slider items, offering improved design customization and user experience.
* Fix: Compatibility with WooCommerce Product Bundles: product ID is now correctly retrieved when it was previously unset.
* Fix: Compatibility with YITH Extra Product Options: improved cart-form data handling so complex add-ons are processed correctly during “Add to Cart”.

= Version 1.0.5 - Tuesday, 27th May 2025 =
* Fix: Fixed spinner not stopping on second "Add to Cart" click with Kadence Shop Kit.
* Fix: Resolved inconsistent cart button padding caused by page editor overrides.

= Version 1.0.4 - Monday, 19th May 2025 =
* Fix: Astra theme cart compatibility on mobile devices.
* Fix: Resolved issue where subscription data was not being added to the cart.
* Fix: Issue preventing variable subscription products from being added to the cart.

= Version 1.0.3 - Tuesday, 13th May 2025 =
* New: Added product recommendations display when the cart is empty, encouraging continued shopping and potentially boosting sales.
* New: Introduced new styles for the order summary section enhancing design flexibility.
* New: Added more cart icon options for improved customization.
* New: Added a knowledge base section in the Modern Cart dashboard for easier user guidance.
* Fix: Fixed issue where hidden products were shown in the product recommendations section of the fold-out cart.
* Fix: Resolved an issue with removing products from the cart when using the Astra theme.

= Version 1.0.2 - Monday, 28th April 2025 =
* Improvement: Added a new color picker with Astra theme's Global Color Palette compatibility.
* Improvement: Added support for Astra's global color palette when no styling is set from the Modern Cart settings.
* Improvement: Displayed product count in the cart header for Cart Style 1.
* Improvement: Renamed 'General Settings' to 'General', and 'Label Settings' to 'Text Label' for better clarity.
* Improvement: Enhanced keyboard navigation within the slide-out cart for a smoother user experience.
* Fix: Fixed an issue where the View Details section was not functioning in Cart Style 2.
* Fix: Resolved a fatal error caused by a missing Astra Notice class.
* Fix: Issue with sidebar not opening automatically with divi theme

= Version 1.0.1 - Friday, 18th April 2025 =
* Fix: Resolved HPOS (High-Performance Order Storage) compatibility notice.
* Fix: Fixed issue where adding or removing products from the Modern Cart didn’t update the default WooCommerce Cart without a page reload.
* Fix: Addressed cart duplication bug when viewing the cart in the WordPress Customizer widget preview.
* Fix: Corrected display issue with the sale banner not appearing properly in the cart.

= Version 1.0.0 - Tuesday, 15th April 2025 =
* Initial release.
