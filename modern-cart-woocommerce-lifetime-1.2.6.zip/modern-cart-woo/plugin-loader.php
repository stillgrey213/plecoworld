<?php
/**
 * Plugin Loader.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro;

use ModernCart\Inc\Helper;
use ModernCart_Pro\Admin_Core\Admin_Menu;
use ModernCart_Pro\Admin_Core\Inc\Settings_Fields;
use ModernCart_Pro\Inc\Floating;
use ModernCart_Pro\Inc\Floating_Ajax;
use ModernCart_Pro\Inc\Scripts;
use ModernCart_Pro\Inc\Slide_Out;
use ModernCart_Pro\Inc\Slide_Out_Ajax;

/**
 * Plugin_Loader
 *
 * @since 1.0.0
 */
class Plugin_Loader {
	/**
	 * Instance
	 *
	 * @access private
	 * @var object Class Instance.
	 * @since 1.0.0
	 */
	private static $instance;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		if ( MODERNCART_PRO_LEGACY_MODE ) {
			add_action(
				'admin_notices',
				function() {
					?>
				<div class="notice notice-warning is-dismissible">
					<p>
						<strong><?php esc_html_e( 'Modern Cart for WooCommerce: Action Needed', 'modern-cart-woo' ); ?></strong><br>
						<?php
						printf(
							/* translators: 1: <strong> tag, 2: </strong> tag, 3: <a> tag, 4: </a> tag. */
							esc_html__( 'Your site is running %1$sModern Cart in legacy mode%2$s, which will be removed in future updates. To keep everything working smoothly, please install the free %3$sModern Cart plugin%4$s from the WordPress repository.', 'modern-cart-woo' ),
							'<strong>',
							'</strong>',
							'<a target="_blank" href="' . esc_url( 'https://wordpress.org/plugins/modern-cart/' ) . '">',
							'</a>'
						);
						?>
					</p>
				</div>
					<?php
				} 
			);
		}

		spl_autoload_register( [ $this, 'autoload' ] );

		add_action( 'init', [ $this, 'save_version_info' ] );
		add_action( 'init', [ $this, 'load_textdomain' ] );
		add_action( 'plugins_loaded', [ $this, 'load_classes' ] );
		add_action( 'plugins_loaded', [ $this, 'maybe_init_bsf_analytics_fallback' ] );
		$this->init_pro_analytics_stats();
		add_filter( 'plugin_action_links_' . MODERNCART_PRO_BASE, [ $this, 'action_links' ] );

		add_filter( 'moderncart_filter_cart_count', [ $this, 'filter_cart_count' ] );
		add_filter( 'moderncart_default_settings', [ $this, 'extend_default_settings' ] );

		add_filter( 'moderncart_override_is_global_enabled', [ $this, 'override_is_global_enabled' ], 12, 2 );
	}

	/**
	 * Override the global enabled state for Modern Cart based on selected pages.
	 *
	 * This method checks if the cart should be enabled only on specific pages as defined
	 * in the plugin settings. If 'selected_pages' is set as the enabled mode, it will
	 * determine if the current page ID is in the list of selected page IDs.
	 *
	 * @since 1.2.0
	 *
	 * @param bool   $maybe_enable The current enabled state determined by previous logic.
	 * @param string $enabled      The enabled mode from settings (e.g., 'all', 'selected_pages').
	 * @return bool  True if the cart should be enabled on the current page, false otherwise.
	 */
	public function override_is_global_enabled( $maybe_enable, $enabled ) {
		if ( 'selected_pages' !== $enabled ) {
			return $maybe_enable;
		}

		$settings = (array) get_option( MODERNCART_SETTINGS, [] );

		$cart_selected_pages = ! empty( $settings['cart_selected_pages'] ) && is_string( $settings['cart_selected_pages'] ) ? array_map( 'absint', explode( ',', $settings['cart_selected_pages'] ) ) : [];

		if ( is_singular() ) {
			// For single posts/products/pages.
			$current_page_id = get_queried_object_id();
		} elseif ( is_post_type_archive( 'product' ) ) {
			// For WooCommerce shop archive.
			$current_page_id = wc_get_page_id( 'shop' );
		} else {
			$current_page_id = null; // Could be category, search, etc.
		}

		if ( is_int( $current_page_id ) && ! empty( $cart_selected_pages ) ) {
			// Check if the current page ID or the shop page ID is in the list of selected cart pages.
			return in_array( $current_page_id, $cart_selected_pages, true );
		}

		return $maybe_enable;
	}

	/**
	 * Saves the current and previous version information of Modern Cart Pro.
	 *
	 * This method checks the stored version information in the 'moderncart_pro_version' option.
	 * If the current version matches the stored version, it does nothing.
	 * Otherwise, it updates the option with the new current version and stores the previous version.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function save_version_info() {
		$version = get_option( 'moderncart_pro_version' );

		if ( is_array( $version ) && isset( $version['current'] ) && MODERNCART_PRO_VER === $version['current'] ) {
			// Already updated.
			return;
		}

		$version = [
			'current'  => MODERNCART_PRO_VER,
			'previous' => ( is_array( $version ) && isset( $version['current'] ) ) ? $version['current'] : '',
		];

		update_option( 'moderncart_pro_version', $version );
	}

	/**
	 * Initiator
	 *
	 * @since 1.0.0
	 * @return object initialized object of class.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Autoload classes.
	 *
	 * @param string $class class name.
	 */
	public function autoload( $class ): void {
		if ( 0 !== strpos( $class, __NAMESPACE__ ) ) {
			return;
		}

		$class_to_load = $class;

		$filename = preg_replace(
			[ '/^' . __NAMESPACE__ . '\\\/', '/([a-z])([A-Z])/', '/_/', '/\\\/' ],
			[ '', '$1-$2', '-', DIRECTORY_SEPARATOR ],
			$class_to_load
		);

		if ( is_string( $filename ) ) {
			$filename = strtolower( $filename );

			$file = MODERNCART_PRO_DIR . $filename . '.php';

			// if the file redable, include it.
			if ( is_readable( $file ) ) {
				require_once $file;
			}
		}
	}

	/**
	 *  Declare the woo HPOS compatibility.
	 *
	 * @since 1.0.1
	 * @return void
	 */
	public function declare_woo_hpos_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', MODERNCART_PRO_FILE, true );
		}
	}


	/**
	 * Load Plugin Text Domain.
	 * This will load the translation textdomain depending on the file priorities.
	 *      1. Global Languages /wp-content/languages/modern-cart-woo/ folder
	 *      2. Local dorectory /wp-content/plugins/modern-cart-woo/languages/ folder
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function load_textdomain(): void {
		// Default languages directory.
		$lang_dir = MODERNCART_PRO_DIR . 'languages/';

		/**
		 * Filters the languages directory path to use for plugin.
		 *
		 * @param string $lang_dir The languages directory path.
		 */
		$lang_dir = apply_filters( 'wpb_languages_directory', $lang_dir );

		// Traditional WordPress plugin locale filter.
		global $wp_version;

		$get_locale = get_locale();

		if ( $wp_version >= 4.7 ) {
			$get_locale = get_user_locale();
		}

		/**
		 * Language Locale for plugin
		 *
		 * @var string $get_locale The locale to use.
		 *                         Uses get_user_locale()` in WordPress 4.7 or greater,
		 *                         otherwise uses `get_locale()`.
		 */
		$locale = apply_filters( 'plugin_locale', $get_locale, 'modern-cart-woo' );
		$mofile = sprintf( '%1$s-%2$s.mo', 'modern-cart-woo', $locale );

		// Setup paths to current locale file.
		$mofile_global = WP_LANG_DIR . '/plugins/' . $mofile;
		$mofile_local  = $lang_dir . $mofile;

		if ( file_exists( $mofile_global ) ) {
			// Look in global /wp-content/languages/modern-cart-woo/ folder.
			load_textdomain( 'modern-cart-woo', $mofile_global );
		} elseif ( file_exists( $mofile_local ) ) {
			// Look in local /wp-content/plugins/modern-cart-woo/languages/ folder.
			load_textdomain( 'modern-cart-woo', $mofile_local );
		} else {
			// Load the default language files.
			load_plugin_textdomain( 'modern-cart-woo', false, $lang_dir );
		}
	}

	/**
	 * Loads plugin classes as per requirement.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function load_classes(): void {
		if ( ! class_exists( 'woocommerce' ) ) {
			add_action( 'admin_notices', [ $this, 'wc_missing_notice' ] );
			return;
		}

		// Let WooCommerce know, CartFlows is compatible with HPOS.
		add_action( 'before_woocommerce_init', array( $this, 'declare_woo_hpos_compatibility' ) );


		if ( is_admin() ) {
			Admin_Menu::get_instance();
		}

		if ( ! MODERNCART_PRO_LEGACY_MODE ) {
			// Load settings fields.
			Settings_Fields::get_instance();
		}
		Scripts::get_instance();
		Floating::get_instance();
		Slide_Out::get_instance();
		Slide_Out_Ajax::get_instance();
		Floating_Ajax::get_instance();


		// Load the NPS Survey library.
		if ( ! class_exists( 'Modern_Cart_Nps_Survey' ) ) {
			require_once MODERNCART_PRO_DIR . 'inc/libraries/class-modern-cart-nps-survey.php';
		}
		include_once MODERNCART_PRO_DIR . 'inc/classes/class-modern-cart-nps-notice.php';
	}

	/**
	 * Adds links in Plugins page.
	 *
	 * @param array<string> $links Existing links.
	 * @return array<string> Filtered links with settings added.
	 * @since 1.0.0
	 */
	public function action_links( $links ) {
		$plugin_links = apply_filters(
			'cpsw_plugin_action_links',
			[
				'moderncart_settings' => '<a href="' . admin_url( 'admin.php?page=moderncart_settings' ) . '">' . __( 'Settings', 'modern-cart-woo' ) . '</a>',
			]
		);

		return array_merge( $plugin_links, $links );
	}

	/**
	 * Loads classes on plugins_loaded hook.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function wc_missing_notice(): void {
		$plugin     = 'woocommerce/woocommerce.php';
		$plugins    = get_plugins();
		$action_url = '';

		if ( ! function_exists( 'get_current_screen' ) ) {
			require_once ABSPATH . '/wp-admin/includes/screen.php';
		}
		$current_screen = get_current_screen();
		if ( $current_screen && strpos( $current_screen->id, 'update' ) === false ) {
			if ( isset( $plugins[ $plugin ] ) && current_user_can( 'activate_plugins' ) ) {
				$action_url   = wp_nonce_url( 'plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin );
				$button_label = __( 'Activate WooCommerce', 'modern-cart-woo' );
			} elseif ( current_user_can( 'install_plugins' ) ) {
				$action_url   = wp_nonce_url(
					add_query_arg(
						[
							'action' => 'install-plugin',
							'plugin' => 'woocommerce',
						],
						admin_url( 'update.php' )
					),
					'install-plugin_woocommerce'
				);
				$button_label = __( 'Install WooCommerce', 'modern-cart-woo' );
			}

			if ( ! empty( $action_url ) && ! empty( $button_label ) ) {
				echo '<div class="notice notice-error is-dismissible"><p>';
				// translators: 1$-2$: opening and closing <strong> tags, 3$-4$: link tags, takes to woocommerce plugin on wp.org, 5$-6$: opening and closing link tags, leads to plugins.php in admin.
				echo sprintf( esc_html__( '%1$sModern Cart for WooCommerce is inactive.%2$s The %3$sWooCommerce plugin%4$s must be active for Modern Cart for WooCommerce to work. Please %5$s%6$s%7$s', 'modern-cart-woo' ), '<strong>', '</strong>', '<a href="http://wordpress.org/extend/plugins/woocommerce/" target="_blank">', '</a>', '<a href="' . esc_url( $action_url ) . '">', esc_html( $button_label ), '</a>' );
				echo '</p></div>';
			}
		}
	}

	/**
	 * Register BSF Analytics, or skip if the free plugin handles it.
	 *
	 * Modern Cart Starter (free) v1.0.8+ owns the BSF Analytics entity
	 * registration. The Pro plugin must not register a duplicate entity;
	 * doing so would result in two consent notices and a doubled stats
	 * payload.
	 *
	 * If — for backward-compatibility — the free plugin is absent or
	 * older than 1.0.8, the Pro falls back to loading BSF Analytics
	 * using the free plugin's bundled library path.
	 *
	 * Minimum free plugin version that owns analytics: 1.0.8
	 *
	 * @since 1.2.4
	 * @return void
	 */
	public function maybe_init_bsf_analytics_fallback() {
		// Always load Astra Notices — unrelated to analytics.
		if ( ! class_exists( 'Astra_Notices' ) ) {
			require_once MODERNCART_PRO_DIR . 'inc/libraries/astra-notices/class-astra-notices.php';
		}

		// Free plugin v1.0.8+ handles BSF Analytics registration; nothing to do here.
		if ( defined( 'MODERNCART_VER' ) && version_compare( MODERNCART_VER, '1.0.8', '>=' ) ) {
			return;
		}

		// -----------------------------------------------------------------------
		// Fallback: free plugin is missing or older than 1.0.8.
		// Prefer Free's copy of BSF Analytics if available; otherwise use Pro's own.
		// -----------------------------------------------------------------------
		$bsf_analytics_path = ( defined( 'MODERNCART_DIR' ) && file_exists( MODERNCART_DIR . 'inc/libraries/bsf-analytics/class-bsf-analytics-loader.php' ) )
			? MODERNCART_DIR . 'inc/libraries/bsf-analytics'
			: MODERNCART_PRO_DIR . 'inc/libraries/bsf-analytics';

		if ( ! class_exists( 'BSF_Analytics_Loader' ) ) {
			require_once $bsf_analytics_path . '/class-bsf-analytics-loader.php';
		}

		if ( ! class_exists( 'BSF_Analytics_Loader' ) ) {
			return;
		}

		$plugin_slug   = 'modern-cart-for-woocommerce';
		$bsf_analytics = \BSF_Analytics_Loader::get_instance();

		$bsf_analytics->set_entity(
			array(
				'cf' => array(
					'hide_optin_checkbox' => true,
					'product_name'        => 'Modern Cart for WooCommerce',
					'usage_doc_link'      => 'https://my.cartflows.com/usage-tracking/',
					'path'                => $bsf_analytics_path,
					'author'              => 'CartFlows',
					'deactivation_survey' => apply_filters(
						'moderncart_bsf_analytics_deactivation_survey_data',
						array(
							array(
								'id'                => 'deactivation-survey-' . $plugin_slug,
								'popup_logo'        => MODERNCART_PRO_URL . 'admin-core/assets/images/logo.svg',
								'plugin_slug'       => $plugin_slug,
								'plugin_version'    => MODERNCART_PRO_VER,
								'popup_title'       => __( 'Quick Feedback', 'modern-cart-woo' ),
								'support_url'       => 'https://cartflows.com/contact/',
								'popup_description' => __( 'If you have a moment, please share why you are deactivating Modern Cart:', 'modern-cart-woo' ),
								'show_on_screens'   => array( 'plugins' ),
							),
						)
					),
				),
			)
		);
	}

	/**
	 * Register the Pro plugin's stats callback on the free-plugin filter.
	 *
	 * Free >= 1.0.8 provides Modern_Cart_Analytics which hooks `bsf_core_stats`
	 * and fires `modern_cart_get_specific_stats` for Pro to append its data.
	 * When Free is absent or older than 1.0.8, neither hook exists, so the
	 * legacy analytics class is loaded to fill that gap.
	 *
	 * Modern_Cart_Pro_Analytics is always loaded — it hooks
	 * `modern_cart_get_specific_stats`, which is fired by both the Free class
	 * and the legacy class.
	 *
	 * @since 1.2.4
	 * @return void
	 */
	private function init_pro_analytics_stats() {
		// Always use the real plugin root (not MODERNCART_PRO_DIR, which points
		// to legacy/ subdirectory in legacy mode and would resolve to wrong paths).
		$pro_root = plugin_dir_path( MODERNCART_PRO_FILE );

		// Load the legacy bsf_core_stats callback when Free's analytics class
		// does not exist (Free < 1.0.8 or Free not installed).
		// The legacy analytics class always lives in legacy/inc/classes/.
		if ( ! defined( 'MODERNCART_VER' ) || version_compare( MODERNCART_VER, '1.0.8', '<' ) ) {
			require_once $pro_root . 'legacy/inc/classes/class-modern-cart-legacy-analytics.php';
		}

		require_once $pro_root . 'inc/classes/class-modern-cart-pro-analytics.php';
	}

	/**
	 * Filters the cart count based on settings.
	 * 
	 * Determines whether to show total product quantity or number of cart items
	 * based on the count_behavior setting.
	 *
	 * @since 1.2.2
	 * @param int $cart_contents_count Total quantity of all products in cart.
	 * @return int Filtered cart count based on settings.
	 */
	public function filter_cart_count( $cart_contents_count ) {
		// Get cart settings from options.
		$cart_settings = Helper::get_instance()->get_option( MODERNCART_SETTINGS );
		// Get count behavior setting, default to product quantity if not set.
		$count_behavior = isset( $cart_settings['count_behavior'] ) ? $cart_settings['count_behavior'] : 'product-qty';

		// If count behavior is set to cart quantity, return number of items in cart.
		if ( 'cart-qty' === $count_behavior ) {
			return count( WC()->cart->get_cart() );
		}

		// Otherwise return total quantity of all products.
		return $cart_contents_count;
	}

	/**
	 * Extends the default settings with Pro-specific defaults.
	 *
	 * This method merges additional Pro settings into the provided defaults array.
	 * It defines default values and types for various settings in the Pro version,
	 * including cart, floating cart, and appearance options.
	 *
	 * @since 1.2.0
	 *
	 * @param array<string, mixed> $defaults The existing default settings array.
	 * @return array<string, mixed> The merged array of default settings including Pro options.
	 */
	public function extend_default_settings( array $defaults ) {
		$pro_defaults = [
			MODERNCART_SETTINGS            => [
				'cart_selected_pages'                 => [
					'value' => '',
					'type'  => 'string',
				],
				'cart_type'                           => [
					'value' => 'slideout',
					'type'  => 'string',
				],
				'cart_header_style'                   => [
					'value' => 'style1',
					'type'  => 'string',
				],
				'order_summary_style'                 => [
					'value' => 'style1',
					'type'  => 'string',
				],
				'count_behavior'                      => [
					'value' => 'product-qty',
					'type'  => 'string',
				],
				'cart_auto_open_behavior'             => [
					'value' => 'show-cart-on-first-add',
					'type'  => 'string',
				],
				'cart_opening_direction'              => [
					'value' => 'right',
					'type'  => 'string',
				],
				'slide_out_width_desktop'             => [
					'value' => 450,
					'type'  => 'number',
				],
				'slide_out_width_mobile'              => [
					'value' => 80,
					'type'  => 'number',
				],
				'popup_width_desktop'                 => [
					'value' => 50,
					'type'  => 'number',
				],
				'popup_width_mobile'                  => [
					'value' => 80,
					'type'  => 'number',
				],
				'enable_total'                        => [
					'value' => false,
					'type'  => 'boolean',
				],
				'enable_subtotal'                     => [
					'value' => true,
					'type'  => 'boolean',
				],
				'enable_discount'                     => [
					'value' => false,
					'type'  => 'boolean',
				],
				'enable_tax'                          => [
					'value' => false,
					'type'  => 'boolean',
				],
				'enable_shipping'                     => [
					'value' => false,
					'type'  => 'boolean',
				],
				'recommendation_types'                => [
					'value' => 'disabled',
					'type'  => 'string',
				],
				'recommendation_list_style'           => [
					'value' => 'style1',
					'type'  => 'string',
				],
				'empty_cart_recommendation'           => [
					'value' => 'disabled',
					'type'  => 'string',
				],
				'enable_coupon_field'                 => [
					'value' => 'minimize',
					'type'  => 'string',
				],
				'custom_recommendations'              => [
					'value' => '',
					'type'  => 'string',
				],
				'enable_product_image_in_mobile_view' => [
					'value' => false,
					'type'  => 'boolean',
				],
			],
			MODERNCART_FLOATING_SETTINGS   => [
				'display_floating_cart_icon' => [
					'value' => true,
					'type'  => 'boolean',
				],
				'custom_cart_icon_url'       => [
					'value' => '',
					'type'  => 'string',
				],
				'custom_trigger_selectors'   => [
					'value' => '',
					'type'  => 'string',
				],
				'enable_floating_if_empty'   => [
					'value' => false,
					'type'  => 'boolean',
				],
				'floating_cart_icon'         => [
					'value' => 0,
					'type'  => 'number',
				],
				'icon_color'                 => [
					'value' => '#FFFFFF',
					'type'  => 'hex',
				],
				'icon_background_color'      => [
					'value' => '#0284C7',
					'type'  => 'hex',
				],
				'count_text_color'           => [
					'value' => '#FFFFFF',
					'type'  => 'hex',
				],
				'count_background_color'     => [
					'value' => '#10B981',
					'type'  => 'hex',
				],
				'icon_width'                 => [
					'value' => 60,
					'type'  => 'number',
				],
				'icon_border_radius'         => [
					'value' => 200,
					'type'  => 'number',
				],
			],
			MODERNCART_APPEARANCE_SETTINGS => [
				'background_color'          => [
					'value' => '#FFFFFF',
					'type'  => 'hex',
				],
				'highlight_color'           => [
					'value' => '#10B981',
					'type'  => 'hex',
				],
				'button_font_color'         => [
					'value' => '#FFFFFF',
					'type'  => 'hex',
				],
				'header_font_color'         => [
					'value' => '#1F2937',
					'type'  => 'hex',
				],
				'header_background_color'   => [
					'value' => '#FFFFFF',
					'type'  => 'hex',
				],
				'quantity_font_color'       => [
					'value' => '#1F2937',
					'type'  => 'hex',
				],
				'quantity_background_color' => [
					'value' => '#EAEFF3',
					'type'  => 'hex',
				],
			],
		];

		return array_merge_recursive( $defaults, $pro_defaults );
	}
}

/**
 * Kicking this off by calling 'get_instance()' method
 */
Plugin_Loader::get_instance();
