<?php
/**
 * Plugin Name: Modern Cart for WooCommerce
 * Description: The Modern Cart enhances your WooCommerce cart with more features and customization options.
 * Author: CartFlows
 * Author URI: https://cartflows.com/
 * Version: 1.2.6
 * License: GPL v2
 * Text Domain: modern-cart-woo
 * WC requires at least: 3.0
 * WC tested up to: 9.8.4
 *
 * @package modern-cart-woo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

// Enable legacy mode for the users who have not install the WP.Org version of Modern Cart.
define( 'MODERNCART_PRO_LEGACY_MODE', ( ! is_plugin_active( 'modern-cart/modern-cart.php' ) && ! defined( 'MODERNCART_FILE' ) ) );

/**
 * Set constants
 */
define( 'MODERNCART_PRO_FILE', __FILE__ );
define( 'MODERNCART_PRO_BASE', plugin_basename( MODERNCART_PRO_FILE ) );
define( 'MODERNCART_PRO_DIR', MODERNCART_PRO_LEGACY_MODE ? plugin_dir_path( MODERNCART_PRO_FILE ) . 'legacy/' : plugin_dir_path( MODERNCART_PRO_FILE ) );
define( 'MODERNCART_PRO_URL', MODERNCART_PRO_LEGACY_MODE ? plugins_url( '/legacy/', MODERNCART_PRO_FILE ) : plugins_url( '/', MODERNCART_PRO_FILE ) );
define( 'MODERNCART_PRO_PLUGIN_PATH', untrailingslashit( MODERNCART_PRO_DIR ) );
define( 'MODERNCART_PRO_VER', '1.2.6' );
define( 'MODERNCART_PRO_SERVER_URL', 'https://my.cartflows.com/' );
define( 'MODERNCART_PRO_PRODUCT_ID', '121257' );
define( 'MODERNCART_PRO_NPS_WEBHOOK_URL', 'https://webhook.ottokit.com/ottokit/4425a821-721e-4d57-a8cd-b2f294e17801' );

if ( ! defined( 'MODERNCART_PRO_DEBUG' ) ) {
	define( 'MODERNCART_PRO_DEBUG', false );
}

if ( MODERNCART_PRO_LEGACY_MODE ) {

	if ( ! defined( 'MODERNCART_MAIN_SETTINGS' ) ) {
		define( 'MODERNCART_MAIN_SETTINGS', 'moderncart_setting' );
	}
	if ( ! defined( 'MODERNCART_SETTINGS' ) ) {
		define( 'MODERNCART_SETTINGS', 'moderncart_cart' );
	}
	if ( ! defined( 'MODERNCART_FLOATING_SETTINGS' ) ) {
		define( 'MODERNCART_FLOATING_SETTINGS', 'moderncart_floating' );
	}
	if ( ! defined( 'MODERNCART_APPEARANCE_SETTINGS' ) ) {
		define( 'MODERNCART_APPEARANCE_SETTINGS', 'moderncart_appearance' );
	}

	if ( ! defined( 'CARTFLOWS_DOMAIN_URL' ) ) {
		define( 'CARTFLOWS_DOMAIN_URL', 'https://cartflows.com' );
	}
	if ( ! defined( 'CARTFLOWS_API_ROUTE' ) ) {
		define( 'CARTFLOWS_API_ROUTE', '/wp-json/powerful-docs/v1' );
	}
	if ( ! defined( 'CARTFLOWS_DOCS_ENDPOINT' ) ) {
		define( 'CARTFLOWS_DOCS_ENDPOINT', '/get-docs' );
	}

	require_once 'legacy/inc/functions.php';
}
require_once 'plugin-loader.php';
