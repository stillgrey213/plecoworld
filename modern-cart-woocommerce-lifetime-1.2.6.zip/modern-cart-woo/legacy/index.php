<?php
/**
 * Silence is golden.
 *
 * @package modern-cart-woo
 */
