<?php
/**
 * Modern Cart Woo slide-out Recommendations Slide
 *
 * @package modern-cart-woo
 * @since 1.0.8
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$allow_wp_kses = [
	'span' => [
		'class' => [],
	],
	'p'    => [
		'class' => [],
	],
	'bdi'  => [
		'class' => [],
	],
	'del'  => [
		'aria-hidden' => [],
	],
	'div'  => [
		'class' => [],
	],
	'a'    => [
		'href'  => [],
		'title' => [],
		'class' => [],
	],
];

$img_wp_kses = [
	'img' => [
		'title'   => [],
		'src'     => [],
		'class'   => [],
		'alt'     => [],
		'width'   => [],
		'height'  => [],
		'loading' => [],
	],
];
?>
<div class="moderncart-slide moderncart-recommendations-slide" id="moderncart-recommendations-slide">
	<div class="moderncart-slide-header">
		<button type="button" class="moderncart-slide-back" aria-label="<?php esc_attr_e( 'Back to cart', 'modern-cart-woo' ); ?>">
			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
			</svg>
		</button>
		<h3 class="moderncart-slide-title"><?php echo esc_html( $title ); ?></h3>
	</div>

	<div class="moderncart-slide-content">
		<div class="moderncart-recommendations-grid">
			<?php foreach ( $recommended_products as $key => $recommended_product ) : ?>
				<?php
				$product_permalink = $recommended_product->is_visible() ? $recommended_product->get_permalink() : '';
				?>
				<div class="moderncart-recommendation-item">
					<div class="moderncart-recommendation-image">
						<?php if ( $product_permalink ) : ?>
							<a href="<?php echo esc_url( $product_permalink ); ?>">
						<?php endif; ?>
						<?php if ( wp_get_attachment_image( $recommended_product->get_image_id(), 'thumbnail' ) ) : ?>
							<?php
							echo wp_kses_post(
								wp_get_attachment_image(
									$recommended_product->get_image_id(),
									'thumbnail',
									false,
									array(
										'aria-hidden' => 'true',
									) 
								) 
							);
							?>
						<?php else : ?>
							<?php
							echo wp_kses(
								wc_placeholder_img(
									'thumbnail',
									array(
										'aria-hidden' => 'true',
									) 
								),
								$img_wp_kses 
							);
							?>
						<?php endif; ?>	
						<?php if ( $product_permalink ) : ?>
							</a>
						<?php endif; ?>
					</div>

					<div class="moderncart-recommendation-details">
						<h4 class="moderncart-recommendation-title">
							<?php if ( $product_permalink ) : ?>
								<a href="<?php echo esc_url( $product_permalink ); ?>">
							<?php endif; ?>
							<?php echo wp_kses( $recommended_product->get_name(), $allow_wp_kses ); ?>
							<?php if ( $product_permalink ) : ?>
								</a>
							<?php endif; ?>
						</h4>

						<p class="moderncart-recommendation-price">
							<?php echo wp_kses( $recommended_product->get_price_html(), $allow_wp_kses ); ?>
						</p>

						<div class="moderncart-recommendation-actions">
							<?php
							$classes                = array( 'moderncart-btn-upsell', 'moderncart-button' );
							$simple_product_classes = array( 'moderncart_add_to_cart_button' );
							$upsell_button_text     = __( 'Select Options', 'modern-cart-woo' );

							if ( $recommended_product->is_type( 'simple' ) ) {
								$classes = array_merge( $classes, $simple_product_classes );
							}

							$attributes = array(
								'type'  => 'button',
								'class' => esc_html( implode( ' ', array_filter( $classes ) ) ),
								'href'  => esc_url( $product_permalink ),
							);

							if ( $recommended_product->is_type( 'simple' ) ) {
								$simple_product_attributes = array(
									'value'                => $recommended_product->get_id(),
									'data-moderncart-cart-open' => 'false',
									'data-moderncart-type' => 'recommendation',
									'data-quantity'        => '1',
									'data-product_id'      => $recommended_product->get_id(),
									'href'                 => '#',
								);
								$attributes                = array_merge( $attributes, $simple_product_attributes );
								$upsell_button_text        = $button_text;
							}

							if ( $recommended_product->is_type( array( 'subscription', 'variable-subscription', 'subscription_variation' ) ) ) {
								$upsell_button_text = __( 'Sign Up Now', 'modern-cart-woo' );
							}
							?>
							<a <?php echo wp_kses( moderncart_implode_html_attributes( $attributes ), $allow_wp_kses ); ?>>
								<span><?php echo esc_html( $upsell_button_text ); ?></span>
							</a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>
