<?php
/**
 * Slide out html
 *
 * @package modern-cart-woo
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$data = [
	'classes'      => $classes,
	'attributes'   => $attributes,
	'notice'       => $notice,
	'message_type' => isset( $message_type ) ? $message_type : '',
];
?>

<div id="moderncart-slide-out-modal" class="<?php echo esc_attr( implode( ' ', array_filter( $modal_classes ) ) ); ?>" aria-hidden="true" role="region">
	<?php moderncart_get_template_part( 'shop/slide-out-inner', '', $data ); ?>
</div>
<div id="live-region" aria-live="polite"></div>
