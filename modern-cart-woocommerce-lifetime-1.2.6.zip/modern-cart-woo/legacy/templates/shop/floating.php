<?php
/**
 * Modern Cart Woo floating html
 *
 * @package modern-cart-woo
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="moderncart-floating-cart" class="<?php echo esc_attr( implode( ' ', array_filter( $classes ) ) ); ?>">
	<?php
	moderncart_get_template_part(
		'shop/floating-inner',
		'',
		[
			'item_account'    => $item_account,
			'cart_icon'       => $cart_icon,
			'custom_icon_url' => $custom_icon_url,
			'cart_svg_icons'  => $cart_svg_icons,
		] 
	);
	?>
</div>
