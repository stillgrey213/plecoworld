<?php
/**
 * Admin menu.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Admin_Core;

use ModernCart_Pro\Inc\Helper;
use ModernCart_Pro\Inc\Traits\Get_Instance;

/**
 * Admin menu
 *
 * @since 1.0.0
 */
class Admin_Menu {
	use Get_Instance;

	/**
	 * Tailwind assets base url
	 *
	 * @var string
	 * @since 1.0.0
	 */
	private $tailwind_assets = MODERNCART_PRO_URL . 'admin-core/assets/build/';

	/**
	 * Instance of Helper class
	 *
	 * @var Helper
	 * @since 1.0.0
	 */
	private $helper;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->helper = new Helper();
		add_action( 'admin_menu', [ $this, 'settings_page' ], 99 );
		add_action( 'admin_enqueue_scripts', [ $this, 'settings_page_scripts' ] );
		add_action( 'wp_ajax_moderncart_update_settings', [ $this, 'moderncart_update_settings' ] );
		add_action( 'wp_ajax_moderncart_install_plugin', 'wp_ajax_install_plugin' );
		add_action( 'wp_ajax_moderncart_activate_plugin', [ $this, 'moderncart_activate_plugin' ] );
		add_action( 'wp_ajax_moderncart_fetch_whats_new', [ $this, 'fetch_whats_new' ] );
		add_action( 'wp_ajax_moderncart_search_products', [ $this, 'search_products' ] );
		add_action( 'wp_ajax_moderncart_get_products', [ $this, 'get_products' ] );
	}

	/**
	 * Adds admin menu for settings page
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function settings_page(): void {
		add_submenu_page(
			'woocommerce',
			__( 'Settings - Modern Cart Woo', 'modern-cart-woo' ),
			__( 'Modern Cart', 'modern-cart-woo' ),
			'manage_woocommerce',
			'moderncart_settings',
			[ $this, 'render' ],
			57
		);
	}

	/**
	 * Renders main div to implement tailwind UI
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function render(): void {
		?>
		<div class="moderncart-settings" id="moderncart-settings"></div>
		<?php
	}

	/**
	 * Enqueue settings page script and style
	 *
	 * @param string $hook Current page hook name.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function settings_page_scripts( $hook ): void {
		if ( 'woocommerce_page_moderncart_settings' !== $hook ) {
			return;
		}

		$version           = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? (string) time() : MODERNCART_PRO_VER;
		$script_asset_path = MODERNCART_PRO_DIR . 'admin-core/assets/build/settings.asset.php';
		$script_info       = file_exists( $script_asset_path )
			? include $script_asset_path
			: [
				'dependencies' => [],
				'version'      => $version,
			];

		$script_dep = array_merge( $script_info['dependencies'], [ 'updates' ] );

		wp_register_script( 'moderncart_settings', $this->tailwind_assets . 'settings.js', $script_dep, $version, true );
		wp_enqueue_script( 'moderncart_settings' );
		wp_localize_script(
			'moderncart_settings',
			'moderncart_settings',
			[
				'ajax_url'                     => admin_url( 'admin-ajax.php' ),
				'update_nonce'                 => wp_create_nonce( 'moderncart_update_settings' ),
				MODERNCART_MAIN_SETTINGS       => $this->helper->get_option( MODERNCART_MAIN_SETTINGS ),
				MODERNCART_SETTINGS            => $this->helper->get_option( MODERNCART_SETTINGS ),
				MODERNCART_FLOATING_SETTINGS   => $this->helper->get_option( MODERNCART_FLOATING_SETTINGS ),
				MODERNCART_APPEARANCE_SETTINGS => $this->helper->get_option( MODERNCART_APPEARANCE_SETTINGS ),
				'is_cpsw_have'                 => defined( 'CPSW_VERSION' ) ? 'yes' : 'no',
				'license_nonces'               => [
					'activate_license_nonce'   => wp_create_nonce( 'modern_cart_license_activation_nonce' ),
					'deactivate_license_nonce' => wp_create_nonce( 'modern_cart_license_deactivation_nonce' ),
				],
				'license_status'               => class_exists( '\ModernCart_Pro\Inc\Classes\Modern_Cart_License' ) ? \ModernCart_Pro\Inc\Classes\Modern_Cart_License::get_instance()->activate_status : '',
				'cartflows_activation'         => [
					'plugin_installer_nonce'  => wp_create_nonce( 'updates' ),
					'plugin_activation_nonce' => wp_create_nonce( 'moderncart_activate_plugin_nonce' ),
					'plugin_status'           => $this->get_cartflows_plugin_status(),
				],
				'whats_new_rss_feed'           => $this->get_whats_new_rss_feeds_data(),
				'theme_colors'                 => Helper::get_compatible_colors(),
				'moderncart_cart_icons'        => Helper::get_cart_icons(),
				'knowledge_base'               => Helper::get_knowledge_base(),
			]
		);

		wp_register_style( 'moderncart_settings', $this->tailwind_assets . 'settings.css', [], $version );
		wp_style_add_data( 'moderncart_settings', 'rtl', 'replace' );
		wp_enqueue_style( 'wp-components' );
		wp_enqueue_style( 'moderncart_settings' );
		wp_enqueue_style( 'moderncart_font', 'https://fonts.googleapis.com/css2?family=Figtree:wght@300;400;500;600&display=swap', [], MODERNCART_PRO_VER );

		// Enqueue WordPress media library for custom icon upload.
		wp_enqueue_media();

		// Load translations strings used in the Javascript file.
		wp_set_script_translations( 'moderncart_settings', 'modern-cart-woo', MODERNCART_PRO_DIR . 'languages' );

		wp_add_inline_style(
			'moderncart_settings',
			'.woocommerce_page_moderncart_settings #wpfooter {
				display: none !important;
			}
			'
		);
	}

	/**
	 * Ajax handler for submit action on settings page.
	 * Updates settings data in database.
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function moderncart_update_settings(): void {
		check_ajax_referer( 'moderncart_update_settings', 'security' );
		$keys = [];

		if ( ! empty( $_POST[ MODERNCART_MAIN_SETTINGS ] ) ) {
			$keys[] = MODERNCART_MAIN_SETTINGS;
		}

		if ( ! empty( $_POST[ MODERNCART_SETTINGS ] ) ) {
			$keys[] = MODERNCART_SETTINGS;
		}

		if ( ! empty( $_POST[ MODERNCART_FLOATING_SETTINGS ] ) ) {
			$keys[] = MODERNCART_FLOATING_SETTINGS;
		}

		if ( ! empty( $_POST[ MODERNCART_APPEARANCE_SETTINGS ] ) ) {
			$keys[] = MODERNCART_APPEARANCE_SETTINGS;
		}

		if ( empty( $keys ) ) {
			wp_send_json_error( [ 'message' => __( 'No valid setting keys found.', 'modern-cart-woo' ) ] );
		}

		$succeded = 0;
		foreach ( $keys as $key ) {
			if ( $this->update_settings( $key ) ) {
				$succeded++;
			}
		}

		if ( count( $keys ) === $succeded ) {
			wp_send_json_success( [ 'message' => __( 'Settings saved successfully.', 'modern-cart-woo' ) ] );
		}

		wp_send_json_error( [ 'message' => __( 'Failed to save settings.', 'modern-cart-woo' ) ] );
	}

	/**
	 * Update dettings data in database
	 *
	 * @param string $key options key.
	 * @return bool
	 * @since 1.0.0
	 */
	public function update_settings( $key ) {
		$data         = ! empty( $_POST[ $key ] ) ? json_decode( stripslashes( $_POST[ $key ] ), true ) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing --> Sanitized in later stage | Nonce Already verified.
		$data         = is_array( $data ) ? $this->sanitize_data( $data ) : [];
		$default_data = $this->helper->get_option( $key );
		$data         = wp_parse_args( $data, $default_data );

		return update_option( $key, $data );
	}

	/**
	 * Sanitize data as per data type
	 *
	 * @param array<string> $data raw input received from user.
	 * @return array<mixed>
	 * @since 1.0.0
	 */
	public function sanitize_data( $data ) {
		$temp     = [];
		$booleans = [
			'enable_cart',
			'display_floating_cart_icon',
			'enable_floating_if_empty',
			'enable_delete_settins_plugin',
			'enable_powered_by',
			'enable_total',
			'enable_subtotal',
			'enable_discount',
			'enable_tax',
			'enable_shipping',
			'enable_express_checkout',
			'enable_free_shipping_bar',
			'enable_usage_tracking',
			'enable_product_image_in_mobile_view',
		];

		$numbers = [
			'slide_out_width_desktop',
			'slide_out_width_mobile',
			'animation_speed',
		];

		$text_fields = [
			'recommendation_list_style',
		];

		foreach ( $data as $key => $value ) {
			if ( in_array( $key, $booleans, true ) ) {
				$temp[ $key ] = rest_sanitize_boolean( $value );
			} elseif ( in_array( $key, $numbers, true ) ) {
				$temp[ $key ] = (int) sanitize_text_field( $value );
			} elseif ( in_array( $key, $text_fields, true ) ) {
				$temp[ $key ] = sanitize_text_field( $value );
			} else {
				$temp[ $key ] = sanitize_text_field( $value );
			}
		}

		return $temp;
	}

	/**
	 * Get plugin status
	 *
	 * @since 1.0.0
	 * @return mixed
	 */
	public function get_cartflows_plugin_status() {

		$installed_plugins = get_plugins();

		if ( ! isset( $installed_plugins['cartflows/cartflows.php'] ) ) {
			return 'not-installed';
		}
		if ( is_plugin_active( 'cartflows/cartflows.php' ) ) {
			return 'active';
		}
			return 'inactive';
	}

	/**
	 * Ajax handler for plugin activation
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function moderncart_activate_plugin(): void {
		if ( ! isset( $_POST['security'] ) || ! wp_verify_nonce( sanitize_text_field( $_POST['security'] ), 'moderncart_activate_plugin_nonce' ) ) {
			wp_send_json_error( [ 'message' => 'Nonce verification failed.' ] );
		}
		if ( ! current_user_can( 'activate_plugins' ) ) {
			wp_send_json_error( [ 'message' => 'You do not have permission to activate plugins.' ] );
		}
		$plugin_slug = isset( $_POST['init'] ) ? sanitize_text_field( $_POST['init'] ) : '';
		if ( empty( $plugin_slug ) ) {
			wp_send_json_error( [ 'message' => 'Invalid plugin slug.' ] );
		}
		$activation_result = activate_plugin( $plugin_slug );
		if ( is_wp_error( $activation_result ) ) {
			wp_send_json_error( [ 'message' => 'Plugin activation failed: ' . $activation_result->get_error_message() ] );
		}
		wp_send_json_success( [ 'message' => 'Plugin activated successfully.' ] );
	}

	/**
	 * Prepare the array of RSS Feeds of Modern Cart for Whats New slide-out panel.
	 *
	 * @since 1.0.0
	 * @return array<string> The prepared array of RSS feeds.
	 */
	public function get_whats_new_rss_feeds_data() {
		return [
			'key'   => 'modern-cart-woo',
			'label' => 'Modern Cart',
			'url'   => add_query_arg(
				[
					'action' => 'moderncart_fetch_whats_new',
					'nonce'  => wp_create_nonce( 'moderncart_fetch_whats_new' ),
				],
				admin_url( 'admin-ajax.php' )
			),
		];
	}

	/**
	 * Fetch the Whats New RSS feed from the URL.
	 *
	 * @since 1.0.3
	 * @return void
	 */
	public function fetch_whats_new(): void {
		if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( $_GET['nonce'] ), 'moderncart_fetch_whats_new' ) ) {
			// Verify the nonce, if it fails, return an error.
			wp_send_json_error( [ 'message' => __( 'Nonce verification failed.', 'modern-cart-woo' ) ] );
		}

		// Fetch the RSS feed from the URL. This saves us from the CORS issue.
		$feed = wp_remote_retrieve_body( wp_remote_get( 'https://cartflows.com/product/modern-cart/feed/' ) ); // phpcs:ignore -- This is a valid use case cannot use VIP rules here.

		echo $feed; // phpcs:ignore -- Cannot sanitize the XML data as it is not in our control here.
		exit;
	}

	/**
	 * AJAX handler for product search
	 *
	 * @since 1.0.7
	 * @return void
	 */
	public function search_products(): void {
		check_ajax_referer( 'moderncart_update_settings', 'security' );

		$search_term = isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '';
		if ( empty( $search_term ) ) {
			wp_send_json_error( [ 'message' => 'Search term is required' ] );
		}

		$args = [
			'post_type'      => 'product',
			'post_status'    => 'publish',
			's'              => $search_term,
			'posts_per_page' => 20,
			'fields'         => 'ids',
		];

		$products = get_posts( $args );
		$results  = [];

		foreach ( $products as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product instanceof \WC_Product ) {
				// Skip out of stock products.
				if ( ! $product->is_in_stock() ) {
					continue;
				}

				if ( $product->get_image_id() ) {
					$image_url = wp_get_attachment_image_url( (int) $product->get_image_id(), 'thumbnail' );
				} else {
					// Send WooCommerce placeholder image url if product image does not exist.
					$image_url = wc_placeholder_img_src();
				}

				$results[] = [
					'id'    => $product->get_id(),
					'name'  => $product->get_name(),
					'image' => $image_url,
				];
			}
		}

		wp_send_json_success( $results );
	}

	/**
	 * AJAX handler for getting products by IDs
	 *
	 * @since 1.0.7
	 * @return void
	 */
	public function get_products(): void {
		check_ajax_referer( 'moderncart_update_settings', 'security' );

		$product_ids = isset( $_POST['product_ids'] ) ? sanitize_text_field( $_POST['product_ids'] ) : '';
		if ( empty( $product_ids ) ) {
			wp_send_json_success( [] );
		}

		$ids     = array_map( 'intval', explode( ',', $product_ids ) );
		$results = [];

		foreach ( $ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product instanceof \WC_Product ) {
				$results[] = [
					'id'   => $product->get_id(),
					'name' => $product->get_name(),
				];
			}
		}

		wp_send_json_success( $results );
	}
}
