<?php
/**
 * Scripts.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Inc;

use ModernCart_Pro\Inc\Traits\Get_Instance;
use ModernCart_Pro\Inc\Cart;

/**
 * Scripts
 *
 * @since 1.0.0
 */
class Scripts extends Cart {
	use Get_Instance;

	/**
	 * Plugin version.
	 *
	 * @var string $version Current plugin version.
	 */
	public $version;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->version = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? (string) time() : MODERNCART_PRO_VER;
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'dynamic_styles' ] );
	}

	/**
	 * Dynamic styles
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function dynamic_styles() {
		if ( ! $this->is_global_enabled() ) {
			return;
		}

		$popup_desktop_width       = $this->get_option( 'popup_width_desktop', MODERNCART_SETTINGS, 40 );
		$popup_desktop_width       = $popup_desktop_width > 100 ? 100 : Helper::convert_to_int( $popup_desktop_width );
		$popup_desktop_margin_left = ( 100 - $popup_desktop_width ) / 2;
		$popup_mobile_width        = $this->get_option( 'popup_width_mobile', MODERNCART_SETTINGS, 80 );
		$popup_mobile_width        = $popup_mobile_width > 100 ? 100 : Helper::convert_to_int( $popup_mobile_width );
		$popup_mobile_margin_left  = ( 100 - $popup_mobile_width ) / 2;
		$cart_item_padding         = $this->get_option( 'cart_item_padding', MODERNCART_SETTINGS, 20 );
		$css_vars                  = [
			'--moderncart-primary-color'               => $this->get_option( 'primary_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-heading-color'               => $this->get_option( 'heading_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-body-color'                  => $this->get_option( 'body_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-background-color'            => $this->get_option( 'background_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-highlight-color'             => $this->get_option( 'highlight_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-button-font-color'           => $this->get_option( 'button_font_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-header-font-color'           => $this->get_option( 'header_font_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-header-background-color'     => $this->get_option( 'header_background_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-quantity-font-color'         => $this->get_option( 'quantity_font_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-quantity-background-color'   => $this->get_option( 'quantity_background_color', MODERNCART_APPEARANCE_SETTINGS ),
			'--moderncart-slide-out-desktop-width'     => $this->get_option( 'slide_out_width_desktop', MODERNCART_SETTINGS ) . 'px',
			'--moderncart-slide-out-mobile-width'      => $this->get_option( 'slide_out_width_mobile', MODERNCART_SETTINGS ) . '%',
			'--moderncart-popup-desktop-width'         => $popup_desktop_width . '%',
			'--moderncart-popup-desktop-margin-left'   => $popup_desktop_margin_left . '%',
			'--moderncart-popup-mobile-width'          => $popup_mobile_width . '%',
			'--moderncart-popup-mobile-margin-left'    => $popup_mobile_margin_left . '%',
			'--moderncart-animation-duration'          => $this->get_option( 'animation_speed', MODERNCART_SETTINGS ) . 'ms',
			'--moderncart-cart-item-padding'           => $cart_item_padding . 'px',
			// Floating cart icon customization.
			'--moderncart-floating-icon-color'         => $this->get_option( 'icon_color', MODERNCART_FLOATING_SETTINGS, '#FFFFFF' ),
			'--moderncart-floating-icon-bg-color'      => $this->get_option( 'icon_background_color', MODERNCART_FLOATING_SETTINGS, '#0284C7' ),
			'--moderncart-floating-count-text-color'   => $this->get_option( 'count_text_color', MODERNCART_FLOATING_SETTINGS, '#FFFFFF' ),
			'--moderncart-floating-count-bg-color'     => $this->get_option( 'count_background_color', MODERNCART_FLOATING_SETTINGS, '#10B981' ),
			'--moderncart-floating-icon-width'         => $this->get_option( 'icon_width', MODERNCART_FLOATING_SETTINGS, 60 ) . 'px',
			'--moderncart-floating-icon-border-radius' => $this->get_option( 'icon_border_radius', MODERNCART_FLOATING_SETTINGS, 200 ) . 'px',
		];

		$dynamic_css = ':root {' . PHP_EOL;

		foreach ( $css_vars as $var => $value ) {
			$_value       = Helper::convert_to_string( $value );
			$dynamic_css .= "\t{$var}: {$_value};" . PHP_EOL;

			// Add alpha value for color variables if the value is a color and it does not contain alpha already.
			if ( false !== strpos( $var, '-color' ) && 7 === strlen( $_value ) ) {
				$dynamic_css .= "\t{$var}-light: {$_value}12;" . PHP_EOL;
			}
		}

		$dynamic_css .= '}';

		// Add cart item padding CSS.
		$dynamic_css .= '.moderncart-cart-item {
			padding-left: var(--moderncart-cart-item-padding);
			padding-right: var(--moderncart-cart-item-padding);
		}';

		$cart_launcher_position = $this->get_option( 'floating_cart_position', MODERNCART_FLOATING_SETTINGS, 'bottom-right' );

		if ( $cart_launcher_position && 'bottom-right' === $cart_launcher_position ) {
			$dynamic_css .= '#moderncart-floating-cart {
					left: auto;
					right: 20px;
					flex-direction: row-reverse;
				}';
		} elseif ( $cart_launcher_position && 'bottom-left' === $cart_launcher_position ) {
			$dynamic_css .= '#moderncart-floating-cart {
					left: 20px;
					right: auto;
				}';
		}

		if ( empty( $this->get_option( 'enable_express_checkout', MODERNCART_MAIN_SETTINGS, false ) ) ) {
			$dynamic_css .= '.moderncart-slide-out-footer #cpsw-payment-request-wrapper {
				display: none !important;
			}';
		}

		// Dynamic CSS related to RTL mode.
		if ( is_rtl() ) {
			$dynamic_css .= '#moderncart-slide-out .moderncart-slide-out-footer .moderncart-order-summary-style-style2 #moderncart-coupon-form-container .moderncart-coupon-remove {
				justify-content: right;
			}';
		}

		wp_add_inline_style( 'moderncart-cart-css', $dynamic_css );
	}

	/**
	 * Enqueue scripts
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! $this->is_global_enabled() ) {
			return;
		}

		wp_register_style( 'moderncart-cart-css', MODERNCART_PRO_URL . 'assets/css/cart.css', [], $this->version );
		wp_style_add_data( 'moderncart-cart-css', 'rtl', 'replace' );
		wp_enqueue_style( 'moderncart-cart-css' );

		// Enqueue recommendations slide CSS if recommendations are enabled.
		if ( 'disabled' !== $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ) ) {
			$css_file = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? 'assets/css/recommendations-slide.css' : 'assets/min-css/recommendations-slide.min.css';
			wp_register_style( 'moderncart-recommendations-slide-css', MODERNCART_PRO_URL . $css_file, [ 'moderncart-cart-css' ], $this->version );
			wp_enqueue_style( 'moderncart-recommendations-slide-css' );
		}

		// Only load Splide assets when using slider style for recommendations.
		$recommendation_list_style = $this->get_option( 'recommendation_list_style', MODERNCART_SETTINGS, 'style1' );
		if ( ( 'disabled' !== $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ) && 'style1' === $recommendation_list_style ) || 'disabled' !== $this->get_option( 'empty_cart_recommendation', MODERNCART_SETTINGS, 'disabled' ) ) {
			wp_register_style( 'moderncart-splide-css', MODERNCART_PRO_URL . 'assets/css/splide.min.css', [], $this->version );
			wp_enqueue_style( 'moderncart-splide-css' );

			wp_register_script( 'moderncart-splide-js', MODERNCART_PRO_URL . 'assets/js/splide.min.js', [ 'jquery' ], $this->version, true );
			wp_enqueue_script( 'moderncart-splide-js' );
		}

		wp_register_script( 'moderncart-cart-js', MODERNCART_PRO_URL . 'assets/js/cart.js', [ 'jquery' ], $this->version, true );
		wp_enqueue_script( 'moderncart-cart-js' );

		wp_localize_script(
			'moderncart-cart-js',
			'moderncart_ajax_object',
			apply_filters(
				'moderncart_localize_script_args',
				[
					'ajax_url'                            => admin_url( 'admin-ajax.php' ),
					'ajax_nonce'                          => wp_create_nonce( 'moderncart_ajax_nonce' ),
					'general_error'                       => __( 'Somethings wrong! try again later', 'modern-cart-woo' ),
					'edit_cart_text'                      => __( 'Edit Cart', 'modern-cart-woo' ),
					'is_needed_edit_cart'                 => ! function_exists( '_get_wcf_step_id' ) && 'astra' !== get_template() ? false : true,
					'recommendation_types'                => $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ),
					'recommendation_list_style'           => $this->get_option( 'recommendation_list_style', MODERNCART_SETTINGS, 'style1' ),
					'empty_cart_recommendation'           => $this->get_option( 'empty_cart_recommendation', MODERNCART_SETTINGS, 'disabled' ),
					'animation_speed'                     => $this->get_option( 'animation_speed', MODERNCART_SETTINGS, '300' ),
					'cart_redirect_after_add'             => apply_filters( 'moderncart_redirect_after_add_to_cart', false ),
					'custom_trigger_selectors'            => $this->get_option( 'custom_trigger_selectors', MODERNCART_FLOATING_SETTINGS, '' ),
					'cart_auto_open_behavior'             => $this->get_option( 'cart_auto_open_behavior', MODERNCART_SETTINGS, 'show-cart-on-first-add' ),
					'enable_product_image_in_mobile_view' => $this->get_option( 'enable_product_image_in_mobile_view', MODERNCART_SETTINGS, false ),
					'cart_opening_direction'              => $this->get_option( 'cart_opening_direction', MODERNCART_SETTINGS, 'right' ),
				]
			)
		);
	}
}
