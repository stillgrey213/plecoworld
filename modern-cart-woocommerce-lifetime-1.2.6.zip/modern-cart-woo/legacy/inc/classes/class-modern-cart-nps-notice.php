<?php
/**
 * NPS Survey Notice
 *
 * @package modern-cart-woo
 * @since 1.0.3
 */

namespace ModernCart_Pro\Inc\Classes;

use ModernCart_Pro\Inc\Traits\Get_Instance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Modern_Cart_Nps_Notice' ) ) {

	/**
	 * Admin
	 */
	class Modern_Cart_Nps_Notice {
		use Get_Instance;

		/**
		 * Constructor.
		 *
		 * @since 1.0.0
		 */
		private function __construct() {
			add_action( 'admin_footer', [ $this, 'show_nps_notice' ], 999 );
			add_filter( 'nps_survey_api_endpoint', [ $this, 'update_webhook_url' ], 10, 2 );
			add_filter( 'nps_survey_post_data', [ $this, 'update_nps_survey_post_data' ] );
		}

		/**
		 * Render NPS Survey
		 *
		 * @return void
		 */
		public function show_nps_notice(): void {
			if ( ! class_exists( 'Nps_Survey' ) ) {
				return;
			}

			$license = class_exists( '\ModernCart_Pro\Inc\Classes\Modern_Cart_License' ) ? \ModernCart_Pro\Inc\Classes\Modern_Cart_License::get_instance()->activate_status : '';

			\Nps_Survey::show_nps_notice(
				'nps-survey-modern-cart-for-woocommerce',
				[
					'show_if'          => 'Activated' === $license,
					'dismiss_timespan' => 2 * WEEK_IN_SECONDS,
					'display_after'    => 0,
					'plugin_slug'      => 'modern-cart-for-woocommerce',
					'show_on_screens'  => [ 'woocommerce_page_moderncart_settings' ],
					'message'          => [
						'logo'                        => esc_url( MODERNCART_PRO_URL . 'admin-core/assets/images/logo.svg' ),
						'plugin_name'                 => __( 'Modern Cart', 'modern-cart-woo' ),
						'nps_rating_message'          => __( 'How likely are you to recommend Modern Cart to your friends or colleagues?', 'modern-cart-woo' ),

						'feedback_title'              => __( 'Thanks a lot for your feedback! 😍', 'modern-cart-woo' ),
						'feedback_content'            => '',
						'plugin_rating_link'          => '',

						'plugin_rating_title'         => __( 'Thank you for your feedback', 'modern-cart-woo' ),
						'plugin_rating_content'       => __( 'We value your input. How can we improve your experience?', 'modern-cart-woo' ),
						'plugin_rating_button_string' => __( 'Rate Modern Cart', 'modern-cart-woo' ),
					],
				]
			);
		}

		/**
		 * Update the NPS survey webhook URL.
		 *
		 * @param string       $url Webhook URL.
		 * @param array<mixed> $post_data NPS survey post data.
		 * @since 1.0.5
		 *
		 * @return string
		 */
		public function update_webhook_url( $url, $post_data ) {
			if ( isset( $post_data['plugin_slug'] ) && 'modern-cart-for-woocommerce' === $post_data['plugin_slug'] ) {
				// Return the NPS webhook URL if the plugin slug is Modern Cart.
				return MODERNCART_PRO_NPS_WEBHOOK_URL;
			}

			return $url;
		}

		/**
		 * Update the NPS survey post data.
		 * Add Modern Cart plugin version to the NPS survey post data.
		 *
		 * @param array<mixed> $post_data NPS survey post data.
		 * @since 1.0.3
		 * @return array<mixed>
		 */
		public function update_nps_survey_post_data( $post_data ) {
			if ( isset( $post_data['plugin_slug'] ) && 'modern-cart-for-woocommerce' === $post_data['plugin_slug'] ) {
				$post_data['plugin_version'] = MODERNCART_PRO_VER;
			}

			return $post_data;
		}

	}

	/**
	 * Kicking this off by calling 'get_instance()' method
	 */
	Modern_Cart_Nps_Notice::get_instance();

}
