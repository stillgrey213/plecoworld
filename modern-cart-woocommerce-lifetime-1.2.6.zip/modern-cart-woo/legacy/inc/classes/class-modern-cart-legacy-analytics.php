<?php
/**
 * Modern Cart Legacy Analytics.
 *
 * Provides a `bsf_core_stats` callback for sites running the Pro plugin
 * alongside a Free plugin older than 1.0.7 (or with no Free plugin at all).
 *
 * Free >= 1.0.7 ships its own Modern_Cart_Analytics class that hooks
 * `bsf_core_stats` and fires `modern_cart_get_specific_stats` so Pro can
 * append its data. When the Free plugin is absent or pre-1.0.7, neither of
 * those hooks is registered, so the analytics payload would contain only
 * generic server stats. This class fills that gap by replicating the same
 * stat-collection logic that was later moved to the Free plugin.
 *
 * Loaded only when Free < 1.0.7 or Free is not installed. See
 * Plugin_Loader::init_pro_analytics_stats() in plugin-loader.php.
 *
 * @package modern-cart-woo
 * @since   1.2.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Modern_Cart_Legacy_Analytics
 *
 * Singleton. Hooks `bsf_core_stats`, populates the free-feature stats node,
 * then fires `modern_cart_get_specific_stats` so Modern_Cart_Pro_Analytics
 * can append Pro-specific data via its own filter callback.
 *
 * @since 1.2.5
 */
class Modern_Cart_Legacy_Analytics {

	/**
	 * Singleton instance.
	 *
	 * @since 1.2.5
	 * @var Modern_Cart_Legacy_Analytics|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @since 1.2.5
	 * @return Modern_Cart_Legacy_Analytics
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — registers hooks for stats collection and analytics opt-in.
	 *
	 * @since 1.2.5
	 */
	private function __construct() {
		add_filter( 'bsf_core_stats', array( $this, 'get_specific_stats' ) );

		// Register the enable_usage_tracking default via the Free plugin's settings
		// filter so the option is available in MODERNCART_SETTINGS even when old Free
		// does not define it. This mirrors the optin_usage_tracking field that was
		// moved to Free >= 1.0.7.
		add_filter( 'moderncart_default_settings', array( $this, 'register_analytics_default' ) );

		// Register the analytics toggle as a visible settings field so the admin
		// can enable/disable tracking from the settings page (Condition 3: old Free
		// does not ship this field itself).
		add_filter( 'moderncart_settings_fields', array( $this, 'add_analytics_settings_field' ) );
	}

	/**
	 * Inject Modern Cart stats into the BSF Analytics payload.
	 *
	 * Mirrors Modern_Cart_Analytics::get_specific_stats() from the Free plugin
	 * (introduced in Free 1.0.7). Populates free-feature data, then fires
	 * `modern_cart_get_specific_stats` so Modern_Cart_Pro_Analytics can merge
	 * Pro-specific fields without duplicating this logic.
	 *
	 * @since 1.2.5
	 *
	 * @param array<string, mixed> $stats_data Existing BSF stats array.
	 * @return array<string, mixed> Stats array with Modern Cart data added.
	 */
	public function get_specific_stats( $stats_data ) {
		$theme_data = $this->get_active_theme();

		$plugin_data                   = is_array( $stats_data['plugin_data'] ) ? $stats_data['plugin_data'] : array();
		$modern_cart                   = $this->get_default_stats( $theme_data );
		$modern_cart['boolean_values'] = $this->get_boolean_values();
		$plugin_data['modern_cart']    = $modern_cart;
		$stats_data['plugin_data']     = $plugin_data;

		/**
		 * Allows Pro (or other extensions) to append additional stats.
		 * Mirrors the same filter fired by Modern_Cart_Analytics in Free >= 1.0.7.
		 *
		 * @since 1.2.5
		 *
		 * @param array<string, mixed> $stats_data Stats array with free data already set.
		 */
		$stats_data = apply_filters( 'modern_cart_get_specific_stats', $stats_data );

		return $stats_data;
	}

	/**
	 * Get default (free-feature) stats.
	 *
	 * Mirrors Modern_Cart_Analytics::get_default_stats() from Free 1.0.7.
	 * Reads values directly from plugin options — no counters are written.
	 *
	 * @since 1.2.5
	 *
	 * @param array<string, mixed> $theme_data Active theme data from get_active_theme().
	 * @return array<string, mixed> Default stats array.
	 */
	public function get_default_stats( $theme_data ) {
		$main_settings     = (array) get_option( MODERNCART_MAIN_SETTINGS, array() );
		$cart_settings     = (array) get_option( MODERNCART_SETTINGS, array() );
		$floating_settings = (array) get_option( MODERNCART_FLOATING_SETTINGS, array() );

		return array(
			'website-domain'              => str_ireplace( array( 'http://', 'https://' ), '', home_url() ),
			'moderncart-version'          => defined( 'MODERNCART_VER' ) ? MODERNCART_VER : '',
			'moderncart-pro-version'      => defined( 'MODERNCART_PRO_VER' ) ? MODERNCART_PRO_VER : '',
			'locale'                      => get_locale(),
			'active-theme'                => $theme_data['parent_theme'],
			'enable_moderncart'           => ! empty( $main_settings['enable_moderncart'] ) ? $main_settings['enable_moderncart'] : '',
			'cart_style'                  => ! empty( $cart_settings['cart_theme_style'] ) ? $cart_settings['cart_theme_style'] : '',
			'product_image_size'          => ! empty( $cart_settings['product_image_size'] ) ? $cart_settings['product_image_size'] : '',
			'section_styling'             => ! empty( $cart_settings['section_styling'] ) ? $cart_settings['section_styling'] : '',
			'floating_cart_position'      => ! empty( $floating_settings['floating_cart_position'] ) ? $floating_settings['floating_cart_position'] : '',
			'product_recommendation_type' => ! empty( $cart_settings['recommendation_types'] ) ? $cart_settings['recommendation_types'] : '',
			'empty_cart_recommendation'   => ! empty( $cart_settings['empty_cart_recommendation'] ) ? $cart_settings['empty_cart_recommendation'] : '',
			'cart_type'                   => ! empty( $cart_settings['cart_type'] ) ? $cart_settings['cart_type'] : '',
			'cart_header_style'           => ! empty( $cart_settings['cart_header_style'] ) ? $cart_settings['cart_header_style'] : '',
			'recommendation_types'        => ! empty( $cart_settings['recommendation_types'] ) ? $cart_settings['recommendation_types'] : '',
			'order_summary_style'         => ! empty( $cart_settings['order_summary_style'] ) ? $cart_settings['order_summary_style'] : '',
			'nps-survey-status'           => get_option( 'nps-survey-modern-cart-for-woocommerce', array() ),
			'cart_auto_open_behavior'     => ! empty( $cart_settings['cart_auto_open_behavior'] ) ? $cart_settings['cart_auto_open_behavior'] : '',
			'nps-library-version'         => defined( 'NPS_SURVEY_VER' ) ? NPS_SURVEY_VER : '',
		);
	}

	/**
	 * Get boolean feature-flag stats for free features.
	 *
	 * Mirrors Modern_Cart_Analytics::get_boolean_values() from Free 1.0.7.
	 *
	 * @since 1.2.5
	 *
	 * @return array<string, bool> Boolean feature flag stats.
	 */
	public function get_boolean_values() {
		$main_settings     = (array) get_option( MODERNCART_MAIN_SETTINGS, array() );
		$cart_settings     = (array) get_option( MODERNCART_SETTINGS, array() );
		$floating_settings = (array) get_option( MODERNCART_FLOATING_SETTINGS, array() );

		$floating_cart_icon = ! empty( $floating_settings['floating_cart_icon'] ) ? $floating_settings['floating_cart_icon'] : '';

		return array(
			'enabled_free_shipping_bar' => ! empty( $main_settings['enable_free_shipping_bar'] ) && true === boolval( $main_settings['enable_free_shipping_bar'] ),
			'enabled_coupon_field'      => ! empty( $cart_settings['enable_coupon_field'] ) && 'disabled' !== $cart_settings['enable_coupon_field'],
			'enabled_ajax_add_to_cart'  => ! empty( $main_settings['enable_ajax_add_to_cart'] ) && true === boolval( $main_settings['enable_ajax_add_to_cart'] ),
			'enabled_express_checkout'  => ! empty( $main_settings['enable_express_checkout'] ) && true === boolval( $main_settings['enable_express_checkout'] ),
			'enabled_powered_by'        => ! empty( $main_settings['enable_powered_by'] ) && true === boolval( $main_settings['enable_powered_by'] ),
			'enable_shipping'           => ! empty( $cart_settings['enable_shipping'] ) && true === boolval( $cart_settings['enable_shipping'] ),
			'is_using_custom_cart_icon' => ! empty( $floating_settings['custom_cart_icon_url'] ) && 'custom' === $floating_cart_icon,
			'is_using_custom_trigger'   => ! empty( $floating_settings['custom_trigger_selectors'] ),
		);
	}

	/**
	 * Retrieve the active theme names.
	 *
	 * Mirrors Modern_Cart_Analytics::get_active_theme() from Free 1.0.7.
	 *
	 * @since 1.2.5
	 *
	 * @return array{parent_theme: string, child_theme: bool}
	 */
	public function get_active_theme() {
		$theme             = wp_get_theme();
		$parent_theme_name = '';
		$child_theme_name  = '';

		if ( isset( $theme->parent_theme ) && ! empty( $theme->parent_theme ) ) {
			$parent_theme_name = $theme->parent_theme;
			$child_theme_name  = $theme->name ? $theme->name : '';
		} else {
			$parent_theme_name = $theme->name;
		}

		return array(
			'parent_theme' => ! empty( $child_theme_name ) ? $child_theme_name : $parent_theme_name,
			'child_theme'  => ! empty( $child_theme_name ) ? true : false,
		);
	}

	/**
	 * Register the enable_usage_tracking default value in MODERNCART_SETTINGS.
	 *
	 * Hooked to `moderncart_default_settings` — the same filter the Free plugin
	 * uses internally to seed its option defaults. Ensures the analytics toggle
	 * key exists in the options array even when Free < 1.0.7 did not define it.
	 *
	 * @since 1.2.5
	 *
	 * @param array<string, mixed> $default_settings Default settings map.
	 * @return array<string, mixed> Settings map with analytics default added.
	 */
	public function register_analytics_default( $default_settings ) {
		$moderncart_opts = isset( $default_settings[ MODERNCART_SETTINGS ] ) && is_array( $default_settings[ MODERNCART_SETTINGS ] )
			? $default_settings[ MODERNCART_SETTINGS ]
			: array();

		if ( ! isset( $moderncart_opts['enable_usage_tracking'] ) ) {
			$moderncart_opts['enable_usage_tracking'] = false;
			$default_settings[ MODERNCART_SETTINGS ]  = $moderncart_opts;
		}

		return $default_settings;
	}

	/**
	 * Inject the Enable Usage Tracking toggle into the settings fields.
	 *
	 * Hooked to `moderncart_settings_fields` so the toggle appears in the
	 * General settings tab. Free >= 1.0.7 ships this field itself; this method
	 * only runs when Free is absent or older than 1.0.7 (Condition 3).
	 *
	 * @since 1.2.5
	 *
	 * @param array<string, mixed> $fields Existing settings fields.
	 * @return array<string, mixed> Fields with the analytics toggle added.
	 */
	public function add_analytics_settings_field( $fields ) {
		if ( ! isset( $fields['moderncart_setting'] ) || ! is_array( $fields['moderncart_setting'] ) ) {
			return $fields;
		}

		$fields['moderncart_setting']['moderncart_cart_enable_usage_tracking'] = array(
			'type'        => 'toggle',
			'label'       => __( 'Enable Usage Tracking', 'modern-cart-woo' ),
			'description' => __( 'Allow Modern Cart to collect non-sensitive usage data to help improve the plugin. No personal data is collected.', 'modern-cart-woo' ),
			'name'        => 'moderncart_cart[enable_usage_tracking]',
			'priority'    => 100,
		);

		return $fields;
	}
}

Modern_Cart_Legacy_Analytics::get_instance();
