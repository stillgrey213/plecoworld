<?php
/**
 * Cart.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Inc;

use ModernCart_Pro\Inc\Traits\Get_Instance;
use WC_Shipping_Zones;

/**
 * Admin menu
 *
 * @since 1.0.0
 */
class Cart {
	use Get_Instance;

	/**
	 * Set a notification for rendering in HTML.
	 *
	 * @since 1.0.0
	 *
	 * @param string $option Option name.
	 * @param string $section Option section.
	 * @param mixed  $default Default value.
	 *
	 * @return mixed
	 */
	public function get_option( $option, $section, $default = '' ) {
		$options = get_option( $section );
		$helper  = Helper::get_instance();

		if ( is_array( $options ) && isset( $options[ $option ] ) ) {
			return '' === $options[ $option ] ? $default : $options[ $option ];
		}

		if ( empty( $default ) && isset( $helper->get_option( $section )[ $option ] ) ) {
			return $helper->get_option( $section )[ $option ];
		}

		return $default;
	}

	/**
	 * Set a notification for rendering in HTML.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function is_global_enabled() {
		if ( Helper::is_nav_menu_widget_render_request() ) {
			return false;
		}

		$enabled = $this->get_option( 'enable_moderncart', MODERNCART_MAIN_SETTINGS, 'all' );

		if ( 'disabled' === $enabled ) {
			return false;
		}

		if ( 'all' === $enabled && ! is_checkout() ) {
			return true;
		}

		if ( is_shop() || is_product() || is_cart() ) {
			return true;
		}

		return false;
	}

	/**
	 * Shipping line item
	 *
	 * @since 1.0.0
	 *
	 * @param bool $wrapper If true, wrap the value in a div.
	 *
	 * @return string
	 */
	public function get_shipping_html( $wrapper = true ) {
		if ( ! $this->get_option( 'enable_shipping', MODERNCART_SETTINGS, false ) ) {
			return '';
		}

		$html  = '';
		$value = '';
		$label = esc_html__( 'Shipping', 'modern-cart-woo' );
		WC()->cart->calculate_shipping();
		$packages = WC()->shipping()->get_packages();

		if ( ! empty( $packages ) ) {
			$package           = $packages[0];
			$available_methods = $package['rates'];

			if ( $available_methods ) {
				$value = WC()->cart->get_cart_shipping_total();
			}

			if ( '' === $value ) {
				return '';
			}

			if ( ! $wrapper ) {
				return $value;
			}

			$html = $this->get_single_item(
				$label,
				apply_filters( 'moderncart_cart_totals_shipping_html', $value ),
				'shipping'
			);
		}

		return $html;
	}

	/**
	 * Get the cart vat without shipping.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $wrapper If true, wrap the value in a div.
	 *
	 * @return string
	 */
	public function get_tax_html( $wrapper = true ) {
		if ( ! $this->get_option( 'enable_tax', MODERNCART_SETTINGS, false ) ) {
			return '';
		}

		$label = '';
		$value = '';

		if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) {
			foreach ( WC()->cart->get_tax_totals() as $tax ) {
				$label .= $tax->label;
				$value .= wp_kses_post( wc_price( $tax->amount ) );
			}
		} else {
			$label .= esc_html( WC()->countries->tax_or_vat() );
			$value .= wc_price( WC()->cart->get_taxes_total( false, false ) );
		}

		if ( '' === $value ) {
			return '';
		}

		if ( ! $wrapper ) {
			return $value;
		}

		return $this->get_single_item(
			$label,
			apply_filters( 'moderncart_cart_totals_vat_total_html', $value ),
			'tax'
		);
	}

	/**
	 * Get the cart subtotal.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $wrapper If true, wrap the value in a div.
	 *
	 * @return string
	 */
	public function get_subtotal_html( $wrapper = true ) {
		if ( ! $this->get_option( 'enable_subtotal', MODERNCART_SETTINGS, true ) || empty( WC()->cart->get_cart() ) ) {
			return '';
		}

		$label = esc_html__( 'Subtotal', 'modern-cart-woo' );
		$value = WC()->cart->get_cart_subtotal();

		if ( ! $wrapper ) {
			return $value;
		}

		return $this->get_single_item(
			$label,
			apply_filters( 'moderncart_cart_totals_subtotal_html', $value ),
			'subtotal'
		);
	}

	/**
	 * Get the cart discount.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $wrapper If true, wrap the value in a div.
	 *
	 * @return string
	 */
	public function get_discount_html( $wrapper = true ) {
		if ( ! $this->get_option( 'enable_discount', MODERNCART_SETTINGS, false ) ) {
			return '';
		}

		$label          = esc_html__( 'Discount', 'modern-cart-woo' );
		$discount_total = WC()->cart->get_cart_discount_total();
		$value          = wc_price( $discount_total );
		$html           = '';

		if ( $discount_total > 0 ) {
			if ( ! $wrapper ) {
				return $value;
			}
			$html = $this->get_single_item(
				$label,
				apply_filters( 'moderncart_cart_totals_discount_total_html', $value ),
				'discount'
			);
		}

		return $html;
	}

	/**
	 * Get the cart total without shipping.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $wrapper If true, wrap the value in a div.
	 *
	 * @return string
	 */
	public function get_total_html( $wrapper = true ) {
		if ( ! $this->get_option( 'enable_total', MODERNCART_SETTINGS, false ) ) {
			return '';
		}

		$cart                   = WC()->cart;
		$enable_shipping        = $this->get_option( 'enable_shipping', MODERNCART_SETTINGS, false );
		$label                  = esc_html__( 'Total', 'modern-cart-woo' );
		$cart_total             = (float) $cart->get_total( 'number' );
		$shipping               = $this->get_shipping_totals();
		$shipping_total         = $shipping->total ?? '';
		$shipping_tax_total     = $shipping->tax_total ?? '';
		$total_without_discount = $cart->get_subtotal() + $cart->get_total_tax() + $cart->get_fee_total() + $shipping_total;
		$total_without_shipping = $cart_total - $shipping_total - $shipping_tax_total;

		if ( $enable_shipping ) {
			$value = '<strong>' . wc_price( $cart_total ) . '</strong> ';
		} else {
			$value = '<strong>' . wc_price( $total_without_shipping ) . '</strong> ';
		}

		if ( wc_tax_enabled() && $cart->display_prices_including_tax() ) {
			$tax_string_array = [];
			$cart_tax_totals  = $cart->get_tax_totals();

			if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) {
				foreach ( $cart_tax_totals as $tax ) {
					$tax_string_array[] = sprintf( '%s %s', wc_price( $tax->amount - $shipping_tax_total ), $tax->label );
				}
			} elseif ( ! empty( $cart_tax_totals ) ) {
				$tax_string_array[] = sprintf( '%s %s', wc_price( $cart->get_taxes_total( true, false ) - $shipping_tax_total ), WC()->countries->tax_or_vat() );
			}

			if ( ! empty( $tax_string_array ) ) {
				$taxable_address = WC()->customer->get_taxable_address();
				// translators: %s: taxable address.
				$estimated_text = ( WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ? sprintf( ' ' . esc_html__( 'estimated for %s', 'modern-cart-woo' ), WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->get_countries()[ $taxable_address[0] ] ) : '' );
				/* translators: %s: tax amount */
				$value .= '<small class="includes_tax">' . sprintf( esc_html__( '(includes %s)', 'modern-cart-woo' ), implode( ', ', $tax_string_array ) . $estimated_text ) . '</small>';
			}
		}

		if ( WC()->cart->has_discount() ) {
			$value .= '<del class="moderncart-cart-discount">' . wc_price( $total_without_discount ) . '</del>';
		}

		if ( ! $wrapper ) {
			return $value;
		}

		return $this->get_single_item(
			$label,
			apply_filters( 'moderncart_cart_totals_order_total_html', $value ),
			'total'
		);
	}

	/**
	 * Creates a single line item.
	 *
	 * @since 1.0.0
	 *
	 * @param string $label The label.
	 * @param string $value The value.
	 * @param string $type Iteam type.
	 *
	 * @return string
	 */
	public function get_single_item( $label, $value, $type = 'item' ) {
		$html    = '';
		$classes = apply_filters( 'moderncart_single_line_item_classes', [ 'moderncart-cart-line-items-item', 'moderncart-cart-line-items__' . $type ] );

		// Define ARIA labels based on type.
		$aria_labels = [
			'subtotal' => __( 'Cart Subtotal', 'modern-cart-woo' ),
			'shipping' => __( 'Shipping Cost', 'modern-cart-woo' ),
			'tax'      => __( 'Tax Amount', 'modern-cart-woo' ),
			'discount' => __( 'Discount Amount', 'modern-cart-woo' ),
			'total'    => __( 'Cart Total', 'modern-cart-woo' ),
		];

		$aria_label = $aria_labels[ $type ] ?? $label;

		$html .= '<div class="' . esc_attr( implode( ' ', array_filter( $classes ) ) ) . '" role="row" aria-label="' . esc_attr( $aria_label ) . '" aria-live="polite" aria-atomic="true" >';

		// Add label with screen reader text.
		$html .= '<span class="moderncart-cart-line-items-label moderncart-cart-line-items__' . esc_attr( $type ) . '-label" role="cell">';
		$html .= '<span class="screen-reader-text">' . esc_html( $aria_label ) . ': </span>';
		$html .= esc_html( $label );
		$html .= '</span>';
		/* translators: %1$s: field label , %2$s: field value */
		$html .= '<span class="moderncart-cart-line-items-value moderncart-cart-line-items__' . esc_attr( $type ) . '-value" role="cell" aria-label="' . esc_attr( sprintf( __( '%1$s: %2$s', 'modern-cart-woo' ), $aria_label, wp_strip_all_tags( $value ) ) ) . '">';
		$html .= wp_kses_post( $value );
		$html .= '</span>';

		$html .= '</div>';
		return $html;
	}

	/**
	 * Check package to destination if is a returning customer.
	 *
	 * @since 1.0.0
	 *
	 * @param array $package Shipping package.
	 * @phpstan-param array{
	 *     destination?: array{
	 *         country?: string,
	 *         state?: string,
	 *         postcode?: string,
	 *         city?: string
	 *     }
	 * } $package
	 *
	 * @return bool
	 */
	public function is_destination_exists( $package = [] ) {
		$country  = $package['destination']['country'] ?? null;
		$state    = $package['destination']['state'] ?? null;
		$postcode = $package['destination']['postcode'] ?? null;
		$city     = $package['destination']['city'] ?? null;
		$exists   = true;

		if ( 'AF' === $country && ! $city ) {
			$country = null;
		}
		if ( ! $country && ! $state && ! $postcode ) {
			$exists = false;
		}

		return $exists;
	}

	/**
	 * Get minimum amount for free shipping.
	 *
	 * @since 1.0.0
	 *
	 * @return int
	 */
	public function get_free_shipping_amount() {
		if ( WC()->cart->is_empty() ) {
			// Check if cart is empty or not before processing.
			return 0;
		}

		$amount         = null;
		$initial_zone   = 1;
		$amount         = null;
		$cart           = WC()->cart;
		$packages       = $cart->get_shipping_packages();
		$package        = reset( $packages );
		$zone           = wc_get_shipping_zone( $package );
		$known_customer = $this->is_destination_exists( $package );

		if ( ! $known_customer ) {
			$init_zone = WC_Shipping_Zones::get_zone_by( 'zone_id', $initial_zone );
			$zone      = $init_zone instanceof \WC_Shipping_Zone ? $init_zone : $zone;
		}

		foreach ( $zone->get_shipping_methods( true ) as $method ) {
			if ( 'free_shipping' !== $method->id ) {
				continue;
			}

			$instance = $method->instance_settings ?? null;
			$amount   = isset( $instance['min_amount'] ) && ! empty( $instance['requires'] ) && 'coupon' !== $instance['requires'] ? $instance['min_amount'] : null;
		}

		return apply_filters( 'moderncart_free_shipping_min_amount', $amount );
	}

	/**
	 * Renders the powered by partial.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_poweredby(): void {
		if ( ! $this->get_option( 'enable_powered_by', MODERNCART_MAIN_SETTINGS, false ) ) {
			return;
		}

		$data = [
			'classes' => apply_filters( 'moderncart_powered_by_classes', [ 'moderncart-powered-by' ] ),
			'url'     => esc_url( 'https://cartflows.com/' ),
		];

		moderncart_get_template_part( 'cart/powered-by', '', $data );
	}

	/**
	 * Renders the free shipping bar.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_free_shipping_bar(): void {
		if ( ! $this->get_option( 'enable_free_shipping_bar', MODERNCART_MAIN_SETTINGS, false ) ) {
			return;
		}

		$amount_free_shipping = $this->get_free_shipping_amount();

		if ( ! $amount_free_shipping ) {
			return;
		}

		$cart_total          = (float) WC()->cart->get_displayed_subtotal();
		$discount            = WC()->cart->get_discount_total();
		$discount_tax        = WC()->cart->get_discount_tax();
		$price_including_tax = WC()->cart->display_prices_including_tax();
		$price_decimal       = wc_get_price_decimals();

		if ( $price_including_tax ) {
			$cart_total = round( $cart_total - ( $discount + $discount_tax ), $price_decimal );
		} else {
			$cart_total = round( $cart_total - $discount, $price_decimal );
		}

		$remaining = $amount_free_shipping - $cart_total;
		$percent   = 100 - ( $remaining / $amount_free_shipping ) * 100;
		$content   = Helper::convert_to_string( $this->get_option( 'free_shipping_bar_text', MODERNCART_SETTINGS, __( 'You\'re {amount} away from free shipping!', 'modern-cart-woo' ) ) );

		if ( $cart_total >= $amount_free_shipping ) {
			return;
		}

		$data = [
			'content' => str_replace( '{amount}', wc_price( $remaining ), $content ),
			'percent' => $percent,
		];

		moderncart_get_template_part( 'cart/free-shipping-bar', '', $data );
	}

	/**
	 * Get shipping information.
	 *
	 * @since 1.0.0
	 *
	 * @return object
	 */
	private function get_shipping_totals() {
		$cart     = WC()->cart;
		$shipping = [
			'total'     => (float) $cart->get_shipping_total(),
			'tax_total' => isset( $cart->shipping_tax_total ) ? (float) $cart->shipping_tax_total : '',
		];
		return (object) $shipping;
	}
}
