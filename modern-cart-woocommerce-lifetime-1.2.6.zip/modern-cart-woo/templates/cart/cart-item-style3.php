<?php
/**
 * Modern Cart Woo Cart Item
 *
 * @package modern-cart-woo
 * @version 1.0.4
 */

use ModernCart\Inc\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$args                = array(
	'cart_item_key' => $cart_item_key,
	'cart_item'     => $cart_item,
	'product'       => $product,
);
$allow_wp_kses       = Helper::get_allowed_tags_kses( 'common' );
$img_wp_kses         = Helper::get_allowed_tags_kses( 'img' );
$allow_quantity_kses = Helper::get_allowed_tags_kses( 'quantity' );
?>

<div class="<?php echo esc_attr( implode( ' ', array_filter( $classes ) ) ); ?> moderncart-cart-item-<?php echo esc_attr( $cart_item_key ); ?>" data-key="<?php echo esc_attr( $cart_item_key ); ?>"  role="row">

	<div class="moderncart-cart-item-container" role="cell">

			<div class="moderncart-cart-item-image">
				<?php if ( $product_permalink ) : ?>
					<a href="<?php echo esc_url( $product_permalink ); ?>" aria-label="
										<?php
										/* translators: %s: product name */
										echo esc_attr( sprintf( __( 'View %s product page', 'modern-cart-woo' ), wp_strip_all_tags( $product_name ) ) );
										?>
						">
				<?php endif; ?>

				<?php if ( $thumbnail ) : ?>
					<?php echo wp_kses( $thumbnail, $img_wp_kses ); ?>
				<?php endif; ?>
				<?php if ( $product->is_on_sale() ) : ?>
						<span class="moderncart-cart-item-onsale">Sale!</span>
						<?php endif; ?>
				<?php if ( $product_permalink ) : ?>
					</a>
				<?php endif; ?>
			</div>

		<div class="moderncart-cart-item-product">

			<div class="moderncart-cart-item__details">
				<div class="moderncart-cart-item-product-name" role="heading" aria-level="3"><?php echo wp_kses( $product_name, $allow_wp_kses ); ?></div>
			</div>

			<?php if ( $quantity ) : ?>
				<?php echo wp_kses( $quantity, $allow_quantity_kses ); ?>
			<?php endif; ?>
		</div>
	</div>

	<div class="moderncart-cart-item-actions">
		<?php if ( $product_subtotal ) : ?>
			<?php moderncart_get_template_part( 'cart/price', '', $args ); ?>
		<?php endif; ?>
		<?php if ( $delete ) : ?>
			<button aria-label="<?php esc_attr_e( 'Remove Item From Cart', 'modern-cart-woo' ); ?>" class="moderncart-cart-item-actions-remove" data-key="<?php echo esc_attr( $cart_item_key ); ?>">
				<svg width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg" aria-labelledby="closeIconTitle">
					<path d="M6.18182 7.125V13.875C6.18182 13.9844 6.1456 14.0742 6.07315 14.1445C6.00071 14.2148 5.90814 14.25 5.79545 14.25H5.02273C4.91004 14.25 4.81747 14.2148 4.74503 14.1445C4.67259 14.0742 4.63636 13.9844 4.63636 13.875V7.125C4.63636 7.01562 4.67259 6.92578 4.74503 6.85547C4.81747 6.78516 4.91004 6.75 5.02273 6.75H5.79545C5.90814 6.75 6.00071 6.78516 6.07315 6.85547C6.1456 6.92578 6.18182 7.01562 6.18182 7.125ZM9.27273 7.125V13.875C9.27273 13.9844 9.23651 14.0742 9.16406 14.1445C9.09162 14.2148 8.99905 14.25 8.88636 14.25H8.11364C8.00095 14.25 7.90838 14.2148 7.83594 14.1445C7.76349 14.0742 7.72727 13.9844 7.72727 13.875V7.125C7.72727 7.01562 7.76349 6.92578 7.83594 6.85547C7.90838 6.78516 8.00095 6.75 8.11364 6.75H8.88636C8.99905 6.75 9.09162 6.78516 9.16406 6.85547C9.23651 6.92578 9.27273 7.01562 9.27273 7.125ZM12.3636 7.125V13.875C12.3636 13.9844 12.3274 14.0742 12.255 14.1445C12.1825 14.2148 12.09 14.25 11.9773 14.25H11.2045C11.0919 14.25 10.9993 14.2148 10.9268 14.1445C10.8544 14.0742 10.8182 13.9844 10.8182 13.875V7.125C10.8182 7.01562 10.8544 6.92578 10.9268 6.85547C10.9993 6.78516 11.0919 6.75 11.2045 6.75H11.9773C12.09 6.75 12.1825 6.78516 12.255 6.85547C12.3274 6.92578 12.3636 7.01562 12.3636 7.125ZM13.9091 15.6094V4.5H3.09091V15.6094C3.09091 15.7812 3.11908 15.9395 3.17543 16.084C3.23177 16.2285 3.29013 16.334 3.3505 16.4004C3.41087 16.4668 3.45312 16.5 3.47727 16.5H13.5227C13.5469 16.5 13.5891 16.4668 13.6495 16.4004C13.7099 16.334 13.7682 16.2285 13.8246 16.084C13.8809 15.9395 13.9091 15.7812 13.9091 15.6094ZM5.79545 3H11.2045L10.625 1.62891C10.5687 1.55859 10.5002 1.51562 10.4197 1.5H6.59233C6.51184 1.51562 6.44342 1.55859 6.38707 1.62891L5.79545 3ZM17 3.375V4.125C17 4.23438 16.9638 4.32422 16.8913 4.39453C16.8189 4.46484 16.7263 4.5 16.6136 4.5H15.4545V15.6094C15.4545 16.2578 15.2654 16.8184 14.8871 17.291C14.5088 17.7637 14.054 18 13.5227 18H3.47727C2.94602 18 2.49124 17.7715 2.11293 17.3145C1.73461 16.8574 1.54545 16.3047 1.54545 15.6562V4.5H0.386364C0.273674 4.5 0.181108 4.46484 0.108665 4.39453C0.0362216 4.32422 0 4.23438 0 4.125V3.375C0 3.26562 0.0362216 3.17578 0.108665 3.10547C0.181108 3.03516 0.273674 3 0.386364 3H4.11719L4.96236 1.04297C5.0831 0.753906 5.30043 0.507812 5.61435 0.304688C5.92827 0.101562 6.24621 0 6.56818 0H10.4318C10.7538 0 11.0717 0.101562 11.3857 0.304688C11.6996 0.507812 11.9169 0.753906 12.0376 1.04297L12.8828 3H16.6136C16.7263 3 16.8189 3.03516 16.8913 3.10547C16.9638 3.17578 17 3.26562 17 3.375Z" fill="#5C5767"/>
				</svg>
			</button>
		<?php endif; ?>
	</div>		
</div>
