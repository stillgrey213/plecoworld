( function ( $ ) {
	const ModernCart_ProAdminNotice = {
		/**
		 * Init
		 */
		init() {
			this._bind();
		},

		/**
		 * Binds events
		 */
		_bind() {
			$( document ).on(
				'click',
				'.modern-cart-dismissible-license-notice .notice-dismiss',
				ModernCart_ProAdminNotice.disable_license_admin_notice
			);
		},

		/**
		 * Import
		 *
		 * @param {Object} event event data.
		 */
		disable_license_admin_notice( event ) {
			event.preventDefault();
			$.ajax( {
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'modern_cart_disable_activate_license_notice',
					security: ModernCart_ProAdminNoticeVars._nonce,
				},
			} )
				.done( function () {} )
				.fail( function () {} )
				.always( function () {} );
		},
	};

	/**
	 * Initialization
	 */
	$( function () {
		ModernCart_ProAdminNotice.init();
	} );
} )( jQuery );
