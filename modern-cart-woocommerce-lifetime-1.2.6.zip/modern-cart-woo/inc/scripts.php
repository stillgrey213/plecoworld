<?php
/**
 * Scripts.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Inc;

use ModernCart\Inc\Helper;
use ModernCart_Pro\Inc\Traits\Get_Instance;
use ModernCart_Pro\Inc\Cart;

/**
 * Scripts
 *
 * @since 1.0.0
 */
class Scripts extends Cart {
	use Get_Instance;

	/**
	 * Plugin version.
	 *
	 * @var string $version Current plugin version.
	 */
	public $version;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// @phpstan-ignore-next-line - Debug condition can be overridden
		$this->version = defined( 'MODERNCART_PRO_DEBUG' ) && MODERNCART_PRO_DEBUG ? (string) time() . '-' . MODERNCART_PRO_VER : MODERNCART_PRO_VER;
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_filter( 'moderncart_css_vars', [ $this, 'add_css_vars' ] );
		add_filter( 'moderncart_localize_script_args', [ $this, 'localize_script_args' ] );
	}

	/**
	 * Add or override dynamic CSS variables for the Pro version.
	 *
	 * This method extends the default Modern Cart CSS variables with additional or
	 * overridden values specific to the Pro version, such as popup and slide-out
	 * cart widths, floating icon styles, and appearance settings. These variables
	 * are used to dynamically style the cart and related UI components on the frontend.
	 *
	 * @since 1.2.0
	 *
	 * @param array<string, mixed> $css_vars Existing CSS variables.
	 * @return array<string, mixed> Modified CSS variables including Pro-specific values.
	 */
	public function add_css_vars( array $css_vars ): array {
		$popup_desktop_width       = $this->get_option( 'popup_width_desktop', MODERNCART_SETTINGS, 40 );
		$popup_desktop_width       = $popup_desktop_width > 100 ? 100 : Helper::convert_to_int( $popup_desktop_width );
		$popup_desktop_margin_left = ( 100 - $popup_desktop_width ) / 2;
		$popup_mobile_width        = $this->get_option( 'popup_width_mobile', MODERNCART_SETTINGS, 80 );
		$popup_mobile_width        = $popup_mobile_width > 100 ? 100 : Helper::convert_to_int( $popup_mobile_width );
		$popup_mobile_margin_left  = ( 100 - $popup_mobile_width ) / 2;

		return array_merge(
			$css_vars,
			[
				'--moderncart-popup-desktop-width'         => $popup_desktop_width . '%',
				'--moderncart-popup-desktop-margin-left'   => $popup_desktop_margin_left . '%',
				'--moderncart-popup-mobile-width'          => $popup_mobile_width . '%',
				'--moderncart-popup-mobile-margin-left'    => $popup_mobile_margin_left . '%',
				'--moderncart-slide-out-desktop-width'     => $this->get_option( 'slide_out_width_desktop', MODERNCART_SETTINGS, 450 ) . 'px',
				'--moderncart-slide-out-mobile-width'      => $this->get_option( 'slide_out_width_mobile', MODERNCART_SETTINGS, 80 ) . '%',
				'--moderncart-floating-icon-width'         => $this->get_option( 'icon_width', MODERNCART_FLOATING_SETTINGS, 60 ) . 'px',
				'--moderncart-floating-icon-border-radius' => $this->get_option( 'icon_border_radius', MODERNCART_FLOATING_SETTINGS, 200 ) . 'px',
				'--moderncart-background-color'            => Helper::convert_to_string( $this->get_option( 'background_color', MODERNCART_APPEARANCE_SETTINGS ) ),
				'--moderncart-header-font-color'           => Helper::convert_to_string( $this->get_option( 'header_font_color', MODERNCART_APPEARANCE_SETTINGS ) ),
				'--moderncart-header-background-color'     => Helper::convert_to_string( $this->get_option( 'header_background_color', MODERNCART_APPEARANCE_SETTINGS ) ),
				'--moderncart-quantity-font-color'         => Helper::convert_to_string( $this->get_option( 'quantity_font_color', MODERNCART_APPEARANCE_SETTINGS ) ),
				'--moderncart-quantity-background-color'   => Helper::convert_to_string( $this->get_option( 'quantity_background_color', MODERNCART_APPEARANCE_SETTINGS ) ),
				'--moderncart-floating-icon-color'         => Helper::convert_to_string( $this->get_option( 'icon_color', MODERNCART_FLOATING_SETTINGS ) ),
				'--moderncart-floating-icon-bg-color'      => Helper::convert_to_string( $this->get_option( 'icon_background_color', MODERNCART_FLOATING_SETTINGS ) ),
				'--moderncart-floating-count-text-color'   => Helper::convert_to_string( $this->get_option( 'count_text_color', MODERNCART_FLOATING_SETTINGS ) ),
				'--moderncart-floating-count-bg-color'     => Helper::convert_to_string( $this->get_option( 'count_background_color', MODERNCART_FLOATING_SETTINGS ) ),
			]
		);
	}

	/**
	 * Add or override localized script arguments for the Pro version.
	 *
	 * This method extends the default localized script arguments with additional
	 * or overridden settings specific to the Pro version of Modern Cart.
	 *
	 * @since 1.2.0
	 *
	 * @param array<string, mixed> $args The existing localized script arguments.
	 * @return array<string, mixed> Modified localized script arguments.
	 */
	public function localize_script_args( array $args ): array {
		return array_merge(
			$args,
			[
				'recommendation_types'                => $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ),
				'recommendation_list_style'           => $this->get_option( 'recommendation_list_style', MODERNCART_SETTINGS, 'style1' ),
				'custom_trigger_selectors'            => $this->get_option( 'custom_trigger_selectors', MODERNCART_FLOATING_SETTINGS, '' ),
				'cart_auto_open_behavior'             => $this->get_option( 'cart_auto_open_behavior', MODERNCART_SETTINGS, 'show-cart-on-first-add' ),
				'enable_product_image_in_mobile_view' => $this->get_option( 'enable_product_image_in_mobile_view', MODERNCART_SETTINGS, false ),
				'cart_opening_direction'              => $this->get_option( 'cart_opening_direction', MODERNCART_SETTINGS, 'right' ),
			]
		);
	}

	/**
	 * Enqueue scripts
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		if ( ! $this->is_global_enabled() ) {
			return;
		}

		// Enqueue recommendations slide CSS if recommendations are enabled.
		if ( 'disabled' !== $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ) ) {
			$css_file = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? 'assets/css/recommendations-slide.css' : 'assets/min-css/recommendations-slide.min.css';
			wp_register_style( 'moderncart-recommendations-slide-css', MODERNCART_PRO_URL . $css_file, [ 'moderncart-cart-css' ], $this->version );
			wp_enqueue_style( 'moderncart-recommendations-slide-css' );
		}

		// Only load Splide assets when using slider style for recommendations.
		$recommendation_list_style = $this->get_option( 'recommendation_list_style', MODERNCART_SETTINGS, 'style1' );
		if ( ( 'disabled' !== $this->get_option( 'recommendation_types', MODERNCART_SETTINGS, 'disabled' ) && 'style1' === $recommendation_list_style ) || 'disabled' !== $this->get_option( 'empty_cart_recommendation', MODERNCART_SETTINGS, 'disabled' ) ) {
			wp_register_style( 'moderncart-splide-css', MODERNCART_PRO_URL . 'assets/css/splide.min.css', [], $this->version );
			wp_enqueue_style( 'moderncart-splide-css' );

			wp_register_script( 'moderncart-splide-js', MODERNCART_PRO_URL . 'assets/js/splide.min.js', [ 'jquery' ], $this->version, true );
			wp_enqueue_script( 'moderncart-splide-js' );
		}
	}
}
