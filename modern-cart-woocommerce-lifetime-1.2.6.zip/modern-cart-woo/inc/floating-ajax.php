<?php
/**
 * Floating cart ajax.
 *
 * @package modern-cart-woo
 * @since 1.0.0
 */

namespace ModernCart_Pro\Inc;

use ModernCart\Inc\Floating;
use ModernCart\Inc\Helper;
use ModernCart_Pro\Inc\Traits\Get_Instance;

/**
 * Floating cart ajax class
 *
 * @since 1.0.0
 */
class Floating_Ajax extends Floating {
	use Get_Instance;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_moderncart_refresh_floating_cart', [ $this, 'refresh_floating_cart' ] );
		add_action( 'wp_ajax_nopriv_moderncart_refresh_floating_cart', [ $this, 'refresh_floating_cart' ] );
	}

	/**
	 * Refresh slide out cart
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function refresh_floating_cart(): void {
		if ( ! isset( $_POST['moderncart_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( $_POST['moderncart_nonce'] ), 'moderncart_ajax_nonce' ) ) {
			return;
		}

		if ( ! $this->get_option( 'display_floating_cart_icon', MODERNCART_FLOATING_SETTINGS, '1' ) ) {
			return;
		}

		$hide_if_empty  = $this->get_option( 'enable_floating_if_empty', MODERNCART_FLOATING_SETTINGS, '0' );
		$cart_count     = Helper::get_cart_count();
		$cart_icon      = $this->get_option( 'floating_cart_icon', MODERNCART_FLOATING_SETTINGS, '0' );
		$cart_svg_icons = Helper::get_cart_icons();

		$data = [
			'classes'        => apply_filters( 'moderncart_floating_cart_launcher_classes', [ 'moderncart-toggle-slide-out' ] ),
			'item_account'   => $cart_count,
			'cart_icon'      => $cart_icon, // Cart icon for floating cart refresh.
			'cart_svg_icons' => $cart_svg_icons, // Cart icon for floating cart refresh.
		];

		if ( $hide_if_empty && 0 === $cart_count ) {
			$data['classes'][] = 'moderncart-floating-cart-empty';
		}

		ob_start();
		moderncart_get_template_part( 'shop/floating-inner', '', $data );
		$result = ob_get_contents();
		ob_end_clean();

		$return = [
			'content'       => $result,
			'cart_count'    => $cart_count,
			'hide_if_empty' => $hide_if_empty,
		];
		wp_send_json( $return );
	}
}
