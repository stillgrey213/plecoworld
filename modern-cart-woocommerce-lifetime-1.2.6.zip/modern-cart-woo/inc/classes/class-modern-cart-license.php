<?php
/**
 * Modern Cart License stub — license check removed.
 *
 * @package modern-cart-woo
 */

namespace ModernCart_Pro\Inc\Classes;

use ModernCart_Pro\Inc\Traits\Get_Instance;

class Modern_Cart_License {
	use Get_Instance;

	public $activate_status = 'Activated';
}
