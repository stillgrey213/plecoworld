<?php
/**
 * Modern Cart Pro Analytics.
 *
 * Appends Pro-exclusive usage stats to the BSF Analytics payload via the
 * `modern_cart_get_specific_stats` filter. The free plugin (Modern Cart
 * Starter) owns the BSF Analytics entity and fires this filter after
 * populating its own free-feature data, so this class is responsible only
 * for settings that exist in the Pro plugin.
 *
 * All KPI values are read directly from existing plugin options — no event
 * counters or transients are created.
 *
 * Free-feature stats tracked by the free plugin (not repeated here):
 *   enable_moderncart, cart_theme_style, product_image_size, section_styling,
 *   floating_cart_position, enabled_free_shipping_bar, enabled_coupon_field,
 *   enabled_ajax_add_to_cart, enabled_express_checkout, enabled_powered_by
 *
 * @package modern-cart-woo
 * @since   1.2.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Modern_Cart_Pro_Analytics
 *
 * Singleton that appends Pro-specific stats to the shared BSF Analytics
 * payload via the `modern_cart_get_specific_stats` filter.
 *
 * @since 1.2.4
 */
class Modern_Cart_Pro_Analytics {

	/**
	 * Singleton instance.
	 *
	 * @since 1.2.4
	 * @var Modern_Cart_Pro_Analytics|null
	 */
	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @since 1.2.4
	 * @return Modern_Cart_Pro_Analytics
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor — registers filter and event-detection hooks.
	 *
	 * @since 1.2.4
	 */
	private function __construct() {
		add_filter( 'modern_cart_get_specific_stats', array( $this, 'add_pro_specific_stats' ) );
		// Hook at priority 25 so free plugin's register_bsf_analytics_entity (init priority 20)
		// has already loaded Modern_Cart_Analytics — avoids plugin load order race condition.
		add_action( 'init', array( $this, 'maybe_detect_pro_state_events' ), 25 );
	}

	/**
	 * Gate for Pro state-event detection — runs once per day in admin.
	 *
	 * Hooked to `init` at priority 25 to ensure the free plugin's
	 * Modern_Cart_Analytics class is already loaded (free registers on init
	 * priority 10). Returns early without setting the transient if
	 * BSF_Analytics_Events is not yet available, so it retries on the next
	 * admin page load.
	 *
	 * @since 1.2.6
	 * @return void
	 */
	public function maybe_detect_pro_state_events() {
		if ( ! is_admin() ) {
			return;
		}

		if ( false !== get_transient( 'mcw_pro_state_events_checked' ) ) {
			return;
		}

		$this->detect_pro_state_events();
	}

	/**
	 * Detect and queue one-time Pro milestone events via the free plugin's
	 * BSF_Analytics_Events instance.
	 *
	 * Calls Modern_Cart_Analytics::events() directly — Pro requires the free
	 * plugin to be active, so the shared event queue is always available.
	 * The daily transient throttle is only set when BSF_Analytics_Events
	 * is confirmed loaded; otherwise this method retries silently.
	 *
	 * @since 1.2.6
	 * @return void
	 */
	private function detect_pro_state_events() {
		if ( ! class_exists( 'Modern_Cart_Analytics' ) ) {
			return;
		}

		$events = Modern_Cart_Analytics::events();
		if ( null === $events ) {
			// BSF_Analytics_Events not yet loaded — retry on next admin load.
			return;
		}

		set_transient( 'mcw_pro_state_events_checked', 1, DAY_IN_SECONDS );

		// 1. pro_plugin_updated — re-track whenever Pro version changes.
		$stored_pro_version = get_option( 'mcw_pro_tracked_version', '' );
		if ( MODERNCART_PRO_VER !== $stored_pro_version ) {
			if ( ! empty( $stored_pro_version ) ) {
				$events->flush_pushed( array( 'pro_plugin_updated' ) );
				$events->track(
					'pro_plugin_updated',
					MODERNCART_PRO_VER,
					array( 'from_version' => $stored_pro_version )
				);
			}
			update_option( 'mcw_pro_tracked_version', MODERNCART_PRO_VER );
		}

		// 2. first_popup_cart_configured — user saved popup as cart type.
		if ( get_option( 'mcw_first_popup_cart_configured', false ) ) {
			$events->track( 'first_popup_cart_configured' );
		}

		// 3. first_recommendations_configured — in-cart recommendations enabled.
		if ( get_option( 'mcw_first_recommendations_configured', false ) ) {
			$mcw_rec_type = get_option( 'mcw_first_recommendations_type', '' );
			$events->track(
				'first_recommendations_configured',
				is_string( $mcw_rec_type ) ? $mcw_rec_type : ''
			);
		}

		// 4. first_empty_cart_recommendations_configured.
		if ( get_option( 'mcw_first_empty_cart_rec_configured', false ) ) {
			$mcw_empty_rec_type = get_option( 'mcw_first_empty_cart_rec_type', '' );
			$events->track(
				'first_empty_cart_recommendations_configured',
				is_string( $mcw_empty_rec_type ) ? $mcw_empty_rec_type : ''
			);
		}

		// 5. first_custom_cart_icon_configured.
		if ( get_option( 'mcw_first_custom_icon_configured', false ) ) {
			$events->track( 'first_custom_cart_icon_configured' );
		}

		// --- Relocated from free plugin: state-based Pro events ---

		$cart_settings     = (array) get_option( MODERNCART_SETTINGS, array() );
		$floating_settings = (array) get_option( MODERNCART_FLOATING_SETTINGS, array() );

		// popup_cart_enabled.
		if ( ! empty( $cart_settings['cart_type'] ) && 'popup' === $cart_settings['cart_type'] ) {
			$events->track( 'popup_cart_enabled' );
		}

		// recommendations_enabled.
		$rec_type = ! empty( $cart_settings['recommendation_types'] ) ? $cart_settings['recommendation_types'] : 'disabled';
		if ( 'disabled' !== $rec_type ) {
			$events->track( 'recommendations_enabled', $rec_type );
		}

		// empty_cart_recommendations_enabled.
		$empty_rec_type = ! empty( $cart_settings['empty_cart_recommendation'] ) ? $cart_settings['empty_cart_recommendation'] : 'disabled';
		if ( 'disabled' !== $empty_rec_type ) {
			$events->track( 'empty_cart_recommendations_enabled', $empty_rec_type );
		}

		// custom_cart_icon_set.
		$floating_cart_icon = ! empty( $floating_settings['floating_cart_icon'] ) ? $floating_settings['floating_cart_icon'] : '';
		if ( ! empty( $floating_settings['custom_cart_icon_url'] ) && 'custom' === $floating_cart_icon ) {
			$events->track( 'custom_cart_icon_set' );
		}

		// license_key_activated.
		if ( defined( 'MODERNCART_PRO_PRODUCT_ID' ) ) {
			$license_status = get_option( 'wc_am_client_' . MODERNCART_PRO_PRODUCT_ID . '_activated', 'Deactivated' );
			if ( 'Activated' === $license_status ) {
				$events->track( 'license_key_activated' );
			}
		}

		// --- New Pro milestone events ---

		// 6. shipping_display_enabled (state-based).
		if ( ! empty( $cart_settings['enable_shipping'] ) && true === boolval( $cart_settings['enable_shipping'] ) ) {
			$events->track( 'shipping_display_enabled' );
		}

		// 7. custom_trigger_configured (state-based).
		if ( ! empty( $floating_settings['custom_trigger_selectors'] ) ) {
			$events->track( 'custom_trigger_configured' );
		}

		// 8. first_header_style_configured (flag-based).
		if ( get_option( 'mcw_first_header_style_configured', false ) ) {
			$mcw_header_style = get_option( 'mcw_first_header_style_type', '' );
			$events->track(
				'first_header_style_configured',
				is_string( $mcw_header_style ) ? $mcw_header_style : ''
			);
		}

		// 9. first_order_summary_style_configured (flag-based).
		if ( get_option( 'mcw_first_order_summary_style_configured', false ) ) {
			$mcw_order_summary_style = get_option( 'mcw_first_order_summary_style_type', '' );
			$events->track(
				'first_order_summary_style_configured',
				is_string( $mcw_order_summary_style ) ? $mcw_order_summary_style : ''
			);
		}

		// 10. first_auto_open_configured (flag-based).
		if ( get_option( 'mcw_first_auto_open_configured', false ) ) {
			$mcw_auto_open_type = get_option( 'mcw_first_auto_open_type', '' );
			$events->track(
				'first_auto_open_configured',
				is_string( $mcw_auto_open_type ) ? $mcw_auto_open_type : ''
			);
		}
	}

	/**
	 * Append Pro-exclusive stats to the Modern Cart analytics payload.
	 *
	 * Called via the `modern_cart_get_specific_stats` filter after the free
	 * plugin has already populated free-feature data. Only Pro-exclusive
	 * settings are added here; free-feature stats must not be duplicated.
	 *
	 * @since 1.2.4
	 *
	 * @param array<string, mixed> $stats_data Stats array populated by the free plugin.
	 * @return array<string, mixed> Stats array with Pro-specific data merged in.
	 */
	public function add_pro_specific_stats( $stats_data ) {
		// Ensure the parent node exists in case of an unexpected call order.
		$plugin_data = is_array( $stats_data['plugin_data'] ) ? $stats_data['plugin_data'] : array();
		$modern_cart = isset( $plugin_data['modern_cart'] ) && is_array( $plugin_data['modern_cart'] )
			? $plugin_data['modern_cart']
			: array();

		// Merge Pro-only default stats (string / enum values).
		$modern_cart = array_merge( $modern_cart, $this->get_pro_default_stats() );

		// Merge Pro-only boolean flags into the existing boolean_values node.
		$boolean_values = isset( $modern_cart['boolean_values'] ) && is_array( $modern_cart['boolean_values'] )
			? $modern_cart['boolean_values']
			: array();

		$modern_cart['boolean_values'] = array_merge( $boolean_values, $this->get_pro_boolean_values() );

		// Note: events_record is NOT flushed here. All events (free + Pro) are
		// tracked into the shared 'mcw' queue via Modern_Cart_Analytics::events()
		// and flushed once by the free plugin's get_specific_stats(). A second
		// flush here would overwrite those events with an empty array.

		// Daily KPIs — last 2 days of WooCommerce order counts.
		$modern_cart['kpi_records'] = $this->get_kpi_tracking_data();

		$plugin_data['modern_cart'] = $modern_cart;
		$stats_data['plugin_data']  = $plugin_data;

		return $stats_data;
	}

	/**
	 * Get Pro-exclusive default stats.
	 *
	 * Reads values directly from existing plugin options. No counters or
	 * event tracking — values reflect the user's current Pro configuration.
	 *
	 * Pro-only settings covered (not tracked by the free plugin):
	 *   cart_type, cart_header_style, recommendation_types,
	 *   empty_cart_recommendation, order_summary_style,
	 *   cart_auto_open_behavior, NPS survey data.
	 *
	 * @since 1.2.4
	 *
	 * @return array<string, mixed> Pro-exclusive stats.
	 */
	public function get_pro_default_stats() {
		$cart_settings = (array) get_option( MODERNCART_SETTINGS, array() );

		return array(
			'cart_type'                   => ! empty( $cart_settings['cart_type'] ) ? $cart_settings['cart_type'] : '', // Cart type [slideout, popup].
			'cart_header_style'           => ! empty( $cart_settings['cart_header_style'] ) ? $cart_settings['cart_header_style'] : '', // Cart header style [style1, style2, style3].
			'product_recommendation_type' => ! empty( $cart_settings['recommendation_types'] ) ? $cart_settings['recommendation_types'] : '', // Product recommendation type [Disabled, Cross-sell, Upsell].
			'recommendation_types'        => ! empty( $cart_settings['recommendation_types'] ) ? $cart_settings['recommendation_types'] : '', // In-cart recommendation type [disabled, cross_sells, upsells].
			'empty_cart_recommendation'   => ! empty( $cart_settings['empty_cart_recommendation'] ) ? $cart_settings['empty_cart_recommendation'] : '', // Empty-cart recommendation type [disabled, cross_sells, upsells, featured].
			'order_summary_style'         => ! empty( $cart_settings['order_summary_style'] ) ? $cart_settings['order_summary_style'] : '', // Order summary style [style1, style2, style3].
			'cart_auto_open_behavior'     => ! empty( $cart_settings['cart_auto_open_behavior'] ) ? $cart_settings['cart_auto_open_behavior'] : '', // Cart auto-open behavior [show-cart-on-first-add, always-show, disabled].
			'nps-survey-status'           => get_option( 'nps-survey-modern-cart-for-woocommerce', array() ), // NPS Survey interaction state (first_display, dismissed, submitted, etc.).
			'nps-library-version'         => defined( 'NPS_SURVEY_VER' ) ? NPS_SURVEY_VER : '', // NPS Survey library version.
		);
	}

	/**
	 * Get Pro-exclusive boolean feature flags.
	 *
	 * Values are read directly from existing plugin options and compared
	 * inline — no separate counters are written.
	 *
	 * Pro-only boolean flags covered (not tracked by the free plugin):
	 *   enable_shipping, is_using_custom_cart_icon, is_using_custom_trigger.
	 *
	 * @since 1.2.4
	 *
	 * @return array<string, bool> Pro-exclusive boolean feature flags.
	 */
	public function get_pro_boolean_values() {
		$cart_settings     = (array) get_option( MODERNCART_SETTINGS, array() );
		$floating_settings = (array) get_option( MODERNCART_FLOATING_SETTINGS, array() );

		$floating_cart_icon = ! empty( $floating_settings['floating_cart_icon'] ) ? $floating_settings['floating_cart_icon'] : '';

		return array(
			'enable_shipping'           => ! empty( $cart_settings['enable_shipping'] ) && true === boolval( $cart_settings['enable_shipping'] ), // Track if shipping display is enabled in the order summary.
			'is_using_custom_cart_icon' => ! empty( $floating_settings['custom_cart_icon_url'] ) && 'custom' === $floating_cart_icon, // Track if a custom floating cart icon is in use.
			'is_using_custom_trigger'   => ! empty( $floating_settings['custom_trigger_selectors'] ), // Track if custom cart trigger selectors are configured.
		);
	}

	/**
	 * Get KPI tracking data for the last 2 days (excluding today).
	 *
	 * Keyed by date string (Y-m-d). Each date entry contains numeric_values
	 * with the WooCommerce order count for that day.
	 *
	 * @since 1.2.6
	 * @return array<string, array<string, array<string, int>>> KPI records.
	 */
	private function get_kpi_tracking_data() {
		$kpi_records = array();

		for ( $i = 1; $i <= 2; $i++ ) {
			$date = wp_date( 'Y-m-d', strtotime( "-{$i} days" ) );
			if ( ! is_string( $date ) ) {
				continue;
			}
			$kpi_records[ $date ] = array(
				'numeric_values' => array(
					'orders' => $this->get_daily_orders_count( $date ),
				),
			);
		}

		return $kpi_records;
	}

	/**
	 * Count WooCommerce orders for a specific date.
	 *
	 * Queries only by date and status — no order content is read. Uses
	 * paginate=true with limit=1 to avoid loading all order IDs into memory.
	 * Compatible with WooCommerce HPOS (custom order tables).
	 *
	 * @since 1.2.6
	 *
	 * @param string $date Date in Y-m-d format.
	 * @return int Order count for the given date.
	 */
	private function get_daily_orders_count( $date ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}

		$result = wc_get_orders(
			array(
				'status'       => array( 'wc-completed', 'wc-processing', 'wc-on-hold' ),
				'date_created' => $date . '...' . $date,
				'return'       => 'ids',
				'limit'        => 1,
				'paginate'     => true,
			)
		);

		return isset( $result->total ) ? (int) $result->total : 0;
	}
}

Modern_Cart_Pro_Analytics::get_instance();
