<?php
/**
 * Plugin Name: Pleco World Order Analytics
 * Description: Adds a WooCommerce admin analytics page for fish/product sales, customer buying patterns, order size, and order cadence.
 * Version: 0.1.0
 * Author: Pleco World
 * Requires Plugins: woocommerce
 * Text Domain: pleco-order-analytics
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'before_woocommerce_init',
	function() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

final class Pleco_World_Order_Analytics {
	private const MENU_SLUG = 'pleco-world-analytics';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
	}

	public function add_admin_menu(): void {
		add_submenu_page(
			'woocommerce',
			'Pleco Order Analytics',
			'Pleco World Analytics',
			'manage_woocommerce',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function render_page(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'pleco-order-analytics' ) );
		}

		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_orders' ) ) {
			echo '<div class="wrap"><h1>Pleco Order Analytics</h1><p>WooCommerce is required.</p></div>';
			return;
		}

		$filters = $this->get_filters();
		$orders  = $this->get_orders( $filters );
		$stats   = $this->build_stats( $orders );

		$this->render_styles();
		?>
		<div class="wrap pleco-oa">
			<h1>Pleco Order Analytics</h1>
			<p class="description">Sales and customer patterns based on WooCommerce order line items.</p>

			<?php $this->render_filters( $filters ); ?>
			<?php $this->render_summary_cards( $stats ); ?>

			<div class="pleco-oa-grid">
				<section class="pleco-oa-panel">
					<h2>Best Selling Fish / Products</h2>
					<?php $this->render_products_table( $stats['products'] ); ?>
				</section>

				<section class="pleco-oa-panel">
					<h2>Customer Order Value & Cadence</h2>
					<?php $this->render_customers_table( $stats['customers'] ); ?>
				</section>
			</div>

			<section class="pleco-oa-panel">
				<h2>Who Buys Which Fish</h2>
				<?php $this->render_customer_products_table( $stats['customer_products'] ); ?>
			</section>
		</div>
		<?php
	}

	private function get_filters(): array {
		$default_end   = current_time( 'Y-m-d' );
		$default_start = gmdate( 'Y-m-d', strtotime( $default_end . ' -90 days' ) );

		$start = isset( $_GET['pleco_start'] ) ? sanitize_text_field( wp_unslash( $_GET['pleco_start'] ) ) : $default_start;
		$end   = isset( $_GET['pleco_end'] ) ? sanitize_text_field( wp_unslash( $_GET['pleco_end'] ) ) : $default_end;

		$allowed_statuses = array(
			'pending'    => 'Pending payment',
			'processing' => 'Processing',
			'on-hold'    => 'On hold',
			'completed'  => 'Completed',
			'cancelled'  => 'Cancelled',
			'refunded'   => 'Refunded',
			'failed'     => 'Failed',
		);

		$statuses = isset( $_GET['pleco_status'] ) ? (array) wp_unslash( $_GET['pleco_status'] ) : array( 'processing', 'on-hold', 'completed' );
		$statuses = array_values( array_intersect( array_map( 'sanitize_key', $statuses ), array_keys( $allowed_statuses ) ) );

		if ( empty( $statuses ) ) {
			$statuses = array( 'processing', 'on-hold', 'completed' );
		}

		return array(
			'start'            => $this->normalise_date( $start, $default_start ),
			'end'              => $this->normalise_date( $end, $default_end ),
			'statuses'         => $statuses,
			'allowed_statuses' => $allowed_statuses,
		);
	}

	private function normalise_date( string $date, string $fallback ): string {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ? $date : $fallback;
	}

	private function get_orders( array $filters ): array {
		$date_created = $filters['start'] . ' 00:00:00...' . $filters['end'] . ' 23:59:59';

		return wc_get_orders(
			array(
				'limit'        => -1,
				'type'         => 'shop_order',
				'status'       => $filters['statuses'],
				'date_created' => $date_created,
				'orderby'      => 'date',
				'order'        => 'ASC',
			)
		);
	}

	private function build_stats( array $orders ): array {
		$products          = array();
		$customers         = array();
		$customer_products = array();
		$total_revenue     = 0.0;
		$total_items       = 0;

		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$order_id       = $order->get_id();
			$order_total    = (float) $order->get_total();
			$order_date     = $order->get_date_created();
			$order_date_key = $order_date ? $order_date->date( 'Y-m-d' ) : '';
			$customer_key   = $this->get_customer_key( $order );
			$customer_name  = $this->get_customer_name( $order );

			$total_revenue += $order_total;

			if ( ! isset( $customers[ $customer_key ] ) ) {
				$customers[ $customer_key ] = array(
					'name'         => $customer_name,
					'email'        => $order->get_billing_email(),
					'orders'       => 0,
					'revenue'      => 0.0,
					'items'        => 0,
					'dates'        => array(),
					'last_order'   => '',
					'avg_order'    => 0.0,
					'avg_cadence'  => null,
				);
			}

			$customers[ $customer_key ]['orders']++;
			$customers[ $customer_key ]['revenue'] += $order_total;
			$customers[ $customer_key ]['dates'][] = $order_date_key;
			$customers[ $customer_key ]['last_order'] = $order_date_key;

			foreach ( $order->get_items( 'line_item' ) as $item ) {
				if ( ! $item instanceof WC_Order_Item_Product ) {
					continue;
				}

				$product_key = $this->get_product_key( $item );
				$name        = $this->get_item_display_name( $item );
				$qty         = (float) $item->get_quantity();
				$line_total  = (float) $item->get_total();
				$sku         = $this->get_item_sku( $item );

				$total_items += $qty;
				$customers[ $customer_key ]['items'] += $qty;

				if ( ! isset( $products[ $product_key ] ) ) {
					$products[ $product_key ] = array(
						'name'      => $name,
						'sku'       => $sku,
						'qty'       => 0.0,
						'revenue'   => 0.0,
						'orders'    => array(),
						'customers' => array(),
					);
				}

				$products[ $product_key ]['qty'] += $qty;
				$products[ $product_key ]['revenue'] += $line_total;
				$products[ $product_key ]['orders'][ $order_id ] = true;
				$products[ $product_key ]['customers'][ $customer_key ] = true;

				$matrix_key = $customer_key . '|' . $product_key;

				if ( ! isset( $customer_products[ $matrix_key ] ) ) {
					$customer_products[ $matrix_key ] = array(
						'customer'   => $customer_name,
						'email'      => $order->get_billing_email(),
						'product'    => $name,
						'sku'        => $sku,
						'qty'        => 0.0,
						'revenue'    => 0.0,
						'orders'     => array(),
						'last_order' => '',
					);
				}

				$customer_products[ $matrix_key ]['qty'] += $qty;
				$customer_products[ $matrix_key ]['revenue'] += $line_total;
				$customer_products[ $matrix_key ]['orders'][ $order_id ] = true;
				$customer_products[ $matrix_key ]['last_order'] = $order_date_key;
			}
		}

		foreach ( $products as &$product ) {
			$product['order_count']    = count( $product['orders'] );
			$product['customer_count'] = count( $product['customers'] );
			$product['avg_per_order']  = $product['order_count'] > 0 ? $product['qty'] / $product['order_count'] : 0;
			unset( $product['orders'], $product['customers'] );
		}
		unset( $product );

		foreach ( $customers as &$customer ) {
			$customer['avg_order']   = $customer['orders'] > 0 ? $customer['revenue'] / $customer['orders'] : 0;
			$customer['avg_cadence'] = $this->calculate_average_cadence( $customer['dates'] );
			unset( $customer['dates'] );
		}
		unset( $customer );

		foreach ( $customer_products as &$row ) {
			$row['order_count'] = count( $row['orders'] );
			unset( $row['orders'] );
		}
		unset( $row );

		uasort( $products, fn( $a, $b ) => $b['qty'] <=> $a['qty'] );
		uasort( $customers, fn( $a, $b ) => $b['revenue'] <=> $a['revenue'] );
		uasort( $customer_products, fn( $a, $b ) => $b['qty'] <=> $a['qty'] );

		return array(
			'order_count'       => count( $orders ),
			'total_revenue'     => $total_revenue,
			'total_items'       => $total_items,
			'avg_order_value'   => count( $orders ) > 0 ? $total_revenue / count( $orders ) : 0,
			'products'          => $products,
			'customers'         => $customers,
			'customer_products' => $customer_products,
		);
	}

	private function get_customer_key( WC_Order $order ): string {
		$user_id = $order->get_user_id();

		if ( $user_id ) {
			return 'user_' . $user_id;
		}

		$email = strtolower( trim( (string) $order->get_billing_email() ) );

		return $email ? 'email_' . md5( $email ) : 'guest_order_' . $order->get_id();
	}

	private function get_customer_name( WC_Order $order ): string {
		$company = trim( (string) $order->get_billing_company() );
		$name    = trim( $order->get_formatted_billing_full_name() );

		if ( $company && $name ) {
			return $company . ' (' . $name . ')';
		}

		return $company ?: ( $name ?: 'Guest customer' );
	}

	private function get_product_key( WC_Order_Item_Product $item ): string {
		$variation_id = $item->get_variation_id();
		$product_id   = $item->get_product_id();

		return $variation_id ? 'variation_' . $variation_id : 'product_' . $product_id;
	}

	private function get_item_display_name( WC_Order_Item_Product $item ): string {
		$name = $item->get_name();
		$meta = array();

		foreach ( $item->get_formatted_meta_data( '' ) as $meta_item ) {
			if ( ! empty( $meta_item->display_key ) && ! empty( $meta_item->display_value ) ) {
				$meta[] = wp_strip_all_tags( $meta_item->display_key . ': ' . $meta_item->display_value );
			}
		}

		return $meta ? $name . ' (' . implode( ', ', $meta ) . ')' : $name;
	}

	private function get_item_sku( WC_Order_Item_Product $item ): string {
		$product = $item->get_product();

		return $product ? (string) $product->get_sku() : '';
	}

	private function calculate_average_cadence( array $dates ): ?float {
		$dates = array_values( array_filter( array_unique( $dates ) ) );
		sort( $dates );

		if ( count( $dates ) < 2 ) {
			return null;
		}

		$diffs = array();

		for ( $i = 1; $i < count( $dates ); $i++ ) {
			$previous = strtotime( $dates[ $i - 1 ] );
			$current  = strtotime( $dates[ $i ] );

			if ( $previous && $current && $current > $previous ) {
				$diffs[] = ( $current - $previous ) / DAY_IN_SECONDS;
			}
		}

		return $diffs ? array_sum( $diffs ) / count( $diffs ) : null;
	}

	private function render_filters( array $filters ): void {
		?>
		<form method="get" class="pleco-oa-filters">
			<input type="hidden" name="page" value="<?php echo esc_attr( self::MENU_SLUG ); ?>" />
			<label>
				<span>From</span>
				<input type="date" name="pleco_start" value="<?php echo esc_attr( $filters['start'] ); ?>" />
			</label>
			<label>
				<span>To</span>
				<input type="date" name="pleco_end" value="<?php echo esc_attr( $filters['end'] ); ?>" />
			</label>
			<fieldset>
				<legend>Statuses</legend>
				<?php foreach ( $filters['allowed_statuses'] as $status => $label ) : ?>
					<label class="pleco-oa-check">
						<input type="checkbox" name="pleco_status[]" value="<?php echo esc_attr( $status ); ?>" <?php checked( in_array( $status, $filters['statuses'], true ) ); ?> />
						<?php echo esc_html( $label ); ?>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<button type="submit" class="button button-primary">Update report</button>
		</form>
		<?php
	}

	private function render_summary_cards( array $stats ): void {
		$cards = array(
			'Orders'              => number_format_i18n( $stats['order_count'] ),
			'Fish / items sold'   => number_format_i18n( $stats['total_items'], 0 ),
			'Revenue'             => wc_price( $stats['total_revenue'] ),
			'Average order value' => wc_price( $stats['avg_order_value'] ),
		);
		?>
		<div class="pleco-oa-cards">
			<?php foreach ( $cards as $label => $value ) : ?>
				<div class="pleco-oa-card">
					<span><?php echo esc_html( $label ); ?></span>
					<strong><?php echo wp_kses_post( $value ); ?></strong>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	private function render_products_table( array $products ): void {
		$this->render_table(
			array( 'Product / variation', 'SKU', 'Qty sold', 'Revenue', 'Orders', 'Customers', 'Avg qty/order' ),
			array_slice( $products, 0, 100 ),
			function( $row ) {
				return array(
					esc_html( $row['name'] ),
					esc_html( $row['sku'] ?: '-' ),
					esc_html( number_format_i18n( $row['qty'], 0 ) ),
					wp_kses_post( wc_price( $row['revenue'] ) ),
					esc_html( number_format_i18n( $row['order_count'] ) ),
					esc_html( number_format_i18n( $row['customer_count'] ) ),
					esc_html( number_format_i18n( $row['avg_per_order'], 1 ) ),
				);
			}
		);
	}

	private function render_customers_table( array $customers ): void {
		$this->render_table(
			array( 'Customer', 'Email', 'Orders', 'Items', 'Revenue', 'Avg order', 'Avg cadence', 'Last order' ),
			array_slice( $customers, 0, 100 ),
			function( $row ) {
				return array(
					esc_html( $row['name'] ),
					esc_html( $row['email'] ?: '-' ),
					esc_html( number_format_i18n( $row['orders'] ) ),
					esc_html( number_format_i18n( $row['items'], 0 ) ),
					wp_kses_post( wc_price( $row['revenue'] ) ),
					wp_kses_post( wc_price( $row['avg_order'] ) ),
					esc_html( null === $row['avg_cadence'] ? '-' : number_format_i18n( $row['avg_cadence'], 1 ) . ' days' ),
					esc_html( $row['last_order'] ?: '-' ),
				);
			}
		);
	}

	private function render_customer_products_table( array $rows ): void {
		$this->render_table(
			array( 'Customer', 'Email', 'Product / variation', 'SKU', 'Qty', 'Revenue', 'Orders', 'Last order' ),
			array_slice( $rows, 0, 250 ),
			function( $row ) {
				return array(
					esc_html( $row['customer'] ),
					esc_html( $row['email'] ?: '-' ),
					esc_html( $row['product'] ),
					esc_html( $row['sku'] ?: '-' ),
					esc_html( number_format_i18n( $row['qty'], 0 ) ),
					wp_kses_post( wc_price( $row['revenue'] ) ),
					esc_html( number_format_i18n( $row['order_count'] ) ),
					esc_html( $row['last_order'] ?: '-' ),
				);
			}
		);
	}

	private function render_table( array $headers, array $rows, callable $row_mapper ): void {
		if ( empty( $rows ) ) {
			echo '<p>No matching orders found for this period/status selection.</p>';
			return;
		}
		?>
		<div class="pleco-oa-table-wrap">
			<table class="widefat striped pleco-oa-table">
				<thead>
					<tr>
						<?php foreach ( $headers as $header ) : ?>
							<th><?php echo esc_html( $header ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<?php foreach ( $row_mapper( $row ) as $cell ) : ?>
								<td><?php echo $cell; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private function render_styles(): void {
		?>
		<style>
			.pleco-oa { max-width: 1600px; }
			.pleco-oa .description { margin-bottom: 18px; }
			.pleco-oa-filters {
				display: flex;
				flex-wrap: wrap;
				align-items: flex-end;
				gap: 14px 18px;
				padding: 16px;
				margin: 18px 0;
				background: #fff;
				border: 1px solid #dcdcde;
			}
			.pleco-oa-filters label span,
			.pleco-oa-filters legend {
				display: block;
				margin-bottom: 6px;
				font-weight: 600;
			}
			.pleco-oa-filters fieldset {
				display: flex;
				flex-wrap: wrap;
				gap: 8px 12px;
				margin: 0;
				padding: 0;
				border: 0;
			}
			.pleco-oa-check {
				display: inline-flex;
				align-items: center;
				gap: 4px;
				margin: 0;
			}
			.pleco-oa-cards {
				display: grid;
				grid-template-columns: repeat(4, minmax(160px, 1fr));
				gap: 12px;
				margin: 18px 0;
			}
			.pleco-oa-card {
				padding: 16px;
				background: #fff;
				border: 1px solid #dcdcde;
			}
			.pleco-oa-card span {
				display: block;
				margin-bottom: 8px;
				color: #646970;
				font-size: 12px;
				font-weight: 700;
				letter-spacing: .04em;
				text-transform: uppercase;
			}
			.pleco-oa-card strong {
				font-size: 24px;
				line-height: 1.1;
			}
			.pleco-oa-grid {
				display: grid;
				grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
				gap: 18px;
			}
			.pleco-oa-panel {
				margin: 18px 0;
				padding: 18px;
				background: #fff;
				border: 1px solid #dcdcde;
			}
			.pleco-oa-panel h2 {
				margin-top: 0;
			}
			.pleco-oa-table-wrap {
				overflow-x: auto;
			}
			.pleco-oa-table th,
			.pleco-oa-table td {
				vertical-align: top;
			}
			@media (max-width: 1100px) {
				.pleco-oa-grid,
				.pleco-oa-cards {
					grid-template-columns: 1fr;
				}
			}
		</style>
		<?php
	}
}

new Pleco_World_Order_Analytics();
